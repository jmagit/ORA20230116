alter session set "_ORACLE_SCRIPT"=true;
@c:\labs\samples\mksample root root hrpw oepw pmpw ixpw shpw bipw users temp @c:\labs\samples\log\ localhost:1521/xe
