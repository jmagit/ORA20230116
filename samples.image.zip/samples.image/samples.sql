alter session set "_ORACLE_SCRIPT"=true;
@/mnt/c/labs/samples/mksample root root hrpw oepw pmpw ixpw shpw bipw users temp @/mnt/c/labs/samples/log/ localhost:1521/xe
