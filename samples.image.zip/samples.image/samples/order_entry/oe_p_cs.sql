set define off
INSERT INTO product_descriptions VALUES(1726-
,'CS'-
,UNISTR(-
'Monitor s tekut\00fdmi krystaly 11/PM'-
),UNISTR(-
'Pasivn\00ed monitor s displejem s tekut\00fdmi krystaly o \00fahlop'||-
'\0159\00ed\010dce 11 palc\016f. Ploch\00e1 obrazovka s vysokou rozli'||-
'\0161ovac\00ed schopnost\00ed m\00e1 vynikaj\00edc\00ed kvalitu obra'||-
'zu se sn\00ed\017een\00fdm odleskem.'-
));
INSERT INTO product_descriptions VALUES(2359-
,'CS'-
,UNISTR(-
'Monitor s tekut\00fdmi krystaly 9/PM'-
),UNISTR(-
'Pasivn\00ed monitor s displejem s tekut\00fdmi krystaly o \00fahlop'||-
'\0159\00ed\010dce 9 palc\016f. Vyu\017e\00edvejte produktivity, kter'||-
'ou v\00e1m m\016f\017ee poskytnout mal\00fd monitor t\00edm, \017ee '||-
'v\00e1m ponech\00e1 v\00edce m\00edsta na pracovn\00edm stole. Snadno'||-
' se d\00e1 nastavit s vyu\017eit\00edm kompatibility plug-and-play (p'||-
'\0159ipoj a pracuj).'-
));
INSERT INTO product_descriptions VALUES(3060-
,'CS'-
,UNISTR(-
'Monitor 17/HR'-
),UNISTR(-
'Monitor se 17-ti palcovou obrazovkou (16 palc\016f viditeln\00fdch) s vy'||-
'sokou rozli\0161ovac\00ed schopnost\00ed. M\00e1 mimo\0159\00e1dnou '||-
'kvalitu obrazu a v\00fdhodu zv\011bt\0161en\00e9 plochy na obrazovce. '||-
'Monitor nab\00edz\00ed ostr\00fd, barevn\011b pln\00fd obraz za neuv'||-
'\011b\0159itelnou cenu. M\00e1 velk\00e9 mno\017estv\00ed d\016fle'||-
'\017eit\00fdch vlastnost\00ed, v\010detn\011b ovl\00e1dac\00edch pr'||-
'vk\016f na obrazovce.'-
));
INSERT INTO product_descriptions VALUES(2243-
,'CS'-
,UNISTR(-
'Monitor 17/HR/F'-
),UNISTR(-
'Monitor s \00fahlop\0159\00ed\010dkou 17 palc\016f (16 palc\016f vid'||-
'iteln\00fdch) s vysok\00fdm rozli\0161en\00edm, s plochou obrazovkou. '||-
'Fotonov\00e1 tryska o vysok\00e9 hustot\011b se zdokonalen\00fdm elipt'||-
'ick\00fdm korek\010dn\00edm syst\00e9mem umo\017e\0148uje p\0159esn'||-
'\00e9 a shodn\00e9 zaost\0159en\00ed po cel\00e9 obrazovce, dokonce i'||-
' v roz\00edch.'-
));
INSERT INTO product_descriptions VALUES(3057-
,'CS'-
,UNISTR(-
'Monitor 17/SD'-
),UNISTR(-
'Monitor se 17-ti palcovou obrazovkou (16 palc\016f viditeln\00fdch) o ma'||-
'l\00e9 hloubce. M\00e1 vynikaj\00edc\00ed kvalitu a p\0159esnost obra'||-
'zu. U\017eivatel\016fm, kte\0159\00ed profesion\00e1ln\011b pracuj'||-
'\00ed s barvami, s in\017een\00fdrsk\00fdmi \00falohami a s vizualiza'||-
'c\00ed/animac\00ed, poskytuje barevnou v\011brnost, kterou po\017eaduj'||-
'\00ed, plus velkou pracovn\00ed plochu pro zv\00fd\0161enou produktivi'||-
'tu.'-
));
INSERT INTO product_descriptions VALUES(3061-
,'CS'-
,UNISTR(-
'Monitor 19/SD'-
),UNISTR(-
'Monitor o \00fahlop\0159\00ed\010dce 19 palc\016f (18 palc\016f vidi'||-
'teln\00fdch) o mal\00e9 hloubce. Vysocekontrastn\00ed \010dern\00e1 v'||-
'rstva na obrazovce: vytv\00e1\0159\00ed vynikaj\00edc\00ed kontrast a'||-
' velk\00fd rozsah \0161ed\00fdch odst\00edn\016f. Nov\011b navr'||-
'\017een\00e9 profesin\00e1ln\00ed reproduktory se zesilova\010dem a d'||-
'ynamickou odezvou bas\016f o\017eivuj\00ed v\0161echny va\0161e multi'||-
'medi\00e1ln\00ed aplikace jasn\00fdm, v\011brn\00fdm zvukem a bohat'||-
'\00fdmi, hlubok\00fdmi basy. K tomu barevn\011b ozna\010den\00e9 kabe'||-
'ly, jednoduch\00e9 p\0159ipojen\00ed plug-and-play (p\0159ipoj a pracu'||-
'j) a digit\00e1ln\00ed ovl\00e1dac\00ed prvky na obrazovce znamenaj'||-
'\00ed, \017ee budete p\0159ipraveni upnout sv\016fj zrak na n\00e1dhe'||-
'rn\00e1 multim\00e9dia a vynikaj\00edc\00ed internet jen v n\011bkoli'||-
'ka minut\00e1ch.'-
));
INSERT INTO product_descriptions VALUES(2245-
,'CS'-
,UNISTR(-
'Monitor 19/SD/M'-
),UNISTR(-
'Monitor 19 palc\016f (18 palc\016f viditeln\00fdch) s malou hloubkou, m'||-
'onochromatick\00fd. Vynikaj\00edc\00ed kvalita obrazu p\0159i kompaktn'||-
'\00ed konstrukci. Jednoduch\00e9 menu na obrazovce v\00e1m umo\017en'||-
'\00ed snadno nastavit rozm\011bry obrazovky, barvy a atributy obrazu. P'||-
'\0159ipojte pouze v\00e1\0161 monitor k PC a jste p\0159ipraveni praco'||-
'vat.'-
));
INSERT INTO product_descriptions VALUES(3065-
,'CS'-
,UNISTR(-
'Monitor 21/D'-
),UNISTR(-
'Monitor 21 palc\016f (20 palc\016f viditeln\00fdch). Digit\00e1ln'||-
'\00ed technologie OptiScan: podporuje rozli\0161en\00ed a\017e 1600x12'||-
'00 pixel\016f p\0159i kmito\010dtu 75 Hz. Rozm\011bry (Vx\0160xH): 8,'||-
'3 x 18,5 x 15 palc\016f. Sn\00edmateln\00e9 reproduktory s\00e9rie Pla'||-
'tinum, nap\00e1jen\00e9 z monitoru, nab\00edzej\00ed jisk\0159iv'||-
'\00fd zvuk a pohodln\011b p\0159\00edstupn\00fd konektor pro digit'||-
'\00e1ln\00ed audio p\0159ehr\00e1va\010d. P\0159ipojte jen v\00e1'||-
'\0161 digit\00e1ln\00ed audio p\0159ehr\00e1va\010d a naslouchejte t'||-
'\00f3n\016fm bez zapnut\00ed va\0161eho osobn\00edho po\010d\00edta'||-
'\010de.'-
));
INSERT INTO product_descriptions VALUES(3331-
,'CS'-
,UNISTR(-
'Monitor 21/HR'-
),UNISTR(-
'21-ti palcov\00fd monitor (20 palc\016f viditeln\00fdch) s vysok\00fdm'||-
' rozli\0161en\00edm. Tento monitor je ide\00e1ln\00ed pro firmy, pro p'||-
'ublika\010dn\00ed \010dinnost a aplikace, vyu\017e\00edvaj\00edc'||-
'\00ed intenzivn\011b grafiku. Vyu\017e\00edjte produktivitu, kterou v'||-
'\00e1m m\016f\017ee p\0159in\00e9st velk\00fd monitor s v\011bt'||-
'\0161\00ed plochou pro prov\00e1d\011bn\00ed aplikac\00ed.'-
));
INSERT INTO product_descriptions VALUES(2252-
,'CS'-
,UNISTR(-
'Monitor 21/HR/M'-
),UNISTR(-
'Monitor 21 palc\016f (20 palc\016f viditeln\00fdch) s vysok\00fdm rozl'||-
'i\0161en\00edm, monochromatick\00fd. Rozm\011bry: 35,6 x 29,6 x 33,3 c'||-
'm (hmotnost 14,6 kg) S obalem: 40,53 x 31,24 x 35,39 cm (16,5 kg). Vodorov'||-
'n\00fd kmito\010det 31,5 - 54 kHz, vertik\00e1ln\00ed kmito\010det 50'||-
' - 120 Hz. Univers\00e1ln\00ed nap\00e1jec\00ed zdroj 90 - 132 V, 50 -'||-
' 60 Hz.'-
));
INSERT INTO product_descriptions VALUES(3064-
,'CS'-
,UNISTR(-
'Monitor 21/SD'-
),UNISTR(-
'Monitor 21 palc\016f (20 palc\016f viditeln\00fdch) s malou hloubkou. V'||-
'lastnosti zahrnuj\00ed vzd\00e1lenost zobrazovac\00edch bod\016f 0,25 '||-
'- 0,28, podporu vysok\00e9ho rozli\0161en\00ed a\017e 1920 x 1200 p'||-
'\0159i kmito\010dtu 76 Hz, menu na obrazovce a vodivou antireflexn\00ed'||-
' vrstvu.'-
));
INSERT INTO product_descriptions VALUES(3155-
,'CS'-
,UNISTR(-
'Oto\010dn\00fd dr\017e\00e1k monitoru - HD'-
),UNISTR(-
'Oto\010dn\00fd dr\017e\00e1k monitoru s vysokou nosnost\00ed, maxim'||-
'\00e1ln\00ed hmotnost monitoru 30 kg'-
));
INSERT INTO product_descriptions VALUES(3234-
,'CS'-
,UNISTR(-
'Oto\010dn\00fd dr\017e\00e1k monitoru - STD'-
),UNISTR(-
'Standardn\00ed dr\017e\00e1k monitoru, maxim\00e1ln\00ed hmotnost mon'||-
'itoru 10 kg'-
));
INSERT INTO product_descriptions VALUES(3350-
,'CS'-
,UNISTR(-
'Plazmov\00fd monitor 10/LE/VGA'-
),UNISTR(-
'10-ti palcov\00fd plazmov\00fd monitor s n\00edzk\00fdm p\0159\00edk'||-
'onem, VGA rozli\0161en\00ed'-
));
INSERT INTO product_descriptions VALUES(2236-
,'CS'-
,UNISTR(-
'Plazmov\00fd monitor 10/TFT/XGA'-
),UNISTR(-
'10-ti palcov\00fd ploch\00fd monitor TFT XGA pro p\0159enosn\00e9 po'||-
'\010d\00edta\010de'-
));
INSERT INTO product_descriptions VALUES(3054-
,'CS'-
,UNISTR(-
'Plazmov\00fd monitor 10/XGA'-
),UNISTR(-
'10-ti palcov\00fd standardn\00ed plazmov\00fd monitor s rozli\0161en'||-
'\00edm XGA. Zcela ploch\00e1 obrazovka s vysok\00fdm rozli\0161en'||-
'\00edm poskytuje vynikaj\00edc\00ed kvalitu obrazu se sn\00ed\017een'||-
'\00fdm odleskem.'-
));
INSERT INTO product_descriptions VALUES(1782-
,'CS'-
,UNISTR(-
'Kompaktn\00ed tisk\00e1rna 400/DQ'-
),UNISTR(-
'Tisk\00e1rna s vysokou rychlost\00ed tisku 400 zn./sek. s ni\017e\0161'||-
'\00ed kvalitou. Rozm\011bry (Vx\0160xH): 17,34 x 24,26 x 26,32 palc'||-
'\016f. Rozhran\00ed: RS-232 s\00e9riov\00e9 (9-kol\00edkov\00fd kone'||-
'ktor), nem\00e1 roz\0161i\0159uj\00ed\00edc\00ed pozice. Form\00e1t'||-
' pap\00edru: A4, US Letter.'-
));
INSERT INTO product_descriptions VALUES(2430-
,'CS'-
,UNISTR(-
'Kompaktn\00ed tisk\00e1rna 400/LQ'-
),UNISTR(-
'Tisk\00e1rna s vysokou rychlost\00ed tisku 400 zn./sec. s vysokou kvalit'||-
'ou (LQ). Rozm\011bry (Vx\0160xH): 12,37 x 27,96 x 23,92 palc\016f. Rozh'||-
'ran\00ed: RS-232 s\00e9riov\00e9 (konektor 25 kol\00edk\016f), 3 roz'||-
'\0161i\0159uj\00edc\00ed pozice (sloty). Form\00e1t pap\00edru: A2, '||-
'A3, A4.'-
));
INSERT INTO product_descriptions VALUES(1792-
,'CS'-
,UNISTR(-
'Pr\016fmyslov\00e1 tisk\00e1rna 600/DQ'-
),UNISTR(-
'Barevn\00e1 tisk\00e1rna s \0161irok\00fdm v\00e1lcem s vysokou rychl'||-
'ost\00ed 600 zn./sec. Rozm\011bry (Vx\0160xH): 22,31 x 25,73 x 20,12 pa'||-
'lc\016f. Form\00e1t pap\00edru: 3 x 5 palce a\017e 11 x 17 palc\016f '||-
'pln\011b o\0159\00edznut\00fd \0161irok\00fd form\00e1t.'-
));
INSERT INTO product_descriptions VALUES(1791-
,'CS'-
,UNISTR(-
'Pr\016fmyslov\00e1 tisk\00e1rna 700/HD'-
),UNISTR(-
'Jehli\010dkov\00e1 tisk\00e1rna s rychlost\00ed 700 zn./sek. s robustn'||-
'\00ed konstrukc\00ed a ochranou proti prachu pro pr\016fmyslov\00e9 po'||-
'u\017eit\00ed. Rozhran\00ed: Centronics paraleln\00ed, kompatibiln'||-
'\00ed s IEEE 1284. Form\00e1t pap\00edru 3 x 5 palce a\017e 11 x 17 pa'||-
'lc\016f pln\011b o\0159\00edznut\00e9ho \0161irok\00e9ho form\00e1'||-
'tu. Pam\011b\0165: 4 MB. Rozm\011bry (Vx\0160xH): 9,3 x 16,5 x 13 palc'||-
'\016f.'-
));
INSERT INTO product_descriptions VALUES(2302-
,'CS'-
,UNISTR(-
'Inkoustov\00e1 tisk\00e1rna B/6'-
),UNISTR(-
'Inkoustov\00e1 tisk\00e1rna, \010dernob\00edl\00e1, 6 str./min., rozl'||-
'i\0161en\00ed 600 x 300 dpi. Rozhran\00ed: Centronics paraleln\00ed, k'||-
'ompatibiln\00ed s IEEE 1284. Rozm\011bry (Vx\0160xH): 7,3 x 17,5 x 14 p'||-
'alc\016f. Form\00e1t pap\00edru A3, A4 US legal. Nem\00e1 roz\0161i'||-
'\0159uj\00edc\00ed pozice.'-
));
INSERT INTO product_descriptions VALUES(2453-
,'CS'-
,UNISTR(-
'Inkoustov\00e1 tisk\00e1rna C/4'-
),UNISTR(-
'Inkoustov\00e1 tisk\00e1rna, barevn\00e1 (s dv\011bma odd\011blen'||-
'\00fdmi inkoustov\00fdmi z\00e1sobn\00edky), 6 str./min. \010dernob'||-
'\00edle, 4 str./min. barevn\011b, rozli\0161en\00ed 600 x 300 dpi. Roz'||-
'hran\00ed: dvousm\011brn\00e9 paraleln\00ed kompatibiln\00ed s IEEE 1'||-
'284 a s\00e9riov\00e9 rozhran\00ed RS-232 (9-kol\00edk\016f), 2 otev'||-
'\0159en\00e9 roz\0161i\0159uj\00edc\00ed pozice (sloty). Pam\011b'||-
'\0165: 8 MB, vyrovn\00e1vac\00ed pam\011b\0165 96 KB.'-
));
INSERT INTO product_descriptions VALUES(1797-
,'CS'-
,UNISTR(-
'Inkoustov\00e1 tisk\00e1rna C/8/HQ'-
),UNISTR(-
'Inkoustov\00e1 tisk\00e1rna, barevn\00e1, 8 str./min., vysok\00e9 rozl'||-
'i\0161en\00ed (fotografick\00e1 kvalita). Pam\011b\0165: 16 MB. Rozm'||-
'\011bry (Vx\0160xH): 7,3 x 17,5 x 14 palc\016f. Form\00e1t pap\00edru'||-
': A4, US letter, ob\00e1lky. Rozhran\00ed: Centronics paraleln\00ed, ko'||-
'mpatibiln\00ed s IEEE 1284.'-
));
INSERT INTO product_descriptions VALUES(2459-
,'CS'-
,UNISTR(-
'Tisk\00e1rna LaserPro 1200/8/BW'-
),UNISTR(-
'Profesion\00e1ln\00ed \010dernob\00edl\00e1 laserov\00e1 tisk\00e1r'||-
'na, rozli\0161en\00ed 1200 dpi, 8 str./sek. Rozm\011bry (Vx\0160xH): 2'||-
'2,37 x 19,86 x 21,92 palc\016f. Software: roz\0161\00ed\0159en\00e9 o'||-
'blada\010de pro SPNIX v4.0; vestav\011bn\00e9 ovlada\010de tisk\00e1r'||-
'ny pro MS-DOS: technologie zv\011bt\0161ov\00e1n\00ed ZoomSmart, plak'||-
'\00e1ty, let\00e1ky, zrcadlov\00e9 obrazy, vodotisk, n\00e1hled, rychl'||-
'\00e9 nastaven\00ed, emulace okraj\016f laserov\00e9 tisk\00e1rny.'-
));
INSERT INTO product_descriptions VALUES(3127-
,'CS'-
,UNISTR(-
'Tisk\00e1rna LaserPro 600/6/BW'-
),UNISTR(-
'Standardn\00ed \010dernob\00edl\00e1 laserov\00e1 tisk\00e1rna, rozl'||-
'i\0161en\00ed 600 dpi, 6 str./sek. Rozhran\00ed: Centronics paraleln'||-
'\00ed, kompatibiln\00ed s IEEE 1284, pam\011b\0165: 8MB, vyrovn\00e1v'||-
'ac\00ed pam\011b\0165 96 KB, pomocn\00e9 programy MS-DOS ToolBox pro S'||-
'PNIX ovlada\010d kompatibiln\00ed s AutoCAM v. 17.'-
));
INSERT INTO product_descriptions VALUES(2254-
,'CS'-
,UNISTR(-
'HD 10GB /I'-
),UNISTR(-
'Pevn\00fd disk s kapacitou 10 GB (intern\00ed). Tyto disky jsou ur\010d'||-
'eny pro dne\0161n\00ed podnikov\00e1 prost\0159ed\00ed s velk\00fdmi'||-
' po\017eadavky na ukl\00e1d\00e1n\00ed dat a jsou ide\00e1ln\00ed v '||-
'aplikac\00edich RAID (diskov\00e1 pole). Sady s univerz\00e1ln\00ed vo'||-
'lbou jsou nakonfigurov\00e1ny a p\0159edem namontov\00e1ny do vhodn'||-
'\00fdch dr\017e\00e1k\016f s mo\017enost\00ed p\0159ipojov\00e1n'||-
'\00ed za provozu pro okam\017eitou instalaci do va\0161ich podnikov'||-
'\00fdch server\016f nebo syst\00e9m\016f na ukl\00e1d\00e1n\00ed da'||-
't.'-
));
INSERT INTO product_descriptions VALUES(3353-
,'CS'-
,UNISTR(-
'HD 10GB /R'-
),UNISTR(-
'Pevn\00fd disk o kapacit\011b 10 GB pro vym\011bniteln\00e9 jednotky p'||-
'evn\00fdch disk\016f 10 GB. Diskov\00e9 jednotky Supra 7 pou\017e'||-
'\00edvaj\00ed nejnov\011bj\0161\00ed technologii na zlep\0161en'||-
'\00ed v\00fdkonu firmy, zv\00fd\0161en\00ed maxim\00e1ln\00ed rychl'||-
'osti p\0159enosu dat a\017e na 160 MB/sek.'-
));
INSERT INTO product_descriptions VALUES(3069-
,'CS'-
,UNISTR(-
'HD 10GB /S'-
),UNISTR(-
'Pevn\00fd disk o kapacit\011b 10 GB pro standardn\00ed instalaci. Zp'||-
'\011btn\011b kompatibiln\00ed se syst\00e9my Supra 5, u\017eivatel'||-
'\00e9 mohou voln\011b instalovat a p\0159em\00eds\0165ovat tyto disky'||-
' k rychl\00e9mu zv\00fd\0161en\00ed kapacity na ukl\00e1d\00e1n'||-
'\00ed dat. Disky Supra eliminuj\00ed riziko nekompatibility firmwaru.'-
));
INSERT INTO product_descriptions VALUES(2253-
,'CS'-
,UNISTR(-
'HD 10GB @5400 /SE'-
),UNISTR(-
'Pevn\00fd disk o kapacit\011b 10 GB (extern\00ed) s rozhran\00edm SCSI'||-
', 5400 ot./min. Sady s univerz\00e1ln\00ed volbou jsou nakonfigurov'||-
'\00e1ny a p\0159edem namontov\00e1ny do vhodn\00fdch dr\017e\00e1k'||-
'\016f s mo\017enost\00ed p\0159ipojov\00e1n\00ed za provozu pro okam'||-
'\017eitou instalaci do va\0161ich podnikov\00fdch server\016f nebo sys'||-
't\00e9m\016f na ukl\00e1d\00e1n\00ed dat. Disky Supra eliminuj\00ed '||-
'riziko nekompatibility firmwaru.'-
));
INSERT INTO product_descriptions VALUES(3354-
,'CS'-
,UNISTR(-
'HD 12GB /I'-
),UNISTR(-
'Pevn\00fd disk o kapacit\011b 12 GB (intern\00ed). Disky Supra eliminuj'||-
'\00ed riziko nekompatibility firmwaru. Zp\011btn\00e1 kompatibilita. M'||-
'\016f\017eete sm\011b\0161ovat dohromady nebo p\00e1rovat za\0159'||-
'\00edzen\00ed Supra 2 a Supra 3 k dosa\017een\00ed optim\00e1ln\00ed'||-
'ch \0159e\0161en\00ed a pro budouc\00ed r\016fst.'-
));
INSERT INTO product_descriptions VALUES(3072-
,'CS'-
,UNISTR(-
'HD 12GB /N'-
),UNISTR(-
'Pevn\00fd disk o kapacit\011b 12 GB pro tzv. \00fazkou mont\00e1\017e'||-
' (Narrow Mount). Pevn\00e9 disky Supra9, p\0159ipojiteln\00e9 za provoz'||-
'u, poskytuj\00ed mo\017enost instalovat a odstra\0148ovat jednotky on-l'||-
'ine. Na\0161e disky, p\0159ipojiteln\00e9 za provozu, jsou po\017eadov'||-
'\00e1ny z d\016fvodu spln\011bn\00ed p\0159\00edsn\00fdch standard'||-
'\016f pro spolehlivost a v\00fdkon.'-
));
INSERT INTO product_descriptions VALUES(3334-
,'CS'-
,UNISTR(-
'HD 12GB /R'-
),UNISTR(-
'Vym\011bniteln\00fd pevn\00fd disk o kapacit\011b 12 GB. S kompatibili'||-
'tou mezi mnoha podnikov\00fdmi platformami m\016f\017eete voln\011b in'||-
'stalovat a p\0159em\00eds\0165ovat tyto disky k rychl\00e9mu z\00edsk'||-
'\00e1n\00ed kapacity k ukl\00e1d\00e1n\00ed dat. Disky Supra 7 Univer'||-
'sal jsou druhou generac\00ed vysoce v\00fdkonn\00fdch disk\016f, p'||-
'\0159ipojiteln\00fdch za provozu, kompatibiln\00edch s podnikov\00fdmi'||-
' servery a extern\00edmi p\0159\00eddavn\00fdmi za\0159\00edzen'||-
'\00edmi na ukl\00e1d\00e1n\00ed dat.'-
));
INSERT INTO product_descriptions VALUES(3071-
,'CS'-
,UNISTR(-
'HD 12GB /S'-
),UNISTR(-
'Pevn\00fd disk 12 GB pro standardn\00ed mont\00e1\017e (Standard Mount'||-
'). Pevn\00e9 disky Supra 9, p\0159ipojiteln\00e9 za provozu, poskytuj'||-
'\00ed mo\017enost p\0159ipojen\00ed nebo odpojen\00ed disk\016f on-l'||-
'ine. Na\0161e disky, p\0159ipojiteln\00e9 za provozu, jsou po\017eadov'||-
'\00e1ny z d\016fvodu spln\011bn\00ed na\0161ich p\0159\00edsn\00fd'||-
'ch standard\016f na spolehlivost a v\00fdkon.'-
));
INSERT INTO product_descriptions VALUES(2255-
,'CS'-
,UNISTR(-
'HD 12GB @7200 /SE'-
),UNISTR(-
'Pevn\00fd disk o kapacit\011b 12 GB (extern\00ed) SCSI, 7200 ot./min. T'||-
'yto disky jsou ur\010deny pro dne\0161n\00ed n\00e1ro\010dn\00e1 pod'||-
'nikov\00e1 prost\0159ed\00ed, kde je ukl\00e1d\00e1n\00ed dat rozhod'||-
'uj\00edc\00ed, a mohou b\00fdt pou\017eity v aplikac\00edch RAID. Sad'||-
'y s univerz\00e1ln\00ed volbou jsou nakonfigurov\00e1ny a p\0159edem n'||-
'amontov\00e1ny do vhodn\00fdch dr\017e\00e1k\016f s mo\017enost'||-
'\00ed p\0159ipojov\00e1n\00ed za provozu pro okam\017eitou instalaci '||-
'do va\0161ich podnikov\00fdch server\016f nebo syst\00e9m\016f na ukl'||-
'\00e1d\00e1n\00ed dat.'-
));
INSERT INTO product_descriptions VALUES(1743-
,'CS'-
,UNISTR(-
'HD 18.2GB @10000 /E'-
),UNISTR(-
'Extern\00ed pevn\00fd disk - 18,2 GB, s ot\00e1\010dkami a\017e 10000'||-
' ot./min. Tyto disky jsou ur\010deny pro dne\0161n\00ed n\00e1ro\010d'||-
'n\00e1 podnikov\00e1 prost\0159ed\00ed, kde je ukl\00e1d\00e1n\00ed'||-
' dat rozhoduj\00edc\00ed, a jsou ide\00e1ln\00ed pro pou\017eit\00ed'||-
' v aplikac\00edch RAID.'-
));
INSERT INTO product_descriptions VALUES(2382-
,'CS'-
,UNISTR(-
'HD 18.2GB@10000 /I'-
),UNISTR(-
'Pevn\00fd disk 18,2 GB s 10000 ot./min. (intern\00ed). Disky Supra 7 Uni'||-
'versal poskytuj\00ed mimo\0159\00e1dnou \00farove\0148 ochrany invest'||-
'ic a zjednodu\0161en\00ed pro z\00e1kazn\00edky t\00edm, \017ee umo'||-
'\017e\0148uj\00ed kompatibilitu disk\016f pro mnoho podnikov\00fdch p'||-
'latforem.'-
));
INSERT INTO product_descriptions VALUES(3399-
,'CS'-
,UNISTR(-
'HD 18GB /SE'-
),UNISTR(-
'Extern\00ed pevn\00fd disk 18 GB SCSI. Pevn\00e9 disky Supra 5 Universa'||-
'l poskytuj\00ed schopnost p\0159epojov\00e1n\00ed za provozu mezi r'||-
'\016fzn\00fdmi servery, diskov\00fdmi poli a extern\00edmi z\00e1loho'||-
'vac\00edmi za\0159\00edzen\00edmi.'-
));
INSERT INTO product_descriptions VALUES(3073-
,'CS'-
,UNISTR(-
'HD 6GB /I'-
),UNISTR(-
'Pevn\00fd disk o kapacit\011b 6 GB (intern\00ed). Disky Supra eliminuj'||-
'\00ed riziko nekompatibility firmwaru.'-
));
INSERT INTO product_descriptions VALUES(1768-
,'CS'-
,UNISTR(-
'HD 8.2GB @5400'-
),UNISTR(-
'Pevn\00fd disk - 8,2 GB, s ot\00e1\010dkami a\017e 5400 ot./min. Disky'||-
' Supra eliminuj\00ed riziko nekompatibility firmwaru. Standardn\00ed s'||-
'\00e9riov\00e9 rozhran\00ed RS-232.'-
));
INSERT INTO product_descriptions VALUES(2410-
,'CS'-
,UNISTR(-
'HD 8.4GB @5400'-
),UNISTR(-
'Pevn\00fd disk 8,4 GB s ot\00e1\010dkami 5400 ot./min. Sn\00ed\017een'||-
'\00e9 n\00e1klady: disky mohou b\00fdt pou\017eity na v\0161ech podni'||-
'kov\00fdch platform\00e1ch. Tento disk, p\0159ipojiteln\00fd za provoz'||-
'u, je po\017eadov\00e1n z d\016fvodu spln\011bn\00ed va\0161ich p'||-
'\0159\00edsn\00fdch standard\016f na spolehlivost a v\00fdkon.'-
));
INSERT INTO product_descriptions VALUES(2257-
,'CS'-
,UNISTR(-
'HD 8GB /I'-
),UNISTR(-
'Pevn\00fd disk s kapacitou 8 GB (intern\00ed). Pevn\00e9 disky Supra9, '||-
'p\0159ipojiteln\00e9 za provozu, poskytuj\00ed mo\017enost p\0159ipoj'||-
'en\00ed nebo odpojen\00ed disk\016f on-line. Zp\011btn\00e1 kompatibi'||-
'lita. Pro optimalizovan\00e9 \0159e\0161en\00ed a budouc\00ed r\016f'||-
'st m\016f\017eete pou\017e\00edvat dohromady za\0159\00edzen\00ed S'||-
'upra2 a Supra3.'-
));
INSERT INTO product_descriptions VALUES(3400-
,'CS'-
,UNISTR(-
'HD 8GB /SE'-
),UNISTR(-
'Pevn\00fd disk o kapacit\011b 8 GB SCSI (extern\00ed). Disky Supra7 sk'||-
'\00fdtaj\00ed nejnov\011bj\0161\00ed technologii ke zlep\0161en'||-
'\00ed v\00fdkonu firmy zv\00fd\0161en\00edm maxim\00e1ln\00ed rychl'||-
'osti p\0159enosu dat a\017e 255 MB/sec.'-
));
INSERT INTO product_descriptions VALUES(3355-
,'CS'-
,UNISTR(-
'HD 8GB /SI'-
),UNISTR(-
'Pevn\00fd disk 8 GB SCSI, intern\00ed. S kompatibilitou pro mnoho podnik'||-
'ov\00fdch platforem m\016f\017eete voln\011b instalovat a p\0159em'||-
'\00eds\0165ovat tyto disky tak, aby poskytovaly zv\00fd\0161enou kapac'||-
'itu ukl\00e1d\00e1n\00ed dat.'-
));
INSERT INTO product_descriptions VALUES(1772-
,'CS'-
,UNISTR(-
'HD 9.1GB @10000'-
),UNISTR(-
'Pevn\00fd disk - 9,1 GB, pracuj\00edc\00ed p\0159i 10000 ot./min. Tyto'||-
' disky jsou ur\010deny pro pou\017eit\00ed v podnikov\00fdch prost'||-
'\0159ed\00edch, kde je rozhoduj\00edc\00ed p\0159enos dat. Snadnost p'||-
'rov\00e1d\011bn\00ed \00fakolu: m\016f\017eete snadno vybrat disky, '||-
'kter\00e9 pot\0159ebujete, bez ohledu na aplikaci, pro kterou budou pou'||-
'\017eity.'-
));
INSERT INTO product_descriptions VALUES(2414-
,'CS'-
,UNISTR(-
'HD 9.1GB @10000 /I'-
),UNISTR(-
'Pevn\00fd disk 9,1 GB, pracuj\00edc\00ed p\0159i 10000 ot./min. (vnit'||-
'\0159n\00ed). Disky Supra7 jsou dod\00e1v\00e1ny s ot\00e1\010dkami '||-
'h\0159\00eddele 10000 ot./min. a kapacitami 18 GB a 9,1 GB a s rohran'||-
'\00edmi RS-232.'-
));
INSERT INTO product_descriptions VALUES(2415-
,'CS'-
,UNISTR(-
'HD 9.1GB @7200'-
),UNISTR(-
'Pevn\00fd disk 9,1 GB, pracuj\00edc\00ed p\0159i ot\00e1\010dk\00e1'||-
'ch 7200 ot./min.. Sady s univerz\00e1ln\00ed volbou jsou nakonfigurov'||-
'\00e1ny a p\0159edem namontov\00e1ny ve vhodn\00fdch pouzdrech pro oka'||-
'm\017eitou instalaci do va\0161ich podnikov\00fdch server\016f nebo sy'||-
'st\00e9m\016f pro ukl\00e1d\00e1n\00ed dat.'-
));
INSERT INTO product_descriptions VALUES(2395-
,'CS'-
,UNISTR(-
'32 MB vyrovn\00e1vac\00ed pam\011b\0165 /M'-
),UNISTR(-
'32 MB zrcadlen\00e1 vyrovn\00e1vac\00ed pam\011b\0165 (100-MHz SDRAM '||-
's registrem)'-
));
INSERT INTO product_descriptions VALUES(1755-
,'CS'-
,UNISTR(-
'32 MB vyrovn\00e1vac\00ed pam\011b\0165 /NM'-
),UNISTR(-
'32 MB nezrcadlen\00e1 vyrovn\00e1vac\00ed pam\011b\0165'-
));
INSERT INTO product_descriptions VALUES(2406-
,'CS'-
,UNISTR(-
'64 MB vyrovn\00e1vac\00ed pam\011b\0165 /M'-
),UNISTR(-
'64 MB zrcadlen\00e1 vyrovn\00e1vac\00ed pam\011b\0165'-
));
INSERT INTO product_descriptions VALUES(2404-
,'CS'-
,UNISTR(-
'64 MB vyrovn\00e1vac\00ed pam\011b\0165 /NM'-
),UNISTR(-
'64 MB nezrcadlen\00e1 vyrovn\00e1vac\00ed pam\011b\0165. Pam\011b'||-
'\0165ov\00e9 \010dipy FPM jsou realizov\00e1ny na 5 voltov\00fdch mod'||-
'ulech SIMM, ale jsou dod\00e1v\00e1ny tak\00e9 na 3,3 voltov\00fdch mo'||-
'dulech DIMM.'-
));
INSERT INTO product_descriptions VALUES(1770-
,'CS'-
,UNISTR(-
'8 MB vyrovn\00e1vac\00ed pam\011b\0165 /NM'-
),UNISTR(-
'8 MB nezrcadlen\00e1 vyrovn\00e1vac\00ed pam\011b\0165 (100-MHz SDRAM'||-
' s registrem)'-
));
INSERT INTO product_descriptions VALUES(2412-
,'CS'-
,UNISTR(-
'8 MB pam\011b\0165 EDO'-
),UNISTR(-
'Pam\011b\0165 8 MB 8 x 32 EDO SIM. Pam\011b\0165 typu EDO (Extended Da'||-
'ta Out) se li\0161\00ed od pam\011bti typu FPM v mal\00fdch, ale podst'||-
'atn\00fdch konstruk\010dn\00edch zm\011bn\00e1ch. Na rozd\00edl od t'||-
'ypu FPM, ovlada\010de na v\00fdstup dat pro EDO z\016fst\00e1vaj\00ed'||-
' zapnuty, kdy\017e \0159adi\010d pam\011bti odstra\0148uje adresu slo'||-
'upce p\0159ed zapo\010det\00edm n\00e1sleduj\00edc\00edho cyklu. Pro'||-
'to m\016f\017ee za\010d\00edt nov\00fd datov\00fd cyklus p\0159edt'||-
'\00edm, ne\017e je dokon\010den p\0159edchoz\00ed datov\00fd cyklus.'||-
' EDO se dod\00e1v\00e1 na modulech SIMM a DIMM, v proveden\00ed 3,3 V a'||-
' 5 V.'-
));
INSERT INTO product_descriptions VALUES(2378-
,'CS'-
,UNISTR(-
'DIMM - 128 MB'-
),UNISTR(-
'Pam\011b\0165 128 MB DIMM. Hlavn\00ed d\016fvod pro zm\011bnu ze SIMM'||-
' na DIMM je podpora v\011bt\0161\00ed \0161\00ed\0159ky sb\011brnic'||-
'e 64-bitov\00fdch procesor\016f. DIMM pam\011bti maj\00ed \0161\00ed'||-
'\0159ku 64 nebo 72 bit\016f; pam\011bti SIMM maj\00ed \0161\00ed'||-
'\0159ku jen 32 nebo 36 bit\016f (s paritou).'-
));
INSERT INTO product_descriptions VALUES(3087-
,'CS'-
,UNISTR(-
'DIMM - 16 MB'-
),UNISTR(-
'Citrus OLX DIMM - kapacita 16 MB.'-
));
INSERT INTO product_descriptions VALUES(2384-
,'CS'-
,UNISTR(-
'DIMM - 1GB'-
),UNISTR(-
'Pam\011b\0165 DIMM: RAM - kapacita 1 GB.'-
));
INSERT INTO product_descriptions VALUES(1749-
,'CS'-
,UNISTR(-
'DIMM - 256MB'-
),UNISTR(-
'Pam\011b\0165 DIMM: RAM 256 MB. (100-MHz SDRAM s registrem)'-
));
INSERT INTO product_descriptions VALUES(1750-
,'CS'-
,UNISTR(-
'DIMM - 2GB'-
),UNISTR(-
'Pam\011b\0165 DIMM: RAM, kapacita 2 GB.'-
));
INSERT INTO product_descriptions VALUES(2394-
,'CS'-
,UNISTR(-
'DIMM - 32MB'-
),UNISTR(-
'32 MB roz\0161\00ed\0159en\00ed pam\011bti DIMM'-
));
INSERT INTO product_descriptions VALUES(2400-
,'CS'-
,UNISTR(-
'DIMM - 512 MB'-
),UNISTR(-
'Pam\011b\0165 512 MB DIMM. Zdokonalen\00e1 granularita roz\0161\00ed'||-
'\0159en\00ed pam\011bti. K roz\0161\00ed\0159en\00ed syst\00e9mu j'||-
'e po\017eadov\00e1no m\00e9n\011b pam\011bt\00ed DIMM ne\017e by by'||-
'lo nutn\00e9 k roz\0161\00ed\0159en\00ed stejn\00e9ho syst\00e9mu p'||-
'omoc\00ed SIMM pam\011bt\00ed. Zv\011bt\0161en\00e1 hranice maxim'||-
'\00e1ln\00ed pam\011bti: P\0159i dan\00e9m stejn\00e9m po\010dtu pa'||-
'm\011b\0165ov\00fdch slot\016f je hranice maxim\00e1ln\00ed pam'||-
'\011bti syst\00e9mu p\0159i pou\017eit\00ed DIMM pam\011bt\00ed v'||-
'\011bt\0161\00ed ne\017e p\0159i pou\017eit\00ed pam\011bt\00ed S'||-
'IMM. Pam\011bti DIMM maj\00ed samostatn\00e9 kontakty na ka\017ed'||-
'\00e9 stran\011b desky, kter\00e9 poskytuj\00ed dvojn\00e1sobn\00e9 '||-
'rychlosti p\0159enosu dat ne\017e pam\011bti SIMM.'-
));
INSERT INTO product_descriptions VALUES(1763-
,'CS'-
,UNISTR(-
'DIMM - 64MB'-
),UNISTR(-
'Pam\011b\0165 DIMM: RAM, 64 MB (100-MHz ECC SDRAM bez registr\016f)'-
));
INSERT INTO product_descriptions VALUES(2396-
,'CS'-
,UNISTR(-
'EDO - 32MB'-
),UNISTR(-
'Pam\011b\0165 EDO SIM: RAM, 32 MB (100-MHz ECC SDRAM bez registr\016f).'||-
' Tak jako FPM, EDO se dod\00e1v\00e1 na modulech SIMM a DIMM, v proveden'||-
'\00ed 3,3 a 5 V. Jestli\017ee je pam\011b\0165 EDO instalov\00e1na do'||-
' po\010d\00edta\010de, kter\00fd nebyl navr\017een pro jej\00ed podp'||-
'oru, nemus\00ed pam\011b\0165 pracovat.'-
));
INSERT INTO product_descriptions VALUES(2272-
,'CS'-
,UNISTR(-
'RAM - 16 MB'-
),UNISTR(-
'Pam\011b\0165 SIMM: RAM - kapacita 16 MB.'-
));
INSERT INTO product_descriptions VALUES(2274-
,'CS'-
,UNISTR(-
'RAM - 32 MB'-
),UNISTR(-
'Pam\011b\0165 SIMM: RAM - kapacita 32 MB.'-
));
INSERT INTO product_descriptions VALUES(3090-
,'CS'-
,UNISTR(-
'RAM - 48 MB'-
),UNISTR(-
'Pam\011b\0165 s p\0159\00edm\00fdm p\0159\00edstupem (RAM), SIMM - '||-
'kapacita 48 MB.'-
));
INSERT INTO product_descriptions VALUES(1739-
,'CS'-
,UNISTR(-
'SDRAM - 128 MB'-
),UNISTR(-
'Pam\011b\0165 SDRAM, kapacita 128 MB. SDRAM m\016f\017ee m\00edt kmit'||-
'o\010det p\0159\00edstupu k dat\016fm a\017e 100 MHz, co\017e je a'||-
'\017e \010dty\0159ikr\00e1t rychlej\0161\00ed ne\017e u standardn'||-
'\00ed DRAM. V\00fdhody pam\011bt\00ed SDRAM mohou b\00fdt pln\011b v'||-
'yu\017eity, ale jen u po\010d\00edta\010d\016f, navr\017een\00fdch '||-
'na podporu pam\011bt\00ed SDRAM. Pam\011bti SDRAM se dod\00e1vaj\00ed'||-
' na modulech DIMM pro nap\011bt\00ed 5 V a 3,3 V.'-
));
INSERT INTO product_descriptions VALUES(3359-
,'CS'-
,UNISTR(-
'SDRAM - 16 MB'-
),UNISTR(-
'Pam\011b\0165ov\00fd modul SDRAM na roz\0161\00ed\0159en\00ed pam'||-
'\011bti, 16 MB. Pam\011b\0165 SDRAM (synchronn\00ed dynamick\00e1 pam'||-
'\011b\0165 s p\0159\00edm\00fdm p\0159\00edstupem) byla zavedena po'||-
' pam\011btech EDO. Jej\00ed architektura a funkce jsou zalo\017eeny na '||-
'standardu DRAM, ale SDRAM poskytuje revolu\010dn\00ed zm\011bnu v hlavn'||-
'\00ed pam\011bti, co\017e d\00e1le sni\017euje dobu vybavov\00e1n'||-
'\00ed dat. SDRAM je synchronizov\00e1na se syst\00e9mov\00fdmi hodinam'||-
'i, kter\00e9 \0159\00edd\00ed CPU. To znamen\00e1, \017ee syst\00e9'||-
'mov\00e9 hodiny, \0159\00edd\00edc\00ed funkce mikroprocesoru \0159'||-
'\00edd\00ed tak\00e9 funkce pam\011bti SDRAM. To umo\017en\00ed '||-
'\0159adi\010di pam\011bti v\011bd\011bt, na kter\00e9m cyklu hodin b'||-
'ude p\0159ipraven po\017eadavek na data a proto eliminuje \010dasov'||-
'\00e1 zpo\017ed\011bn\00ed.'-
));
INSERT INTO product_descriptions VALUES(3088-
,'CS'-
,UNISTR(-
'SDRAM - 32 MB'-
),UNISTR(-
'Modul SDRAM s ECC - kapacita 32 MB. Pam\011b\0165 SDRAM m\00e1 v\00edc'||-
'en\00e1sobn\00e9 pam\011b\0165ov\00e9 bloky, kter\00e9 mohou pracova'||-
't sou\010dasn\011b. P\0159ep\00edn\00e1n\00ed mezi bloky umo\017e'||-
'\0148uje kontinu\00e1ln\00ed tok dat.'-
));
INSERT INTO product_descriptions VALUES(2276-
,'CS'-
,UNISTR(-
'SDRAM - 48 MB'-
),UNISTR(-
'Pam\011b\0165 SIMM: RAM - 48 MB. Pam\011b\0165 SDRAM m\016f\017ee pr'||-
'acovat ve shlukov\00e9m (n\00e1razov\00e9m) re\017eimu (burst mode). V'||-
' tomto re\017eimu, kdy\017e je dosa\017eeno jedn\00e9 datov\00e9 adre'||-
'sy, na\010dte se cel\00fd blok dat nam\00edsto jen jedn\00e9 \010d'||-
'\00e1sti. P\0159edpokladem je, \017ee n\00e1sleduj\00edc\00ed \010d'||-
'\00e1st dat, kter\00e1 bude po\017eadov\00e1na, bude n\00e1sledovat z'||-
'a p\0159edchoz\00ed. Proto\017ee to tak obvykle je, jsou data rychle do'||-
'stupn\00e1.'-
));
INSERT INTO product_descriptions VALUES(3086-
,'CS'-
,UNISTR(-
'VRAM - 16 MB'-
),UNISTR(-
'Modul Citrus Video RAM - kapacita 16 MB. VRAM je pou\017e\00edv\00e1na '||-
'video syst\00e9my v po\010d\00edta\010di k ukl\00e1d\00e1n\00ed vid'||-
'eo informac\00ed a je rezervov\00e1na v\00fdhradn\011b pro video opera'||-
'ce. Byla vyvinuta proto, aby umo\017e\0148ovala kontinu\00e1ln\00ed pr'||-
'oud s\00e9riov\00fdch dat pro obnovu video obrazovky.'-
));
INSERT INTO product_descriptions VALUES(3091-
,'CS'-
,UNISTR(-
'VRAM - 64 MB'-
),UNISTR(-
'Pam\011b\0165ov\00fd modul Citrus Video RAM - kapacita 64 MB. Fyzicky v'||-
'ypad\00e1 VRAM \00fapln\011b stejn\011b jako DRAM s p\0159idan\00fdm'||-
' hardwarem naz\00fdvan\00fdm posouvac\00ed registr. Speci\00e1ln\00ed'||-
' vlastnost\00ed pam\011bti VRAM je, \017ee m\016f\017ee p\0159en'||-
'\00e9st jednu celou \0159adu dat (a\017e 256 bit\016f) do tohoto posou'||-
'vac\00edho registru v jednom cyklu hodin. Tato schopnost v\00fdznamn'||-
'\011b sni\017euje vybavovac\00ed dobu, proto\017ee po\010det p\0159'||-
'\00edstup\016f je sn\00ed\017een z mo\017en\00fdch 256 na jeden p'||-
'\0159\00edstup. Hlavn\00ed v\00fdhodou dostupnosti posouvac\00edho re'||-
'gistru pro ulo\017een\00ed dat je, \017ee uvoln\00ed CPU pro obnovov'||-
'\00e1n\00ed obrazovky nam\00edsto na\010d\00edt\00e1n\00ed dat a t'||-
'\00edm se zdvojn\00e1sob\00ed \0161\00ed\0159ka p\00e1sma dat. Z to'||-
'hoto d\016fvodu se \010dasto mluv\00ed o pam\011bti VRAM jako o dvoupo'||-
'rtov\00e9 (dvoubr\00e1nov\00e9). Av\0161ak posouvac\00ed registr bude'||-
' pou\017eit jen tehdy, kdy\017e \010dip pam\011bti VRAM dostane speci'||-
'\00e1ln\00ed instrukci na prov\00e1d\011bn\00ed t\00e9to funkce. P'||-
'\0159\00edkaz na pou\017eit\00ed posouvac\00edho registru je vestav'||-
'\011bn v grafick\00fdch \0159adi\010d\00edch.'-
));
INSERT INTO product_descriptions VALUES(1787-
,'CS'-
,UNISTR(-
'CPU D300'-
),UNISTR(-
'Du\00e1ln\00ed CPU na 300 Mhz. Jen pro nen\00e1ro\010dn\00e9 procesy '||-
'nebo souborov\00e9 servery s m\00e9n\011b ne\017e p\011bti p\0159ipo'||-
'jen\00fdmi u\017eivateli. Tento produkt brzy pravd\011bpodobn\011b zas'||-
'tar\00e1.'-
));
INSERT INTO product_descriptions VALUES(2439-
,'CS'-
,UNISTR(-
'CPU D400'-
),UNISTR(-
'Du\00e1ln\00ed CPU na 400 Mhz. M\00e1 dobr\00fd pom\011br cena/v'||-
'\00fdkon; pro st\0159edn\00ed souborov\00e9 servery LAN (a\017e 100 p'||-
'\0159ipojen\00fdch u\017eivatel\016f).'-
));
INSERT INTO product_descriptions VALUES(1788-
,'CS'-
,UNISTR(-
'CPU D600'-
),UNISTR(-
'Du\00e1ln\00ed CPU na 600 Mhz. Nejnov\011bj\0161\00ed technologie, vy'||-
'sok\00fd taktovac\00ed kmito\010det; pro velmi zat\00ed\017een\00e9 '||-
'servery WAN (a\017e 200 p\0159ipojen\00fdch u\017eivatel\016f).'-
));
INSERT INTO product_descriptions VALUES(2375-
,'CS'-
,UNISTR(-
'GP 1024x768'-
),UNISTR(-
'Grafick\00fd procesor, rozli\0161en\00ed 1024 x 768 pixel\016f. Vynika'||-
'j\00edc\00ed pom\011br cena/v\00fdkon pro 2D a 3D aplikace pod SPNIX v'||-
'. 3.3 a v. 4.0. Zdvojn\00e1sob\00ed va\0161i prohl\00ed\017eec\00ed '||-
'schopnost t\00edm, \017ee ovl\00e1d\00e1 dva monitory z t\00e9to jedn'||-
'\00e9 karty. Dva 17-ti palcov\00e9 monitory maj\00ed v\011bt\0161'||-
'\00ed plochu obrazovky ne\017e jeden 21-ti palcov\00fd. Vynikaj\00edc'||-
'\00ed volba pro u\017eivatele, kte\0159\00ed \010dasto zpracov\00e1v'||-
'aj\00ed n\011bkolik \00faloh nebo \010dasto pot\0159ebuj\00ed p'||-
'\0159\00edstup k n\011bkolika zdroj\016fm dat.'-
));
INSERT INTO product_descriptions VALUES(2411-
,'CS'-
,UNISTR(-
'GP 1280x1024'-
),UNISTR(-
'Grafick\00fd procesor, rozli\0161en\00ed 1280 x 1024 pixel\016f. Vysok'||-
'\00fd v\00fdkon pro 3D \00falohy p\0159i st\0159edn\00ed cen\011b: '||-
'15 milion\016f Gouraudov\00fdch st\00ednovan\00fdch troj\00faheln'||-
'\00edk\016f za sekundu. Optimalizovan\00e9 3D ovlada\010de pro aplikac'||-
'e MCAD a DCC s nastaven\00edm p\0159izp\016fsobiteln\00fdm u\017eivat'||-
'eli. Unifikovan\00e1 obrazov\00e1 pam\011b\0165 64 MB DDR SDRAM, podpo'||-
'ruj\00edc\00ed skute\010dn\00e9 barvy (true clolor) p\0159i v\0161ec'||-
'h podporovan\00fdch standardn\00edch rozli\0161en\00edch.'-
));
INSERT INTO product_descriptions VALUES(1769-
,'CS'-
,UNISTR(-
'GP 800x600'-
),UNISTR(-
'Grafick\00fd procesor, rozli\0161en\00ed 800 x 600 pixel\016f. Pozoruh'||-
'odn\00e1 hodnota pro u\017eivatele, po\017eaduj\00edc\00ed vysok'||-
'\00fd v\00fdkon pro 2D \00falohy nebo v\0161eobecnou podporu pro n'||-
'\00e1ro\010dn\00e9 aplikace 3D. Poskytuje vynikaj\00edc\00ed v\00fdk'||-
'on u velmi slo\017eit\00fdch model\016f a umo\017e\0148uje u\017eiva'||-
'tel\016fm, aby se zam\011b\0159ili na n\00e1vrh nam\00edsto na proces'||-
' vizualizace (rendering).'-
));
INSERT INTO product_descriptions VALUES(2049-
,'CS'-
,UNISTR(-
'MB - S300'-
),UNISTR(-
'Z\00e1kladn\00ed deska typu PC, s\00e9rie 300.'-
));
INSERT INTO product_descriptions VALUES(2751-
,'CS'-
,UNISTR(-
'MB - S450'-
),UNISTR(-
'Z\00e1kladn\00ed deska typu PC, s\00e9rie 450.'-
));
INSERT INTO product_descriptions VALUES(3112-
,'CS'-
,UNISTR(-
'MB - S500'-
),UNISTR(-
'Z\00e1kladn\00ed deska typu PC, s\00e9rie 500.'-
));
INSERT INTO product_descriptions VALUES(2752-
,'CS'-
,UNISTR(-
'MB - S550'-
),UNISTR(-
'Z\00e1kladn\00ed deska typu PC pro s\00e9rie 550.'-
));
INSERT INTO product_descriptions VALUES(2293-
,'CS'-
,UNISTR(-
'MB - S600'-
),UNISTR(-
'Z\00e1kladn\00ed deska s\00e9rie 600.'-
));
INSERT INTO product_descriptions VALUES(3114-
,'CS'-
,UNISTR(-
'MB - S900/650+'-
),UNISTR(-
'Z\00e1kladn\00ed deska PC, s\00e9rie 900; standardn\00ed z\00e1kladn'||-
'\00ed deska pro v\0161echny modely 650 a vy\0161\0161\00ed.'-
));
INSERT INTO product_descriptions VALUES(3129-
,'CS'-
,UNISTR(-
'Zvukov\00e1 karta STD'-
),UNISTR(-
'Zvukov\00e1 karta - standardn\00ed verze s rozhran\00edm MIDI, s p'||-
'\0159ipojen\00edm vstupu/v\00fdstupu (line in/out), se vstupem pro n'||-
'\00edzkoimpedan\010dn\00ed mikrofon.'-
));
INSERT INTO product_descriptions VALUES(3133-
,'CS'-
,UNISTR(-
'Video karta /32'-
),UNISTR(-
'Video karta, s vyrovn\00e1vac\00ed pam\011bt\00ed 32 MB.'-
));
INSERT INTO product_descriptions VALUES(2308-
,'CS'-
,UNISTR(-
'Video karta /E32'-
),UNISTR(-
'Video karta 3-D ELSA s pam\011bt\00ed 32 MB.'-
));
INSERT INTO product_descriptions VALUES(2496-
,'CS'-
,UNISTR(-
'WSP DA-130'-
),UNISTR(-
'Procesor pro rozs\00e1hl\00e9 ukl\00e1d\00e1n\00ed DA-130 pro ukl'||-
'\00e1d\00e1n\00ed podjednotek.'-
));
INSERT INTO product_descriptions VALUES(2497-
,'CS'-
,UNISTR(-
'WSP DA-290'-
),UNISTR(-
'Procesor pro rozs\00e1hl\00e9 ukl\00e1d\00e1n\00ed (model DA-290).'-
));
INSERT INTO product_descriptions VALUES(3106-
,'CS'-
,UNISTR(-
'KB 101/EN'-
),UNISTR(-
'Standardn\00ed roz\0161\00ed\0159en\00e1 kl\00e1vesnice PC/AT (101/1'||-
'02-kl\00e1ves). Proveden\00ed: anglick\00e1 (US).'-
));
INSERT INTO product_descriptions VALUES(2289-
,'CS'-
,UNISTR(-
'KB 101/ES'-
),UNISTR(-
'Standardn\00ed roz\0161\00ed\0159en\00e1 kl\00e1vesnice PC/AT (101/1'||-
'02-kl\00e1ves). Proveden\00ed: \0161pan\011blsk\00e1.'-
));
INSERT INTO product_descriptions VALUES(3110-
,'CS'-
,UNISTR(-
'KB 101/FR'-
),UNISTR(-
'Standardn\00ed roz\0161\00ed\0159en\00e1 kl\00e1vesnice PC/AT (101/1'||-
'02-kl\00e1ves). Proveden\00ed: francouzsk\00e1.'-
));
INSERT INTO product_descriptions VALUES(3108-
,'CS'-
,UNISTR(-
'KB E/EN'-
),UNISTR(-
'Ergonomick\00e1 kl\00e1vesnice se dv\011bma samostatn\00fdmi oblastmi,'||-
' odd\011blitelnou numerickou kl\00e1vesnic\00ed. Rozlo\017een\00ed kl'||-
'\00e1ves: anglick\00e9 (US).'-
));
INSERT INTO product_descriptions VALUES(2058-
,'CS'-
,UNISTR(-
'My\0161 +WP'-
),UNISTR(-
'Kombinace my\0161i a podlo\017eky z\00e1p\011bst\00ed pro pohodln'||-
'\011bj\0161\00ed psan\00ed a operace s my\0161\00ed.'-
));
INSERT INTO product_descriptions VALUES(2761-
,'CS'-
,UNISTR(-
'My\0161 +WP/CL'-
),UNISTR(-
'Souprava, sest\00e1vaj\00edc\00ed z my\0161i a podlo\017eky pod z'||-
'\00e1p\011bst\00ed s podnikov\00fdm logem.'-
));
INSERT INTO product_descriptions VALUES(3117-
,'CS'-
,UNISTR(-
'My\0161 C/E'-
),UNISTR(-
'Ergonomick\00e1 bezdr\00e1tov\00e1 my\0161. S kuli\010dkou pro maxim'||-
'\00e1ln\00ed pohodl\00ed a snadn\00e9 pou\017eit\00ed.'-
));
INSERT INTO product_descriptions VALUES(2056-
,'CS'-
,UNISTR(-
'Podlo\017eka pod my\0161 /CL'-
),UNISTR(-
'Standardn\00ed podlo\017eka pod my\0161 s podnikov\00fdm logem.'-
));
INSERT INTO product_descriptions VALUES(2211-
,'CS'-
,UNISTR(-
'Podlo\017eka pod z\00e1p\011bst\00ed'-
),UNISTR(-
'P\011bnov\00fd p\00e1s na podporu va\0161ich z\00e1p\011bst\00ed p'||-
'\0159i pou\017eit\00ed kl\00e1vesnice.'-
));
INSERT INTO product_descriptions VALUES(2944-
,'CS'-
,UNISTR(-
'Podlo\017eka pod z\00e1p\011bst\00ed /CL'-
),UNISTR(-
'Podlo\017eka pod z\00e1p\011bst\00ed s podnikov\00fdm logem'-
));
INSERT INTO product_descriptions VALUES(1742-
,'CS'-
,UNISTR(-
'CD-ROM 500/16x'-
),UNISTR(-
'CD mechanika, jen pro \010dten\00ed, rychlost 16x, maxim\00e1ln\00ed k'||-
'apacita 500 MB.'-
));
INSERT INTO product_descriptions VALUES(2402-
,'CS'-
,UNISTR(-
'CD-ROM 600/E/24x'-
),UNISTR(-
'Extern\00ed mechanika CD-ROM 600 MB s rychlost\00ed 24x (jen pro \010dt'||-
'en\00ed).'-
));
INSERT INTO product_descriptions VALUES(2403-
,'CS'-
,UNISTR(-
'CD-ROM 600/I/24x'-
),UNISTR(-
'Intern\00ed mechanika CD-ROM 600 MB, jen pro \010dten\00ed, rychlost '||-
'\010dten\00ed 24x.'-
));
INSERT INTO product_descriptions VALUES(1761-
,'CS'-
,UNISTR(-
'CD-ROM 600/I/32x'-
),UNISTR(-
'Intern\00ed mechanika CD-ROM 600 MB, rychlost 32x (jen pro \010dten'||-
'\00ed).'-
));
INSERT INTO product_descriptions VALUES(2381-
,'CS'-
,UNISTR(-
'CD-ROM 8x'-
),UNISTR(-
'Zapisovac\00ed mechanika CD, jen pro \010dten\00ed, rychlost 8x'-
));
INSERT INTO product_descriptions VALUES(2424-
,'CS'-
,UNISTR(-
'CDW 12/24'-
),UNISTR(-
'Zapisovac\00ed mechanika CD, rychlost 12x pro z\00e1pis, 24x pro \010dt'||-
'en\00ed. Varov\00e1n\00ed: velmi brzy zastar\00e1; tato rychlost ji'||-
'\017e nen\00ed dostate\010dn\00e1 a jsou k dispozici lep\0161\00ed a'||-
'lternativy za p\0159ijatelnou cenu.'-
));
INSERT INTO product_descriptions VALUES(1781-
,'CS'-
,UNISTR(-
'CDW 20/48/E'-
),UNISTR(-
'Zapisovac\00ed mechanika CD, rychlost \010dten\00ed 48x, rychlost z'||-
'\00e1pisu 20x'-
));
INSERT INTO product_descriptions VALUES(2264-
,'CS'-
,UNISTR(-
'CDW 20/48/I'-
),UNISTR(-
'Mechanika CD-ROM: rychlost \010dten\00ed 48x, z\00e1pisu 20x (intern'||-
'\00ed)'-
));
INSERT INTO product_descriptions VALUES(2260-
,'CS'-
,UNISTR(-
'DFD 1.44/3.5'-
),UNISTR(-
'Dvojit\00e1 disketov\00e1 mechanika - 1,44 MB - 3,5 palce'-
));
INSERT INTO product_descriptions VALUES(2266-
,'CS'-
,UNISTR(-
'DVD 12x'-
),UNISTR(-
'Mechanika DVD-ROM: rychlost 12x'-
));
INSERT INTO product_descriptions VALUES(3077-
,'CS'-
,UNISTR(-
'DVD 8x'-
),UNISTR(-
'Mechanika DVD - ROM, rychlost 8x. Zastar\00e1 pravd\011bpodobn\011b vel'||-
'mi brzo...'-
));
INSERT INTO product_descriptions VALUES(2259-
,'CS'-
,UNISTR(-
'FD 1.44/3.5'-
),UNISTR(-
'Disketov\00e1 mechanika - kapacita 1,44 MB s vysokou hustotou - \0161asi'||-
' 3,5 palce'-
));
INSERT INTO product_descriptions VALUES(2261-
,'CS'-
,UNISTR(-
'FD 1.44/3.5/E'-
),UNISTR(-
'Disketov\00e1 mechanika - kapacita 1,44 MB (vysok\00e1 hustota) - 3,5 pa'||-
'lce (extern\00ed)'-
));
INSERT INTO product_descriptions VALUES(3082-
,'CS'-
,UNISTR(-
'Modem - 56/90/E'-
),UNISTR(-
'Modem - 56kb/sek., vyhovuj\00edc\00ed v.90 PCI Global. Extern\00ed; pro'||-
' nap\00e1jen\00ed 110 V.'-
));
INSERT INTO product_descriptions VALUES(2270-
,'CS'-
,UNISTR(-
'Modem - 56/90/I'-
),UNISTR(-
'Modem - 56kb/sek. vyhovuj\00edc\00ed v.90 PCI Global. Intern\00ed, pro '||-
'standardn\00ed \0161asi (3,5 palce).'-
));
INSERT INTO product_descriptions VALUES(2268-
,'CS'-
,UNISTR(-
'Modem - 56/H/E'-
),UNISTR(-
'Standardn\00ed modem kompatibiln\00ed s Hayes - 56kb/sek., extern\00ed.'||-
' Nap\00e1jen\00ed: 220 V.'-
));
INSERT INTO product_descriptions VALUES(3083-
,'CS'-
,UNISTR(-
'Modem - 56/H/I'-
),UNISTR(-
'Standardn\00ed Hayes modem - 56kb/sek., intern\00ed, pro standardn\00ed'||-
' \0161asi 3,5 palce.'-
));
INSERT INTO product_descriptions VALUES(2374-
,'CS'-
,UNISTR(-
'Modem - C/100'-
),UNISTR(-
'Kabel extern\00edho modemu, vyhovuj\00edc\00ed DOCSIS/EURODOCSIS 1.0/1.'||-
'1'-
));
INSERT INTO product_descriptions VALUES(1740-
,'CS'-
,UNISTR(-
'TD 12GB/DAT'-
),UNISTR(-
'P\00e1skov\00e1 jednotka - kapacita 12 gigabyt\016f, form\00e1t DAT.'-
));
INSERT INTO product_descriptions VALUES(2409-
,'CS'-
,UNISTR(-
'TD 7GB/8'-
),UNISTR(-
'P\00e1skov\00e1 jednotka, kapacita 7 GB, kazeta s p\00e1skou o \0161'||-
'\00ed\0159ce 8 mm.'-
));
INSERT INTO product_descriptions VALUES(2262-
,'CS'-
,UNISTR(-
'ZIP 100'-
),UNISTR(-
'Mechanika disket ZIP, kapacita 100 MB (extern\00ed) plus kabel pro p'||-
'\0159ipojen\00ed do paraleln\00edho portu'-
));
INSERT INTO product_descriptions VALUES(2522-
,'CS'-
,UNISTR(-
'Baterie - EL'-
),UNISTR(-
'Baterie s prodlou\017eenou \017eivotnost\00ed pro p\0159enosn\00e9 po'||-
'\010d\00edta\010de'-
));
INSERT INTO product_descriptions VALUES(2278-
,'CS'-
,UNISTR(-
'Baterie - NiHM'-
),UNISTR(-
'Nab\00edjec\00ed baterie NiHM pro p\0159enosn\00e9 po\010d\00edta'||-
'\010de'-
));
INSERT INTO product_descriptions VALUES(2418-
,'CS'-
,UNISTR(-
'Bateriov\00e9 z\00e1lohov\00e1n\00ed (DA-130)'-
),UNISTR(-
'Nab\00edje\010dka pro jednu baterii s indik\00e1tory LED'-
));
INSERT INTO product_descriptions VALUES(2419-
,'CS'-
,UNISTR(-
'Bateriov\00e9 z\00e1lohov\00e1n\00ed (DA-290)'-
),UNISTR(-
'Nab\00edje\010dka pro dv\011b baterie s indik\00e1tory LED'-
));
INSERT INTO product_descriptions VALUES(3097-
,'CS'-
,UNISTR(-
'Konektor kabelu - 32R'-
),UNISTR(-
'Kabel konektoru - 32 kol\00edk\016f ploch\00fd kabel'-
));
INSERT INTO product_descriptions VALUES(3099-
,'CS'-
,UNISTR(-
'P\00e1sky na kabely'-
),UNISTR(-
'P\00e1sky na kabely pro uspo\0159\00e1d\00e1n\00ed a sv\00e1z\00e1n'||-
'\00ed kabel\016f'-
));
INSERT INTO product_descriptions VALUES(2380-
,'CS'-
,UNISTR(-
'Kabel PR/15/P'-
),UNISTR(-
'Kabel pro paraleln\00ed tisk\00e1rnu 15 stop'-
));
INSERT INTO product_descriptions VALUES(2408-
,'CS'-
,UNISTR(-
'Kabel PR/P/6'-
),UNISTR(-
'Standardn\00ed kabel tisk\00e1rny Centronics 6 stop, paraleln\00ed port'-
));
INSERT INTO product_descriptions VALUES(2457-
,'CS'-
,UNISTR(-
'Kabel PR/S/6'-
),UNISTR(-
'Standardn\00ed kabel pro s\00e9riovou tisk\00e1rnu RS232, 6 stop'-
));
INSERT INTO product_descriptions VALUES(2373-
,'CS'-
,UNISTR(-
'Kabel RS232 10/AF'-
),UNISTR(-
'Kabel RS232 10 stop, s adapt\00e9ry F/F a 9F/25F'-
));
INSERT INTO product_descriptions VALUES(1734-
,'CS'-
,UNISTR(-
'Kabel RS232 10/AM'-
),UNISTR(-
'Kabel RS232 10 stop, s adapt\00e9ry M/M a 9M/25M'-
));
INSERT INTO product_descriptions VALUES(1737-
,'CS'-
,UNISTR(-
'Kabel SCSI 10/FW/ADS'-
),UNISTR(-
'Kabel 10 stop SCSI2 s p\0159izp\016fsoben\00edm F/W do DSxx0'-
));
INSERT INTO product_descriptions VALUES(1745-
,'CS'-
,UNISTR(-
'Kabel SCSI 20/WD->D'-
),UNISTR(-
'Kabel na propojen\00ed SCSI2 Wide Disk Store a Disk Store'-
));
INSERT INTO product_descriptions VALUES(2982-
,'CS'-
,UNISTR(-
'R\00e1me\010dek pro mont\00e1\017e mechaniky - A'-
),UNISTR(-
'Souprava pro mont\00e1\017e mechaniky'-
));
INSERT INTO product_descriptions VALUES(3277-
,'CS'-
,UNISTR(-
'R\00e1me\010dek pro mont\00e1\017e mechaniky - A/T'-
),UNISTR(-
'Souprava pro mont\00e1\017e mechaniky pro PC sk\0159\00ed\0148 typu v'||-
'\011b\017e'-
));
INSERT INTO product_descriptions VALUES(2976-
,'CS'-
,UNISTR(-
'R\00e1me\010dek pro mont\00e1\017e mechaniky - D'-
),UNISTR(-
'R\00e1me\010dek pro mont\00e1\017e mechaniky pro PC sk\0159\00ed'||-
'\0148 typu desktop'-
));
INSERT INTO product_descriptions VALUES(3204-
,'CS'-
,UNISTR(-
'Envoy DS'-
),UNISTR(-
'Envoy Docking Station'-
));
INSERT INTO product_descriptions VALUES(2638-
,'CS'-
,UNISTR(-
'Envoy DS/E'-
),UNISTR(-
'Envoy zdokonalen\00e1 Docking Station'-
));
INSERT INTO product_descriptions VALUES(3020-
,'CS'-
,UNISTR(-
'Envoy IC'-
),UNISTR(-
'Internetov\00fd po\010d\00edta\010d Envoy, Plug&Play (p\0159ipoj a pr'||-
'acuj)'-
));
INSERT INTO product_descriptions VALUES(1948-
,'CS'-
,UNISTR(-
'Envoy IC/58'-
),UNISTR(-
'Internetov\00fd po\010d\00edta\010d s vestav\011bn\00fdm modemem 58K'-
));
INSERT INTO product_descriptions VALUES(3003-
,'CS'-
,UNISTR(-
'P\0159enosn\00fd po\010d\00edta\010d 128/12/56/v90/110'-
),UNISTR(-
'P\0159enosn\00fd po\010d\00edta\010d Envoy, pam\011b\0165 128 MB, p'||-
'evn\00fd disk 12 GB, modem v90, nap\00e1jen\00ed 110 V.'-
));
INSERT INTO product_descriptions VALUES(2999-
,'CS'-
,UNISTR(-
'P\0159enosn\00fd po\010d\00edta\010d 16/8/110'-
),UNISTR(-
'P\0159enosn\00fd po\010d\00edta\010d Envoy, pam\011b\0165 16 MB, pe'||-
'vn\00fd disk 8 GB, nap\00e1jen\00ed 110 V (jen Spojen\00e9 st\00e1ty)'||-
'.'-
));
INSERT INTO product_descriptions VALUES(3000-
,'CS'-
,UNISTR(-
'P\0159enosn\00fd po\010d\00edta\010d 32/10/56'-
),UNISTR(-
'P\0159enosn\00fd po\010d\00edta\010d Envoy, pam\011b\0165 32 MB, pe'||-
'vn\00fd disk 10 GB, modem 56K, univerz\00e1ln\00ed nap\00e1jec\00ed z'||-
'droj (p\0159ep\00ednateln\00fd).'-
));
INSERT INTO product_descriptions VALUES(3001-
,'CS'-
,UNISTR(-
'P\0159enosn\00fd po\010d\00edta\010d 48/10/56/110'-
),UNISTR(-
'P\0159enosn\00fd po\010d\00edta\010d Envoy, pam\011b\0165 48 MB, pe'||-
'vn\00fd disk 10 GB, 56K modem, nap\00e1jec\00ed zdroj 110 V.'-
));
INSERT INTO product_descriptions VALUES(3004-
,'CS'-
,UNISTR(-
'P\0159enosn\00fd po\010d\00edta\010d 64/10/56/220'-
),UNISTR(-
'P\0159enosn\00fd po\010d\00edta\010d Envoy, pam\011b\0165 64 MB, pe'||-
'vn\00fd disk 10 GB, modem 56K, nap\00e1jec\00ed zdroj 220 V.'-
));
INSERT INTO product_descriptions VALUES(3391-
,'CS'-
,UNISTR(-
'PS 110/220'-
),UNISTR(-
'Nap\00e1jec\00ed zdroj - p\0159ep\00ednateln\00fd, 110 V/220 V'-
));
INSERT INTO product_descriptions VALUES(3124-
,'CS'-
,UNISTR(-
'PS 110V /T'-
),UNISTR(-
'Nap\00e1jec\00ed zdroj pro PC typu v\011b\017e, 110 V'-
));
INSERT INTO product_descriptions VALUES(1738-
,'CS'-
,UNISTR(-
'PS 110V /US'-
),UNISTR(-
'Nap\00e1jec\00ed zdroj 110 V - kompatibiln\00ed pro Spojen\00e9 st'||-
'\00e1ty'-
));
INSERT INTO product_descriptions VALUES(2377-
,'CS'-
,UNISTR(-
'PS 110V HS/US'-
),UNISTR(-
'Nap\00e1jec\00ed zdroj 110 V vym\011bniteln\00fd za provozu - kompatib'||-
'iln\00ed pro Spojen\00e9 st\00e1ty'-
));
INSERT INTO product_descriptions VALUES(2299-
,'CS'-
,UNISTR(-
'PS 12V /P'-
),UNISTR(-
'Nap\00e1jec\00ed zdroj - 12 V p\0159enosn\00fd'-
));
INSERT INTO product_descriptions VALUES(3123-
,'CS'-
,UNISTR(-
'PS 220V /D'-
),UNISTR(-
'Standardn\00ed nap\00e1jec\00ed zdroj, 220 V, pro po\010d\00edta'||-
'\010de typu desktop.'-
));
INSERT INTO product_descriptions VALUES(1748-
,'CS'-
,UNISTR(-
'PS 220V /EUR'-
),UNISTR(-
'Nap\00e1jec\00ed zdroj 220 Volt\016f - typ pro Evropu'-
));
INSERT INTO product_descriptions VALUES(2387-
,'CS'-
,UNISTR(-
'PS 220V /FR'-
),UNISTR(-
'Nap\00e1jec\00ed zdroj 220 Volt\016f - typ pro Francii'-
));
INSERT INTO product_descriptions VALUES(2370-
,'CS'-
,UNISTR(-
'PS 220V /HS/FR'-
),UNISTR(-
'Nap\00e1jec\00ed zdroj 220 V, vym\011bniteln\00fd za provozu, pro Fran'||-
'cii.'-
));
INSERT INTO product_descriptions VALUES(2311-
,'CS'-
,UNISTR(-
'PS 220V /L'-
),UNISTR(-
'Nap\00e1jec\00ed zdroj pro p\0159enosn\00e9 po\010d\00edta\010de, 2'||-
'20 V'-
));
INSERT INTO product_descriptions VALUES(1733-
,'CS'-
,UNISTR(-
'PS 220V /UK'-
),UNISTR(-
'Nap\00e1jec\00ed zdroj 220 Volt\016f - typ pro Spojen\00e9 kr\00e1lov'||-
'stv\00ed'-
));
INSERT INTO product_descriptions VALUES(2878-
,'CS'-
,UNISTR(-
'Sm\011brova\010d (router) - ASR/2W'-
),UNISTR(-
'Speci\00e1ln\00ed ALS sm\011brova\010d - schv\00e1len\00fd dodavatel'||-
' po\017eadoval polo\017eku s dvoucestnou shodou'-
));
INSERT INTO product_descriptions VALUES(2879-
,'CS'-
,UNISTR(-
'Sm\011brova\010d (router) - ASR/3W'-
),UNISTR(-
'Speci\00e1ln\00ed ALS sm\011brova\010d - schv\00e1len\00fd dodavatel'||-
' po\017eadoval polo\017eku s trojcestnou shodou'-
));
INSERT INTO product_descriptions VALUES(2152-
,'CS'-
,UNISTR(-
'Sm\011brova\010d (router) - DTMF4'-
),UNISTR(-
'Sm\011brova\010d DTMF se 4 porty'-
));
INSERT INTO product_descriptions VALUES(3301-
,'CS'-
,UNISTR(-
'\0160rouby <B.28.P>'-
),UNISTR(-
'\0160rouby: Mosaz, rozm\011br 28 mm, s k\0159\00ed\017eovou dr\00e1'||-
'\017ekou. Plastov\00e1 krabice, obsah 500 ks.'-
));
INSERT INTO product_descriptions VALUES(3143-
,'CS'-
,UNISTR(-
'\0160rouby <B.28.S>'-
),UNISTR(-
'\0160rouby: Mosaz, rozm\011br 28 mm, s p\0159\00edmou dr\00e1\017eko'||-
'u. Plastov\00e1 krabice, obsah 500 ks.'-
));
INSERT INTO product_descriptions VALUES(2323-
,'CS'-
,UNISTR(-
'\0160rouby <B.32.P>'-
),UNISTR(-
'\0160rouby: Mosaz, rozm\011br 32 mm, s k\0159\00ed\017eovou dr\00e1'||-
'\017ekou. Plastov\00e1 krabice, obsah 400 ks.'-
));
INSERT INTO product_descriptions VALUES(3134-
,'CS'-
,UNISTR(-
'\0160rouby <B.32.S>'-
),UNISTR(-
'\0160rouby: Mosaz, rozm\011br 32 mm, s p\0159\00edmou dr\00e1\017eko'||-
'u. Plastov\00e1 krabice, obsah 400 ks.'-
));
INSERT INTO product_descriptions VALUES(3139-
,'CS'-
,UNISTR(-
'\0160rouby <S.16.S>'-
),UNISTR(-
'\0160rouby: Ocel, rozm\011br 16 mm, s p\0159\00edmou dr\00e1\017ekou'||-
'. Pap\00edrov\00e1 krabice, obsah 750 ks.'-
));
INSERT INTO product_descriptions VALUES(3300-
,'CS'-
,UNISTR(-
'\0160rouby <S.32.P>'-
),UNISTR(-
'\0160rouby: Ocel, rozm\011br 32 mm, s k\0159\00ed\017eovou dr\00e1'||-
'\017ekou. Plastov\00e1 krabice, obsah 400 ks.'-
));
INSERT INTO product_descriptions VALUES(2316-
,'CS'-
,UNISTR(-
'\0160rouby <S.32.S>'-
),UNISTR(-
'\0160rouby: Ocel, rozm\011br 32 mm, s p\0159\00edmou dr\00e1\017ekou'||-
'. Plastov\00e1 krabice, obsah 500 ks.'-
));
INSERT INTO product_descriptions VALUES(3140-
,'CS'-
,UNISTR(-
'\0160rouby <Z.16.S>'-
),UNISTR(-
'\0160rouby: Pozinkovan\00e9, d\00e9lka 16 mm, s p\0159\00edmou dr'||-
'\00e1\017ekou. Pap\00edrov\00e1 krabice, obsah 750 ks.'-
));
INSERT INTO product_descriptions VALUES(2319-
,'CS'-
,UNISTR(-
'\0160rouby <Z.24.S>'-
),UNISTR(-
'\0160rouby: Pozinkovan\00e9, rozm\011br 24 mm, s p\0159\00edmou dr'||-
'\00e1\017ekou. Pap\00edrov\00e1 krabice, obsah 500 ks.'-
));
INSERT INTO product_descriptions VALUES(2322-
,'CS'-
,UNISTR(-
'\0160rouby <Z.28.P>'-
),UNISTR(-
'\0160rouby: Pozinkovan\00e9, rozm\011br 28 mm, s k\0159\00ed\017eovo'||-
'u dr\00e1\017ekou. Pap\00edrov\00e1 krabice, obsah 850 ks.'-
));
INSERT INTO product_descriptions VALUES(3178-
,'CS'-
,UNISTR(-
'Tabulkov\00fd procesor - SSP/V 2.0'-
),UNISTR(-
'Tabulkov\00fd procesor SmartSpread, profesion\00e1ln\00ed edice verze 2'||-
'.0, pro Vision Release 11.1 a 11.2. Balen\00ed ve smr\0161\0165ovac'||-
'\00ed f\00f3lii zahrnuje CD-ROM, obsahuj\00edc\00ed pokro\010dil'||-
'\00fd software a dokumentaci on-line, plus ti\0161t\011bn\00fd manu'||-
'\00e1l, v\00fdukov\00fd program a registraci licence.'-
));
INSERT INTO product_descriptions VALUES(3179-
,'CS'-
,UNISTR(-
'Tabulkov\00fd procesor - SSS/S 2.1'-
),UNISTR(-
'Tabulkov\00fd procesor SmartSpread, standardn\00ed edice verze 2.1, pro '||-
'SPNIX Release 4.0. Balen\00ed ve smr\0161\0165ovac\00ed f\00f3lii zah'||-
'rnuje CD-ROM, obsahuj\00edc\00ed software a dokumentaci on-line, plus ti'||-
'\0161t\011bn\00fd manu\00e1l a registraci licence.'-
));
INSERT INTO product_descriptions VALUES(3182-
,'CS'-
,UNISTR(-
'Textov\00fd editor - SWP/V 4.5'-
),UNISTR(-
'Textov\00fd editor SmartWord, profesion\00e1ln\00ed edice verze 4.5, pr'||-
'o Vision Release 11.x. Balen\00ed ve smr\0161\0165ovac\00ed f\00f3lii'||-
' zahrnuje CD-ROM, obsahuj\00edc\00ed pokro\010dil\00fd software, ti'||-
'\0161t\011bn\00fd manu\00e1l a registraci licence.'-
));
INSERT INTO product_descriptions VALUES(3183-
,'CS'-
,UNISTR(-
'Textov\00fd editor - SWS/V 4.5'-
),UNISTR(-
'Textov\00fd editor SmartWord, standardn\00ed edice verze 4.5, pro Vision'||-
' Release 11.x. Balen\00ed ve smr\0161\0165ovac\00ed f\00f3lii zahrnuj'||-
'e CD-ROM a registraci licence.'-
));
INSERT INTO product_descriptions VALUES(3197-
,'CS'-
,UNISTR(-
'Tabulkov\00fd procesor - SSS/V 2.1'-
),UNISTR(-
'Tabulkov\00fd procesor SmartSpread, standardn\00ed edice verze 2.1, pro '||-
'Vision Release 11.1 a 11.2. Balen\00ed ve smr\0161\0165ovac\00ed f'||-
'\00f3lii zahrnuje CD-ROM, obsahuj\00edc\00ed software a dokumentaci on-'||-
'line, plus ti\0161t\011bn\00fd manu\00e1l, v\00fdukov\00fd program a'||-
' registraci licence.'-
));
INSERT INTO product_descriptions VALUES(3255-
,'CS'-
,UNISTR(-
'Tabulkov\00fd procesor - SSS/CD 2.2B'-
),UNISTR(-
'Tabulkov\00fd procesor SmartSpread, standardn\00ed edice, beta verze 2.2'||-
' pro SPNIX Relaease 4.1. Jen CD-ROM.'-
));
INSERT INTO product_descriptions VALUES(3256-
,'CS'-
,UNISTR(-
'Tabulkov\00fd procesor - SSS/V 2.0'-
),UNISTR(-
'Tabulkov\00fd procesor SmartSpread, standardn\00ed edice verze 2.0, pro '||-
'Vision Release 11.0. Balen\00ed ve smr\0161\0165ovac\00ed f\00f3lii z'||-
'ahrnuje CD-ROM, obsahuj\00edc\00ed software a dokumentaci on-line, plus '||-
'ti\0161t\011bn\00fd manu\00e1l, v\00fdukov\00fd program a registraci'||-
' licence.'-
));
INSERT INTO product_descriptions VALUES(3260-
,'CS'-
,UNISTR(-
'Textov\00fd editor - SWP/S 4.4'-
),UNISTR(-
'Tabulkov\00fd procesor SmartSpread, standardn\00ed edice, verze 2.2 pro '||-
'SPNIX Relaease 4.x. Balen\00ed ve smr\0161\0165ovac\00ed f\00f3lii za'||-
'hrnuje CD-ROM, obsahuj\00edc\00ed software, plus ti\0161t\011bn\00fd '||-
'manu\00e1l a registraci licence.'-
));
INSERT INTO product_descriptions VALUES(3262-
,'CS'-
,UNISTR(-
'Tabulkov\00fd procesor - SSS/S 2.2'-
),UNISTR(-
'Tabulkov\00fd procesor SmartSpread, standardn\00ed edice, verze 2.2 pro '||-
'SPNIX Relaease 4.1. Balen\00ed ve smr\0161\0165ovac\00ed f\00f3lii za'||-
'hrnuje CD-ROM, obsahuj\00edc\00ed software a dokumentaci on-line, plus t'||-
'i\0161t\011bn\00fd manu\00e1l a registraci licence.'-
));
INSERT INTO product_descriptions VALUES(3361-
,'CS'-
,UNISTR(-
'Tabulkov\00fd procesor - SSP/S 1.5'-
),UNISTR(-
'Tabulkov\00fd procesor SmartSpread, standardn\00ed edice, verze 1.5 pro '||-
'SPNIX Relaease 3.3. Balen\00ed ve smr\0161\0165ovac\00ed f\00f3lii za'||-
'hrnuje CD-ROM, obsahuj\00edc\00ed pokro\010dil\00fd software a dokumen'||-
'taci on-line, plus ti\0161t\011bn\00fd manu\00e1l, v\00fdukov\00fd p'||-
'rogram a registraci licence.'-
));
INSERT INTO product_descriptions VALUES(1799-
,'CS'-
,UNISTR(-
'SPNIX3.3 - SL'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX v. 3.3 - z\00e1kladn'||-
'\00ed licence pro server. Zahrnuje 10 v\0161eobecn\00fdch licenc\00ed '||-
'pro spr\00e1vu syst\00e9mu, v\00fdvoj\00e1\0159e nebo u\017eivatele.'||-
' \017d\00e1dn\00e9 licence pro s\00ed\0165ov\00e9 u\017eivatele.'-
));
INSERT INTO product_descriptions VALUES(1801-
,'CS'-
,UNISTR(-
'SPNIX3.3 - AL'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V3.3 - Roz\0161\00ed'||-
'\0159en\00e1 licence pro spr\00e1vce syst\00e9mu, v\010detn\011b p'||-
'\0159\00edstupu po s\00edti.'-
));
INSERT INTO product_descriptions VALUES(1803-
,'CS'-
,UNISTR(-
'SPNIX3.3 - DL'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V3.3 - Roz\0161\00ed'||-
'\0159en\00e1 licence pro v\00fdvoj\00e1\0159e.'-
));
INSERT INTO product_descriptions VALUES(1804-
,'CS'-
,UNISTR(-
'SPNIX3.3 - UL/N'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V3.3 - Roz\0161\00ed'||-
'\0159en\00e1 licence u\017eivatele s p\0159\00edstupem po s\00edti.'-
));
INSERT INTO product_descriptions VALUES(1805-
,'CS'-
,UNISTR(-
'SPNIX3.3 - UL/A'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V3.3 - Roz\0161\00ed'||-
'\0159en\00e1 licence u\017eivatele, t\0159\00edda A.'-
));
INSERT INTO product_descriptions VALUES(1806-
,'CS'-
,UNISTR(-
'SPNIX3.3 - UL/C'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V3.3 - Roz\0161\00ed'||-
'\0159en\00e1 licence u\017eivatele, t\0159\00edda C.'-
));
INSERT INTO product_descriptions VALUES(1808-
,'CS'-
,UNISTR(-
'SPNIX3.3 - UL/D'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V3.3 - Roz\0161\00ed'||-
'\0159en\00e1 licence u\017eivatele, t\0159\00edda D.'-
));
INSERT INTO product_descriptions VALUES(1820-
,'CS'-
,UNISTR(-
'SPNIX3.3 - NL'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V3.3 - Roz\0161\00ed'||-
'\0159en\00e1 licence pro p\0159\00edstup po s\00edti.'-
));
INSERT INTO product_descriptions VALUES(1822-
,'CS'-
,UNISTR(-
'SPNIX4.0 - SL'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V4.0 - Z\00e1kladn'||-
'\00ed licence pro server. Zahrnuje 10 v\0161eobecn\00fdch licenc\00ed '||-
'pro spr\00e1vce syst\00e9mu, v\00fdvoj\00e1\0159e nebo u\017eivatele'||-
'. Neobsahuje licence pro u\017eivatele s\00edt\011b.'-
));
INSERT INTO product_descriptions VALUES(2422-
,'CS'-
,UNISTR(-
'SPNIX4.0 - SAL'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V4.0 - Roz\0161\00ed'||-
'\0159en\00e1 licence pro spr\00e1vce syst\00e9mu, v\010detn\011b p'||-
'\0159\00edstupu po s\00edti.'-
));
INSERT INTO product_descriptions VALUES(2452-
,'CS'-
,UNISTR(-
'SPNIX4.0 - DL'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V4.0 - Roz\0161\00ed'||-
'\0159en\00e1 licence pro v\00fdvoj\00e1\0159e.'-
));
INSERT INTO product_descriptions VALUES(2462-
,'CS'-
,UNISTR(-
'SPNIX4.0 - UL/N'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V4.0 - Roz\0161\00ed'||-
'\0159en\00e1 licence u\017eivatele s p\0159\00edstupem po s\00edti.'-
));
INSERT INTO product_descriptions VALUES(2464-
,'CS'-
,UNISTR(-
'SPNIX4.0 - UL/A'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V4.0 - Roz\0161\00ed'||-
'\0159en\00e1 licence u\017eivatele, t\0159\00edda A.'-
));
INSERT INTO product_descriptions VALUES(2467-
,'CS'-
,UNISTR(-
'SPNIX4.0 - UL/D'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V4.0 - Roz\0161\00ed'||-
'\0159en\00e1 licence u\017eivatele, t\0159\00edda D.'-
));
INSERT INTO product_descriptions VALUES(2468-
,'CS'-
,UNISTR(-
'SPNIX4.0 - UL/C'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V4.0 - Roz\0161\00ed'||-
'\0159en\00e1 licence u\017eivatele, t\0159\00edda C.'-
));
INSERT INTO product_descriptions VALUES(2470-
,'CS'-
,UNISTR(-
'SPNIX4.0 - NL'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V4.0 - Roz\0161\00ed'||-
'\0159en\00e1 licence pro p\0159\00edstup ze s\00edt\011b.'-
));
INSERT INTO product_descriptions VALUES(2471-
,'CS'-
,UNISTR(-
'SPNIX3.3 SU'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V3.3 - Z\00e1kladn'||-
'\00ed licence pro server, roz\0161\00ed\0159en\00ed na v. 4.0.'-
));
INSERT INTO product_descriptions VALUES(2492-
,'CS'-
,UNISTR(-
'SPNIX3.3 AU'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V3.3 - roz\0161\00ed'||-
'\0159en\00ed na v. 4.0; u\017eivatel t\0159\00eddy A.'-
));
INSERT INTO product_descriptions VALUES(2493-
,'CS'-
,UNISTR(-
'SPNIX3.3 C/DU'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V3.3 - roz\0161\00ed'||-
'\0159en\00ed na v. 4.0; u\017eivatel t\0159\00eddy C nebo D.'-
));
INSERT INTO product_descriptions VALUES(2494-
,'CS'-
,UNISTR(-
'SPNIX3.3 NU'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V3.3 - roz\0161\00ed'||-
'\0159en\00ed na v. 4.0; licence na p\0159\00edstup ze s\00edt\011b.'-
));
INSERT INTO product_descriptions VALUES(2995-
,'CS'-
,UNISTR(-
'SPNIX3.3 SAU'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V3.3 - roz\0161\00ed'||-
'\0159en\00ed na v. 4.0; licence pro spr\00e1vce syst\00e9mu.'-
));
INSERT INTO product_descriptions VALUES(3290-
,'CS'-
,UNISTR(-
'SPNIX3.3 DU'-
),UNISTR(-
'Software opera\010dn\00edho syst\00e9mu: SPNIX V3.3 - roz\0161\00ed'||-
'\0159en\00ed na v. 4.0; licence pro v\00fdvoj\00e1\0159e.'-
));
INSERT INTO product_descriptions VALUES(1778-
,'CS'-
,UNISTR(-
'C pro SPNIX3.3 - 1 licence'-
),UNISTR(-
'Programovac\00ed jazyk C pro SPNIX V3.3 - jeden u\017eivatel'-
));
INSERT INTO product_descriptions VALUES(1779-
,'CS'-
,UNISTR(-
'C pro SPNIX3.3 - Doc'-
),UNISTR(-
'Dokumentace programovac\00edho jazyka C, SPNIX V3.3'-
));
INSERT INTO product_descriptions VALUES(1780-
,'CS'-
,UNISTR(-
'C pro SPNIX3.3 - Sys'-
),UNISTR(-
'Programovac\00ed jazyk C pro SPNIX V3.3 - syst\00e9mov\00fd kompil'||-
'\00e1tor, knihovny, sestavovac\00ed program (linker)'-
));
INSERT INTO product_descriptions VALUES(2371-
,'CS'-
,UNISTR(-
'C pro SPNIX4.0 - Doc'-
),UNISTR(-
'Programovac\00ed jazyk C - dokumentace, SPNIX V4.4'-
));
INSERT INTO product_descriptions VALUES(2423-
,'CS'-
,UNISTR(-
'C pro SPNIX4.0 - 1 licence'-
),UNISTR(-
'Programovac\00ed jazyk C pro SPNIX V4.0 - jeden u\017eivatel'-
));
INSERT INTO product_descriptions VALUES(3501-
,'CS'-
,UNISTR(-
'C pro SPNIX4.0 - Sys'-
),UNISTR(-
'Programovac\00ed jazyk C pro SPNIX V4.0 - syst\00e9mov\00fd kompil'||-
'\00e1tor, knihovny, sestavovac\00ed program (linker).'-
));
INSERT INTO product_descriptions VALUES(3502-
,'CS'-
,UNISTR(-
'C pro SPNIX3.3 -Sys/U'-
),UNISTR(-
'Programovac\00ed jazyk C pro SPNIX V3.3 - roz\0161\00ed\0159en\00ed n'||-
'a V4.0; syst\00e9mov\00fd kompil\00e1tor, knihovny, sestavovac\00ed pr'||-
'ogram (linker).'-
));
INSERT INTO product_descriptions VALUES(3503-
,'CS'-
,UNISTR(-
'C pro SPNIX3.3 - Seat/U'-
),UNISTR(-
'Programovac\00ed jazyk C pro SPNIX V3.3 - roz\0161\00ed\0159en\00ed n'||-
'a V4.0 - jeden u\017eivatel'-
));
INSERT INTO product_descriptions VALUES(1774-
,'CS'-
,UNISTR(-
'Z\00e1kladn\00ed ISO CP - BL'-
),UNISTR(-
'Z\00e1kladn\00ed komunika\010dn\00ed soubor program\016f ISO - z'||-
'\00e1kladn\00ed licence'-
));
INSERT INTO product_descriptions VALUES(1775-
,'CS'-
,UNISTR(-
'Klient ISO CP - S'-
),UNISTR(-
'Komunika\010dn\00ed soubor program\016f ISO, p\0159\00eddavn\00e1 li'||-
'cence pro dal\0161\00edho klienta SPNIX V3.3'-
));
INSERT INTO product_descriptions VALUES(1794-
,'CS'-
,UNISTR(-
'OSI 8-16/IL'-
),UNISTR(-
'OSI vrstva 8 a\017e 16 - p\0159\00edr\016fstkov\00e1 licence'-
));
INSERT INTO product_descriptions VALUES(1825-
,'CS'-
,UNISTR(-
'X25 - 1 u\017eivatel'-
),UNISTR(-
'\0158\00edd\00edc\00ed syst\00e9m pro p\0159\00edstup do s\00edt'||-
'\011b X25, jeden u\017eivatel'-
));
INSERT INTO product_descriptions VALUES(2004-
,'CS'-
,UNISTR(-
'Prohl\00ed\017ee\010d IC - S'-
),UNISTR(-
'Prohl\00ed\017ee\010d WWW IC pro SPNIX. Prohl\00ed\017ee\010d s mo'||-
'\017enost\00ed elektronick\00e9 po\0161ty.'-
));
INSERT INTO product_descriptions VALUES(2005-
,'CS'-
,UNISTR(-
'IC prohl\00ed\017ee\010d Doc - S'-
),UNISTR(-
'Sada dokumentace k prohl\00ed\017ee\010di WWW IC pro SPNIX. Zahrnuje in'||-
'stala\010dn\00ed manu\00e1l, p\0159\00edru\010dku pro spr\00e1vu po'||-
'\0161tovn\00edho serveru a stru\010dn\00fd n\00e1vod pro u\017eivate'||-
'le.'-
));
INSERT INTO product_descriptions VALUES(2416-
,'CS'-
,UNISTR(-
'Klient ISO CP - S'-
),UNISTR(-
'Komunika\010dn\00ed soubor program\016f ISO, p\0159\00eddavn\00e1 li'||-
'cence pro dal\0161\00edho klienta SPNIX V4.0'-
));
INSERT INTO product_descriptions VALUES(2417-
,'CS'-
,UNISTR(-
'Klient ISO CP - V'-
),UNISTR(-
'Komunika\010dn\00ed soubor program\016f ISO, roz\0161i\0159uj\00edc'||-
'\00ed licence pro dal\0161\00edho klienta Vision.'-
));
INSERT INTO product_descriptions VALUES(2449-
,'CS'-
,UNISTR(-
'OSI 1-4/IL'-
),UNISTR(-
'OSI vrstva 1 a\017e 4 - p\0159\00edr\016fstkov\00e1 licence'-
));
INSERT INTO product_descriptions VALUES(3101-
,'CS'-
,UNISTR(-
'IC prohl\00ed\017ee\010d - V'-
),UNISTR(-
'Prohl\00ed\017ee\010d WWW IC pro Vision s manu\00e1lem. Prohl\00ed'||-
'\017ee\010d s mo\017enost\00ed elektronick\00e9 po\0161ty.'-
));
INSERT INTO product_descriptions VALUES(3170-
,'CS'-
,UNISTR(-
'Kancel\00e1\0159sk\00fd software - V/SP'-
),UNISTR(-
'Sada program\016f pro kancel\00e1\0159 (SmartWrite, SmartArt, SmartSpre'||-
'ad, SmartBrowse) pro Vision. Software ve \0161pan\011blsk\00e9m jazyce '||-
'a u\017eivatelsk\00e9 n\00e1vody.'-
));
INSERT INTO product_descriptions VALUES(3171-
,'CS'-
,UNISTR(-
'Kancel\00e1\0159sk\00fd software - S3.3/EN'-
),UNISTR(-
'Sada program\016f pro kancel\00e1\0159 (SmartWrite, SmartArt, SmartSpre'||-
'ad, SmartBrowse) pro SPNIX V3.3. Software v anglick\00e9m jazyce a u'||-
'\017eivatelsk\00e9 n\00e1vody.'-
));
INSERT INTO product_descriptions VALUES(3172-
,'CS'-
,UNISTR(-
'Grafika - DIK+'-
),UNISTR(-
'Sada program\016f pro grafiku: Draw-It Kwik-Plus. Zahrnuje rozs\00e1hl'||-
'\00e9 soubory grafick\00fdch p\0159edloh (clip art) a pokro\010dil'||-
'\00e9 kreslic\00ed n\00e1stroje pro 3-dimenzion\00e1ln\00ed zpracov'||-
'\00e1n\00ed objekt\016f a roz\0161\00ed\0159en\00e1 p\00edsma.'-
));
INSERT INTO product_descriptions VALUES(3173-
,'CS'-
,UNISTR(-
'Grafika - SA'-
),UNISTR(-
'Sada program\016f pro grafiku: SmartArt. Profesion\00e1ln\00ed bal'||-
'\00edk grafick\00fdch program\016f pro SPNIX s mnoha styly \010dar, te'||-
'xturami, vestav\011bn\00fdmi tvary a b\011b\017en\00fdmi symboly.'-
));
INSERT INTO product_descriptions VALUES(3175-
,'CS'-
,UNISTR(-
'\0158\00edzen\00ed projektu - S4.0'-
),UNISTR(-
'Software pro \0159\00edzen\00ed projektu pro SPNIX V4.0. Software zahrn'||-
'uje rozhran\00ed s p\0159\00edkazov\00fdm \0159\00e1dkem a grafick'||-
'\00e9 rozhran\00ed s n\00e1sleduj\00edc\00edmi form\00e1ty: textov'||-
'\00fd, tabulkov\00fd procesor a sestavy (p\0159izp\016fsobiteln\00e9)'||-
'.'-
));
INSERT INTO product_descriptions VALUES(3176-
,'CS'-
,UNISTR(-
'Smart Suite - V/EN'-
),UNISTR(-
'Sada kancel\00e1\0159sk\00fdch program\016f (SmartWrite, SmartArt, Sma'||-
'rtSpread, SmartBrowse) pro Vision. Software v anglick\00e9m jazyce a u'||-
'\017eivatelsk\00e9 manu\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3177-
,'CS'-
,UNISTR(-
'Smart Suite - V/FR'-
),UNISTR(-
'Sada kancel\00e1\0159sk\00fdch program\016f (SmartWrite, SmartArt, Sma'||-
'rtSpread, SmartBrowse) pro Vision. Software ve francouzsk\00e9m jazyce a '||-
'u\017eivatelsk\00e9 manu\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3245-
,'CS'-
,UNISTR(-
'Smart Suite - S4.0/FR'-
),UNISTR(-
'Sada kancel\00e1\0159sk\00fdch program\016f (SmartWrite, SmartArt, Sma'||-
'rtSpread, SmartBrowse) pro SPNIX V4.0. Software ve francouzsk\00e9m jazyc'||-
'e a u\017eivatelsk\00e9 manu\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3246-
,'CS'-
,UNISTR(-
'Smart Suite - S4.0/SP'-
),UNISTR(-
'Sada kancel\00e1\0159sk\00fdch program\016f (SmartWrite, SmartArt, Sma'||-
'rtSpread, SmartBrowse) pro SPNIX V4.0. Software ve \0161pan\011blsk'||-
'\00e9m jazyce a u\017eivatelsk\00e9 manu\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3247-
,'CS'-
,UNISTR(-
'Smart Suite - V/DE'-
),UNISTR(-
'Sada kancel\00e1\0159sk\00fdch program\016f (SmartWrite, SmartArt, Sma'||-
'rtSpread, SmartBrowse) pro Vision. Software v n\011bmeck\00e9m jazyce a '||-
'u\017eivatelsk\00e9 manu\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3248-
,'CS'-
,UNISTR(-
'Smart Suite - S4.0/DE'-
),UNISTR(-
'Sada kancel\00e1\0159sk\00fdch program\016f (SmartWrite, SmartArt, Sma'||-
'rtSpread, SmartBrowse) pro SPNIX V4.0. Software v n\011bmeck\00e9m jazyc'||-
'e a u\017eivatelsk\00e9 manu\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3250-
,'CS'-
,UNISTR(-
'Grafika - DIK'-
),UNISTR(-
'Sada grafick\00fdch program\016f: Draw-It Kwik. Jednoduch\00fd bal'||-
'\00edk grafick\00fdch program\016f pro syst\00e9my Vision s mo\017eno'||-
'st\00ed ulo\017een\00ed ve form\00e1tech GIF, JPG a BMP.'-
));
INSERT INTO product_descriptions VALUES(3251-
,'CS'-
,UNISTR(-
'\0158\00edzen\00ed projektu - V'-
),UNISTR(-
'Software pro \0158\00edzen\00ed projektu pro Vision. Software zahrnuje '||-
'rozhran\00ed s p\0159\00edkazov\00fdm \0159\00e1dkem a grafick\00e9'||-
' rozhran\00ed s n\00e1sleduj\00edc\00edmi form\00e1ty: textov\00fd, '||-
'tabulkov\00fd procesor a sestavy (p\0159izp\016fsobiteln\00e9).'-
));
INSERT INTO product_descriptions VALUES(3252-
,'CS'-
,UNISTR(-
'\0158\00edzen\00ed projektu - S3.3'-
),UNISTR(-
'Software pro \0158\00edzen\00ed projektu pro SPNIX V3.3. Software zahrn'||-
'uje rozhran\00ed s p\0159\00edkazov\00fdm \0159\00e1dkem a grafick'||-
'\00e9 rozhran\00ed s n\00e1sleduj\00edc\00edmi form\00e1ty: textov'||-
'\00fd, tabulkov\00fd procesor a sestavy (p\0159izp\016fsobiteln\00e9)'||-
'.'-
));
INSERT INTO product_descriptions VALUES(3253-
,'CS'-
,UNISTR(-
'Smart Suite - S4.0/EN'-
),UNISTR(-
'Sada kancel\00e1\0159sk\00fdch program\016f (SmartWrite, SmartArt, Sma'||-
'rtSpread, SmartBrowse) pro SPNIX V4.0. Software v anglick\00e9m jazyce a '||-
'u\017eivatelsk\00e9 manu\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3257-
,'CS'-
,UNISTR(-
'Prohl\00ed\017ee\010d WWW - SB/S 2.1'-
),UNISTR(-
'Sada program\016f prohl\00ed\017ee\010de WWW: SmartBrowse V2.1 pro SPN'||-
'IX V3.3. Zahrnuje soubory s kontextovou n\00e1pov\011bdou a dokumentaci '||-
'on-line.'-
));
INSERT INTO product_descriptions VALUES(3258-
,'CS'-
,UNISTR(-
'Prohl\00ed\017ee\010d WWW - SB/V 1.0'-
),UNISTR(-
'Sada program\016f prohl\00ed\017ee\010de WWW: SmartBrowse V2.1 pro Vis'||-
'ion. Zahrnuje soubory s kontextovou n\00e1pov\011bdou a dokumentaci on-l'||-
'ine.'-
));
INSERT INTO product_descriptions VALUES(3362-
,'CS'-
,UNISTR(-
'Prohl\00ed\017ee\010d WWW - SB/S 4.0'-
),UNISTR(-
'Sada program\016f prohl\00ed\017ee\010de WWW: SmartBrowse V2.1 pro SPN'||-
'IX V4.0. Zahrnuje soubory s kontextovou n\00e1pov\011bdou a dokumentaci '||-
'on-line.'-
));
INSERT INTO product_descriptions VALUES(2231-
,'CS'-
,UNISTR(-
'Psac\00ed st\016fl - S/V'-
),UNISTR(-
'Psac\00ed st\016fl standardn\00edch rozm\011br\016f; aktivovateln'||-
'\00e1, zdaniteln\00e1 polo\017eka. Povrchov\00e1 \00faprava je z d'||-
'\00fdhy, kter\00e1 je na sklad\011b v dob\011b objedn\00e1vky, v'||-
'\010detn\011b dubu, jasanu, t\0159e\0161n\011b a mahagonu.'-
));
INSERT INTO product_descriptions VALUES(2335-
,'CS'-
,UNISTR(-
'Mobiln\00ed telefon'-
),UNISTR(-
'Du\00e1ln\00ed mobiln\00ed telefon s n\00edzkou spot\0159ebou energie'||-
'. Lehk\00fd, skl\00e1p\011bc\00ed, se z\00e1suvkou na p\0159ipojen'||-
'\00ed sluch\00e1tka a s p\0159ihr\00e1dkou pro n\00e1hradn\00ed bate'||-
'rii.'-
));
INSERT INTO product_descriptions VALUES(2350-
,'CS'-
,UNISTR(-
'Psac\00ed st\016fl - W/48'-
),UNISTR(-
'Psac\00ed st\016fl - 48 palc\016f, b\00edl\00fd lamin\00e1t bez bo'||-
'\010dn\00edho stolku; aktivovateln\00e1, zdaniteln\00e1 polo\017eka.'-
));
INSERT INTO product_descriptions VALUES(2351-
,'CS'-
,UNISTR(-
'Psac\00ed st\016fl - W/48/R'-
),UNISTR(-
'Psac\00ed st\016fl - 60 palc\016f, b\00edl\00fd lamin\00e1t s 48 pal'||-
'cov\00fdm bo\010dn\00edm stolkem; aktivovateln\00e1, zdaniteln\00e1 p'||-
'olo\017eka.'-
));
INSERT INTO product_descriptions VALUES(2779-
,'CS'-
,UNISTR(-
'Psac\00ed st\016fl - OS/O/F'-
),UNISTR(-
'Dubov\00fd psac\00ed st\016fl velk\00fdch rozm\011br\016f v mana'||-
'\017eersk\00e9m stylu se z\00e1suvkami na spisy. Povrchov\00e1 \00fap'||-
'rava se d\00e1 zvolit p\0159i objedn\00e1vce, sv\011btle nebo tmav'||-
'\011b mo\0159en\00fd dub nebo p\0159\00edrodn\00ed ru\010dn\011b l'||-
'e\0161t\011bn\00fd \010dir\00fd povrch.'-
));
INSERT INTO product_descriptions VALUES(3337-
,'CS'-
,UNISTR(-
'Mobiln\00ed telefon s p\0159ipojen\00edm na internet'-
),UNISTR(-
'Mobiln\00ed telefon v\010detn\011b m\011bs\00ed\010dn\00edch poplat'||-
'k\016f za p\0159\00edstup na WWW. Tenk\00e9 proveden\00ed s pouzdrem '||-
'z imitace k\016f\017ee a sponou na opasek.'-
));
INSERT INTO product_descriptions VALUES(2091-
,'CS'-
,UNISTR(-
'Pap\00edrov\00fd blok LW 8 1/2 x 11'-
),UNISTR(-
'Pozn\00e1mkov\00fd pap\00edrov\00fd blok, linkovan\00fd, b\00edl'||-
'\00fd, rozm\011br 8,5 x 11 palc\016f'-
));
INSERT INTO product_descriptions VALUES(2093-
,'CS'-
,UNISTR(-
'Pera - 10/FP'-
),UNISTR(-
'Pero s trvanliv\00fdm inkoustem, kter\00fd rychle schne a nerozmaz\00e1'||-
'v\00e1 se. Zaji\0161\0165uje hladk\00e9 a nep\0159eru\0161ovan\00e9'||-
' psan\00ed. Jemn\00fd hrot. Krabice s jednou barvou (\010dern\00e1, mo'||-
'dr\00e1, \010derven\00e1) nebo s r\016fzn\00fdmi barvami (6 \010dern'||-
'\00fdch, 3 modr\00e9 a 1 \010derven\00e1).'-
));
INSERT INTO product_descriptions VALUES(2144-
,'CS'-
,UNISTR(-
'Kryt z\00e1sobn\00edku nav\0161t\00edvenek'-
),UNISTR(-
'N\00e1hradn\00ed kryt stoln\00edho z\00e1sobn\00edku nav\0161t\00ed'||-
'venek v mana\017eersk\00e9m stylu. Kou\0159ov\011b \0161ed\00fd (ori'||-
'gin\00e1ln\00ed barva) nebo \010dir\00fd plast.'-
));
INSERT INTO product_descriptions VALUES(2336-
,'CS'-
,UNISTR(-
'Krabice na nav\0161t\00edvenky - 250'-
),UNISTR(-
'Krabice nav\0161t\00edvenek, kapacita 250 ks. Na objedn\00e1n\00ed pou'||-
'\017eijte formul\00e1\0159 BC110-2, Rev. 3/2000 (na pap\00ed\0159e ne'||-
'bo online) a vypl\0148te v\0161echny rubriky ozna\010den\00e9 hv\011b'||-
'zdi\010dkou.'-
));
INSERT INTO product_descriptions VALUES(2337-
,'CS'-
,UNISTR(-
'Nav\0161t\00edvenky - 1000/2L'-
),UNISTR(-
'Krabice nav\0161t\00edvenek, kapacita 1000 ks, dvoustrann\00e9 s odli'||-
'\0161n\00fdmi jazyky na ka\017ed\00e9 stran\011b. Na objedn\00e1n'||-
'\00ed pou\017eijte formul\00e1\0159 BC111-2, Rev. 12/1999 (na pap'||-
'\00ed\0159e nebo online) vypl\0148te v\0161echny rubriky ozna\010den'||-
'\00e9 hv\011bzdi\010dkou a ozna\010dte pol\00ed\010dko pro druh'||-
'\00fd jazyk (angli\010dtina je v\017edy na stran\011b 1).'-
));
INSERT INTO product_descriptions VALUES(2339-
,'CS'-
,UNISTR(-
'Pap\00edr - Standardn\00ed tisk\00e1rna'-
),UNISTR(-
'Pap\00edr do laserov\00e9 tisk\00e1rny, 20 liber, 8,5 x 11 palce, b'||-
'\00edl\00fd (recyklovan\00fd), deset bal\00edk\016f po 500 listech'-
));
INSERT INTO product_descriptions VALUES(2536-
,'CS'-
,UNISTR(-
'Nav\0161t\00edvenky - 250/2L'-
),UNISTR(-
'Krabice nav\0161t\00edvenek, kapacita 250 ks, dvoustrann\00e9 s odli'||-
'\0161n\00fdmi jazyky na ka\017ed\00e9 stran\011b. Na objedn\00e1n'||-
'\00ed pou\017eijte formul\00e1\0159 BC111-2, Rev. 12/1999 (na pap'||-
'\00ed\0159e nebo online) - vypl\0148te v\0161echny rubriky ozna\010de'||-
'n\00e9 hv\011bzdi\010dkou a ozna\010dte pol\00ed\010dko pro druh'||-
'\00fd jazyk (angli\010dtina je v\017edy na stran\011b 1).'-
));
INSERT INTO product_descriptions VALUES(2537-
,'CS'-
,UNISTR(-
'Krabice nav\0161t\00edvenek - 1000'-
),UNISTR(-
'Krabice nav\0161t\00edvenek, kapacita 1000 ks. Na objedn\00e1n\00ed po'||-
'u\017eijte formul\00e1\0159 BC110-3, Rev. 3/2000 (na pap\00ed\0159e n'||-
'ebo online) a vypl\0148te v\0161echny rubriky ozna\010den\00e9 hv'||-
'\011bzdi\010dkou.'-
));
INSERT INTO product_descriptions VALUES(2783-
,'CS'-
,UNISTR(-
'Sponky na pap\00edr'-
),UNISTR(-
'Sv\011btov\00e1 zna\010dka pap\00edrov\00fdch sponek, kter\00e1 ur'||-
'\010duje jejich kvalitu. 10 krabic, ka\017ed\00e1 po 100 kusech sponek.'||-
' #1 norm\00e1ln\00ed nebo velk\00e9, hladk\00e9 nebo drsn\00e9.'-
));
INSERT INTO product_descriptions VALUES(2808-
,'CS'-
,UNISTR(-
'Pap\00edrov\00fd blok LY 8 1/2 x 11'-
),UNISTR(-
'Pap\00edrov\00fd blok, linkovan\00fd, \017elut\00fd, rozm\011br 8 1/'||-
'2 x 11 palc\016f'-
));
INSERT INTO product_descriptions VALUES(2810-
,'CS'-
,UNISTR(-
'Pera s viditelnou inkoustovou n\00e1pln\00ed'-
),UNISTR(-
'Kuli\010dkov\00e9 pero je opat\0159eno p\0159esn\00fdm, hladk\00fdm '||-
'hrotem. Pr\016fhledn\00e1 gumov\00e1 rukoje\0165, umo\017e\0148uj'||-
'\00edc\00ed kontrolu mno\017estv\00ed inkoustu a pohodln\00e9 psan'||-
'\00ed. Krabi\010dka se 4 kusy obsahuje \010dernou, modrou, \010derveno'||-
'u a zelenou barvu.'-
));
INSERT INTO product_descriptions VALUES(2870-
,'CS'-
,UNISTR(-
'Tu\017eka - Mech'-
),UNISTR(-
'Ergonomicky navr\017een\00e1 mechanick\00e1 tu\017eka pro zlep\0161en'||-
'\00fd komfort psan\00ed. Tuhy i gumu lze dopl\0148ovat. Dod\00e1v'||-
'\00e1 se pro t\0159i pr\016fm\011bry tuhy: 0,5 mm (jemn\00e1); 0,7 mm'||-
' (st\0159edn\00ed); a 0,9 mm (tlust\00e1).'-
));
INSERT INTO product_descriptions VALUES(3051-
,'CS'-
,UNISTR(-
'Pera - 10/MP'-
),UNISTR(-
'Pero s trvanliv\00fdm inkoustem, kter\00fd rychle schne a nerozmaz\00e1'||-
'v\00e1 se. Zaji\0161\0165uje hladk\00e9 a nep\0159eru\0161ovan\00e9'||-
' psan\00ed. St\0159edn\00ed hrot. Krabice s jednou barvou (\010dern'||-
'\00e1, modr\00e1, \010derven\00e1) nebo s r\016fzn\00fdmi barvami (6'||-
' \010dern\00fdch, 3 modr\00e9 a 1 \010derven\00e1).'-
));
INSERT INTO product_descriptions VALUES(3150-
,'CS'-
,UNISTR(-
'Z\00e1sobn\00edk nav\0161t\00edvenek - 25'-
),UNISTR(-
'Z\00e1sobn\00edk nav\0161t\00edvenek; z\00e1sobn\00edk nav\0161t'||-
'\00edvenek z pevn\00e9ho plastu s vyra\017een\00fdm podnikov\00fdm lo'||-
'gem. Pojme asi 25 va\0161ich vizitek v z\00e1vislosti na jejich tlou'||-
'\0161\0165ce.'-
));
INSERT INTO product_descriptions VALUES(3208-
,'CS'-
,UNISTR(-
'Tu\017eky - d\0159ev\011bn\00e9'-
),UNISTR(-
'Krabice se 2 tucty d\0159ev\011bn\00fdch tu\017eek. P\0159i objedn'||-
'\00e1vce specifikujte typ tuhy: 2H (dvojn\00e1sobn\00e1 tvrdost), H (tv'||-
'rd\00e1), HB (tvrd\00e1 \010dern\00e1), B (m\011bkk\00e1 \010dern'||-
'\00e1).'-
));
INSERT INTO product_descriptions VALUES(3209-
,'CS'-
,UNISTR(-
'O\0159ez\00e1v\00e1tko na tu\017eky'-
),UNISTR(-
'Elektrick\00e9 o\0159ez\00e1v\00e1tko na tu\017eky s no\017ei z kval'||-
'itn\00ed oceli, zaji\0161\0165uj\00edc\00ed dlouhou \017eivotnost. F'||-
'unkce PencilSaver zabra\0148uje p\0159\00edli\0161n\00e9mu naost'||-
'\0159en\00ed. Neklouzav\00e9 gumov\00e9 patky. Zabudovan\00fd dr'||-
'\017e\00e1k tu\017eek.'-
));
INSERT INTO product_descriptions VALUES(3224-
,'CS'-
,UNISTR(-
'Z\00e1sobn\00edk nav\0161t\00edvenek - 250'-
),UNISTR(-
'P\0159enosn\00fd z\00e1sobn\00edk pro uspo\0159\00e1d\00e1n\00ed n'||-
'av\0161t\00edvenek, kapacita 250 ks. Ve stylu bro\017eury s transparent'||-
'n\00edmi kapsami na zasouv\00e1n\00ed nav\0161t\00edvenek. Voliteln'||-
'\00e9 \0161t\00edtky pro abecedn\00ed t\0159\00edd\011bn\00ed. P'||-
'\0159i objedn\00e1vce specifikujte barvu obalu (tmav\011b hn\011bd'||-
'\00e1, b\00e9\017eov\00e1, karm\00ednov\00e1, \010dern\00e1 a sv'||-
'\011btle \0161ed\00e1).'-
));
INSERT INTO product_descriptions VALUES(3225-
,'CS'-
,UNISTR(-
'Z\00e1sobn\00edk pro uspo\0159\00e1d\00e1n\00ed nav\0161t\00edvene'||-
'k - 1000'-
),UNISTR(-
'Z\00e1sobn\00edk pro uspo\0159\00e1d\00e1n\00ed nav\0161t\00edvene'||-
'k s abecedn\00edm d\011blen\00edm, kapacita 1000 ks. Stoln\00ed proved'||-
'en\00ed s kou\0159ov\011b \0161ed\00fdm krytem a \010dern\00fdm pod'||-
'stavcem. V\00ed\010dko je odn\00edmateln\00e9 pro ulo\017een\00ed vn'||-
'it\0159n\00ed z\00e1suvky.'-
));
INSERT INTO product_descriptions VALUES(3511-
,'CS'-
,UNISTR(-
'Pap\00edr - pro vysoce kvalitn\00ed tisk'-
),UNISTR(-
'Kvalitn\00ed pap\00edr pro inkoustov\00e9 a laserov\00e9 tisk\00e1rny'||-
', testovan\00fd na odolnost proti zma\010dk\00e1n\00ed v tisk\00e1rn'||-
'\011b. Neobsahuje kyseliny pro pou\017eit\00ed v archivech. Hmotnost 22'||-
' liber s b\011blost\00ed 92. Rozm\011br 8,5 x 11 palc\016f. Bal\00edk'||-
' o 500 listech.'-
));
INSERT INTO product_descriptions VALUES(3515-
,'CS'-
,UNISTR(-
'N\00e1hradn\00ed tuhy'-
),UNISTR(-
'N\00e1hradn\00ed tuhy pro mechanick\00e9 tu\017eky. Ka\017ed\00e9 ba'||-
'len\00ed obsahuje 25 tuh a n\00e1hradn\00ed gumu. Dod\00e1v\00e1 se v'||-
'e t\0159ech pr\016fm\011brech tuh: 0,5 mm (jemn\00e1), 0,7 mm (st'||-
'\0159edn\00ed) a 0,9 mm (tlust\00e1).'-
));
INSERT INTO product_descriptions VALUES(2986-
,'CS'-
,UNISTR(-
'Manu\00e1l - Vision OS/2x +'-
),UNISTR(-
'Manu\00e1ly pro opera\010dn\00ed syst\00e9m Vision V2.x a sadu kancel'||-
'\00e1\0159sk\00fdch program\016f (Vision Office Suite)'-
));
INSERT INTO product_descriptions VALUES(3163-
,'CS'-
,UNISTR(-
'Manu\00e1l - Vision Net6.3/US'-
),UNISTR(-
'Referen\010dn\00ed manu\00e1l pro pr\00e1ci v s\00edti pro Vision V6.'||-
'3. US verze s pokro\010dil\00fdm \0161ifrov\00e1n\00edm.'-
));
INSERT INTO product_descriptions VALUES(3165-
,'CS'-
,UNISTR(-
'Manu\00e1l - Vision Tools2.0'-
),UNISTR(-
'Referen\010dn\00ed manu\00e1l k souboru ekonomick\00fdch n\00e1stroj'||-
'\016f (Vision Business Tools Suite) pro Vision V2.0. Zahrnuje instalaci, '||-
'konfiguraci a n\00e1vod u\017eivatele.'-
));
INSERT INTO product_descriptions VALUES(3167-
,'CS'-
,UNISTR(-
'Manu\00e1l - Vision OS/2.x'-
),UNISTR(-
'Referen\010dn\00ed manu\00e1l pro opera\010dn\00ed syst\00e9m Vision'||-
' V2.0/2.1/2/3. Kompletn\00ed instalace, konfigurace, spr\00e1va a inform'||-
'ace pro lad\011bn\00ed pro spr\00e1vce syst\00e9mu Vision. Uv\011bdom'||-
'te si, \017ee tento manu\00e1l nahrazuje jednotliv\00e9 manu\00e1ly pr'||-
'o verze 2.0 a 2.1.'-
));
INSERT INTO product_descriptions VALUES(3216-
,'CS'-
,UNISTR(-
'Manu\00e1l - Vision Net6.3'-
),UNISTR(-
'Referen\010dn\00ed manu\00e1l pro pr\00e1ci v s\00edti pro Vision V6.'||-
'3. Neamerick\00e1 verze se z\00e1kladn\00edm \0161ifrov\00e1n\00edm.'-
));
INSERT INTO product_descriptions VALUES(3220-
,'CS'-
,UNISTR(-
'Manu\00e1l - Vision OS/1.2'-
),UNISTR(-
'Referen\010dn\00ed manu\00e1l pro opera\010dn\00ed syst\00e9m Vision'||-
' V1.2. Kompletn\00ed instalace, konfigurace, spr\00e1va a informace pro '||-
'lad\011bn\00ed pro spr\00e1vce syst\00e9mu Vision.'-
));
INSERT INTO product_descriptions VALUES(1729-
,'CS'-
,UNISTR(-
'Chemik\00e1lie - RCP'-
),UNISTR(-
'Chemik\00e1lie na \010di\0161t\011bn\00ed - 3500 kapesn\00ed\010dk'||-
'\016f na \010di\0161t\011bn\00ed v\00e1lc\016f'-
));
INSERT INTO product_descriptions VALUES(1910-
,'CS'-
,UNISTR(-
'FG dr\017e\00e1k - H'-
),UNISTR(-
'Sklolamin\00e1tov\00fd dr\017e\00e1k - pro velk\00e9 zat\00ed\017ee'||-
'n\00ed, tlou\0161\0165ka 1'-
));
INSERT INTO product_descriptions VALUES(1912-
,'CS'-
,UNISTR(-
'SS dr\017e\00e1k - 3 mm'-
),UNISTR(-
'Nerezov\00fd dr\017e\00e1k - 3 mm. M\016f\017ee b\00fdt p\0159edvrt'||-
'\00e1n pro standardn\00ed nap\00e1jec\00ed zdroje, dr\017e\00e1ky z'||-
'\00e1kladn\00edch desek a pevn\00e9 disky. P\0159i objedn\00e1v\00e1'||-
'n\00ed vrtan\00fdch plech\016f pou\017eijte p\0159\00edslu\0161nou '||-
'\0161ablonu na ur\010den\00ed \010d\00edsla modelu, um\00edst\011bn'||-
'\00ed a rozm\011br dokon\010den\00e9ho plechu.'-
));
INSERT INTO product_descriptions VALUES(1940-
,'CS'-
,UNISTR(-
'ESD N\00e1ramek/Spona'-
),UNISTR(-
'N\00e1ramek pro vybit\00ed elektrostatick\00e9ho n\00e1boje se svorkam'||-
'i typu krokod\00fdlek na snadn\00e9 p\0159ipojen\00ed k \0161asi po'||-
'\010d\00edta\010de nebo jin\00e9 uzemn\011bn\00e9 \010d\00e1sti.'-
));
INSERT INTO product_descriptions VALUES(2030-
,'CS'-
,UNISTR(-
'Latexov\00e9 rukavice'-
),UNISTR(-
'Latexov\00e9 rukavice pro mont\00e9ry, pracovn\00edky s chemik\00e1lie'||-
'mi, se\0159izova\010de. Pevn\00e9, v bezpe\010dnostn\00ed oran\017eo'||-
'v\00e9 barv\011b, se zdrsn\011bn\00fdmi plochami na prstech a palc'||-
'\00edch. Vodot\011bsn\00e9 a odoln\00e9 elektrick\00e9mu proudu do 22'||-
'0 V/ 2 A, 110 V/ 5 A. Odoln\00e9 kyselin\00e1m do 5 minut.'-
));
INSERT INTO product_descriptions VALUES(2326-
,'CS'-
,UNISTR(-
'Plastov\00fd dr\017e\00e1k - Y'-
),UNISTR(-
'Plastov\00fd dr\017e\00e1k - \017elut\00fd, standardn\00ed kvalita.'-
));
INSERT INTO product_descriptions VALUES(2330-
,'CS'-
,UNISTR(-
'Plastov\00fd dr\017e\00e1k - R'-
),UNISTR(-
'Plastov\00fd dr\017e\00e1k - \010derven\00fd, standardn\00ed kvalita'||-
'.'-
));
INSERT INTO product_descriptions VALUES(2334-
,'CS'-
,UNISTR(-
'Prysky\0159ice'-
),UNISTR(-
'Syntetick\00e1 prysky\0159ice pro v\0161eobecn\00e9 \00fa\010dely.'-
));
INSERT INTO product_descriptions VALUES(2340-
,'CS'-
,UNISTR(-
'Chemik\00e1lie - SW'-
),UNISTR(-
'\010cistic\00ed chemik\00e1lie - 3500 antistatick\00fd kapesn\00ed'||-
'\010dk\016f'-
));
INSERT INTO product_descriptions VALUES(2365-
,'CS'-
,UNISTR(-
'Chemik\00e1lie - TCS'-
),UNISTR(-
'\010cistic\00ed chemik\00e1lie - 2500 \010dist\00edc\00edch kapesn'||-
'\00ed\010dk\016f pod\00e1vac\00edch za\0159\00edzen\00ed'-
));
INSERT INTO product_descriptions VALUES(2594-
,'CS'-
,UNISTR(-
'FG dr\017e\00e1k - L'-
),UNISTR(-
'Sklolamin\00e1tov\00fd dr\017e\00e1k - lehk\00fd, pro vnit\0159n'||-
'\00ed ochranu proti teplu'-
));
INSERT INTO product_descriptions VALUES(2596-
,'CS'-
,UNISTR(-
'SS dr\017e\00e1k - 1mm'-
),UNISTR(-
'Nerezov\00fd dr\017e\00e1k - 3 mm. M\016f\017ee b\00fdt p\0159edvrt'||-
'\00e1n pro standardn\00ed z\00e1kladn\00ed desky a dr\017e\00e1ky ba'||-
'teri\00ed. P\0159i objedn\00e1v\00e1n\00ed vrtan\00fdch plech\016f '||-
'pou\017eijte p\0159\00edslu\0161nou \0161ablonu na ur\010den\00ed '||-
'\010d\00edsla modelu, um\00edst\011bn\00ed a rozm\011br dokon\010de'||-
'n\00e9ho plechu.'-
));
INSERT INTO product_descriptions VALUES(2631-
,'CS'-
,UNISTR(-
'ESD n\00e1ramek/QR'-
),UNISTR(-
'N\00e1ramek pro vybit\00ed elktrostatick\00e9ho n\00e1boje: 2 kusy ved'||-
'en\00ed s rychle odpojiteln\00fdmi konektory. Jeden kus z\016fst\00e1v'||-
'\00e1 trvale p\0159ipojen k \0161asi po\010d\00edta\010de \0161roub'||-
'em, druh\00fd je p\0159ipojen k n\00e1ramku. K dod\00e1n\00ed dal'||-
'\0161\00ed trvale p\0159ipojen\00e9 konce.'-
));
INSERT INTO product_descriptions VALUES(2721-
,'CS'-
,UNISTR(-
'PC bra\0161na - L/S'-
),UNISTR(-
'\010cern\00e1 ko\017een\00e1 bra\0161na na po\010d\00edta\010d - v'||-
'elikost pro jeden p\0159enosn\00fd po\010d\00edta\010d s kapsami pro '||-
'n\00e1vody, p\0159\00eddavn\00fd hardware a pracovn\00ed dokumentaci.'||-
' Se\0159iditeln\00e9 ochrann\00e9 popruhy a odn\00edmateln\00e1 kapsa'||-
' na nap\00e1jec\00ed zdroj a kabely.'-
));
INSERT INTO product_descriptions VALUES(2722-
,'CS'-
,UNISTR(-
'PC bra\0161na - L/D'-
),UNISTR(-
'\010cern\00e1 ko\017een\00e1 bra\0161na na po\010d\00edta\010de - '||-
'velikost pro dva p\0159enosn\00e9 po\010d\00edta\010de s kapsami pro '||-
'p\0159\00eddavn\00fd hardware nebo n\00e1vody a pracovn\00ed dokument'||-
'aci. Se\0159iditeln\00e9 ochrann\00e9 popruhy a odn\00edmateln\00e9 k'||-
'apsy na nap\00e1jec\00ed zdroje a kabely. Pro pohodl\00ed popruh o dvoj'||-
'n\00e1sobn\00e9 \0161\00ed\0159ce.'-
));
INSERT INTO product_descriptions VALUES(2725-
,'CS'-
,UNISTR(-
'Strojn\00ed olej'-
),UNISTR(-
'Strojn\00ed olej pro maz\00e1n\00ed dv\00ed\0159ek a san\00ed mechan'||-
'ik CD-ROM. Samo\010distic\00ed se\0159izovateln\00e1 tryska pro jemn'||-
'\00fd nebo st\0159edn\00ed proud.'-
));
INSERT INTO product_descriptions VALUES(2782-
,'CS'-
,UNISTR(-
'PC bra\0161na - C/S'-
),UNISTR(-
'Textiln\00ed bra\0161na na po\010d\00edta\010de - velikost pro jeden '||-
'p\0159enosn\00fd po\010d\00edta\010d s kapsami pro p\0159\00eddavn'||-
'\00fd hardware a pracovn\00ed dokumentaci. Se\0159iditeln\00e9 ochrann'||-
'\00e9 popruhy a odn\00edmateln\00e1 kapsa na nap\00e1jec\00ed zdroj a'||-
' kabely. Vn\011bj\0161\00ed kapsa s rychlouz\00e1v\011brem pro snadn'||-
'\00fd p\0159\00edstup p\0159i cestov\00e1n\00ed.'-
));
INSERT INTO product_descriptions VALUES(3187-
,'CS'-
,UNISTR(-
'Plastov\00fd dr\017e\00e1k - B/HD'-
),UNISTR(-
'Plastov\00fd dr\017e\00e1k - modr\00fd, vysok\00e1 specifick\00e1 v'||-
'\00e1ha.'-
));
INSERT INTO product_descriptions VALUES(3189-
,'CS'-
,UNISTR(-
'Plastov\00fd dr\017e\00e1k - G'-
),UNISTR(-
'Plastov\00fd dr\017e\00e1k - zelen\00fd, standardn\00ed specifick'||-
'\00e1 v\00e1ha.'-
));
INSERT INTO product_descriptions VALUES(3191-
,'CS'-
,UNISTR(-
'Plastov\00fd dr\017e\00e1k - O'-
),UNISTR(-
'Plastov\00fd dr\017e\00e1k - oran\017eov\00fd, standardn\00ed specif'||-
'ick\00e1 v\00e1ha.'-
));
INSERT INTO product_descriptions VALUES(3193-
,'CS'-
,UNISTR(-
'Plastov\00fd dr\017e\00e1k - W/HD'-
),UNISTR(-
'Plastov\00fd dr\017e\00e1k - b\00edl\00fd, vysok\00e1 specifick'||-
'\00e1 v\00e1ha.'-
));
commit;
set define on
