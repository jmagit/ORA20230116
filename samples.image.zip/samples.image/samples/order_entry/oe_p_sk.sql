set define off
INSERT INTO product_descriptions VALUES(1726-
,'SK'-
,UNISTR(-
'LCD Monitor 11/PM'-
),UNISTR(-
'Pas\00edvny 11 palcov\00fd monitor na b\00e1ze kvapaln\00fdch kry'||-
'\0161t\00e1lov. Prakticky ploch\00e1 obrazovka s vysok\00fdm rozl'||-
'\00ed\0161en\00edm poskytuje vynikaj\00facu kvalitu obrazu so zn\00ed'||-
'\017een\00fdm odleskom.'-
));
INSERT INTO product_descriptions VALUES(2359-
,'SK'-
,UNISTR(-
'LCD monitor 9/PM'-
),UNISTR(-
'Pas\00edvny 9 palcov\00fd monitor na b\00e1ze kvapaln\00fdch kry\0161'||-
't\00e1lov. U\017eite si produktivitu, ktor\00fa dok\00e1\017ee prinie'||-
's\0165 mal\00fd monitor prostredn\00edctvom v\00e4\010d\0161ieho pra'||-
'covn\00e9ho priestoru na stole. \013dahk\00e1 in\0161tal\00e1cia s ko'||-
'mpatibilitou plug-and-play.'-
));
INSERT INTO product_descriptions VALUES(3060-
,'SK'-
,UNISTR(-
'Monitor 17/HR'-
),UNISTR(-
'CRT monitor, 17 palcov\00fd (vidite\013en\00e1 plocha 16 palcov) s vyso'||-
'k\00fdm rozl\00ed\0161en\00edm. V\00fdnimo\010dn\00fd obrazov\00fd'||-
' v\00fdkon a pr\00ednos \010fal\0161ieho obrazovkov\00e9ho priestoru.'||-
' Tento monitor pon\00faka ostr\00fd, na farby bohat\00fd obraz za neuve'||-
'rite\013en\00fa cenu. S mno\017estvom modern\00fdch funkci\00ed vr'||-
'\00e1tane ovl\00e1da\010dov zobrazenia zobrazovan\00fdch na obrazovke.'-
));
INSERT INTO product_descriptions VALUES(2243-
,'SK'-
,UNISTR(-
'Monitor 17/HR/F'-
),UNISTR(-
'17 palcov\00fd monitor (vidite\013en\00e1 plocha 16 palcov) s plochou o'||-
'brazovkou. Vysokohustotn\00e1 fot\00f3nov\00e1 d\00fdza so syst\00e9m'||-
'om Enhanced Elliptical Correction System prin\00e1\0161aj\00faca konzis'||-
'tentnej\0161ie, presnej\0161ie zaostrenie na obrazovke, dokonca aj v roh'||-
'och.'-
));
INSERT INTO product_descriptions VALUES(3057-
,'SK'-
,UNISTR(-
'Monitor 17/SD'-
),UNISTR(-
'CRT monitor, 17 palcov\00fd (vidite\013en\00e1 plocha 16 palcov) s kr'||-
'\00e1tkou h\013abkou. Poskytuje vynikaj\00facu jasnos\0165 a presnos'||-
'\0165 obrazu. Zabezpe\010duje profesion\00e1lnu farbu, technick\00e9 p'||-
'revedenie a pou\017e\00edvatelia vizualiz\00e1cie a anim\00e1cie objav'||-
'ia neobvykl\00fa vernos\0165 farby, ako aj ve\013ek\00fa pracovn\00fa'||-
' plochu s vy\0161\0161ou produktivitou.'-
));
INSERT INTO product_descriptions VALUES(3061-
,'SK'-
,UNISTR(-
'Monitor 19/SD'-
),UNISTR(-
'CRT monitor, 19 palcov\00fd (vidite\013en\00e1 plocha 18) s kr\00e1tko'||-
'u h\013abkou. Vysoko kontrastn\00e1 \010dierna povrchov\00e1 vrstva ob'||-
'razovky d\00e1va jedine\010dn\00fd kontrast a v\00fdkon v odtie\0148o'||-
'ch sivej. Novo skon\0161truovan\00e9, zosil\0148ovan\00e9 profesion'||-
'\00e1lne reproduktory s dynamickou basovou odozvou o\017eivuj\00fa v'||-
'\0161etky va\0161e multimedi\00e1lne zvukov\00e9 z\00e1\017eitky kri'||-
'\0161t\00e1\013eov\00fdm, vern\00fdm zvukom a bohat\00fdmi, hlbok'||-
'\00fdmi basov\00fdmi t\00f3nmi. Plus farebne odl\00ed\0161en\00e9 k'||-
'\00e1ble, jednoduch\00e1 in\0161tal\00e1cia typu plug-and-play a digit'||-
'\00e1lne ovl\00e1da\010de zobrazovan\00e9 na obrazovke znamenaj\00fa,'||-
' \017ee m\00e1te k dispoz\00edcii \00fa\017easn\00e9 multim\00e9di'||-
'\00e1 a neuverite\013en\00fd internet v priebehu nieko\013ek\00fdch m'||-
'in\00fat.'-
));
INSERT INTO product_descriptions VALUES(2245-
,'SK'-
,UNISTR(-
'Monitor 19/SD/M'-
),UNISTR(-
'19 palcov\00fd monitor (vidite\013en\00e1 plocha 18 palcov), monochroma'||-
'tick\00fd. Vynikaj\00faci obrazov\00fd v\00fdkon v kompaktnom dizajne.'||-
' Jednoduch\00e1, na obrazovke zobrazovan\00e1 ponuka umo\017e\0148uje '||-
'\013eahko nastavi\0165 rozmery obrazovky, farby a atrib\00faty obrazu. '||-
'Sta\010d\00ed zapoji\0165 monitor do po\010d\00edta\010da a m\00f4'||-
'\017eete za\010da\0165.'-
));
INSERT INTO product_descriptions VALUES(3065-
,'SK'-
,UNISTR(-
'Monitor 21/D'-
),UNISTR(-
'CRT monitor, 21 palcov\00fd (vidite\013en\00e1 plocha 20 palcov). Digit'||-
'\00e1lna technol\00f3gia OptiScan podporuje rozl\00ed\0161enia a\017e'||-
' do 1600 x 1200 pri 75 Hz. Rozmery (V x \0160 x H): 8,3 x 18,5 x 15 palco'||-
'v. Odpojite\013en\00e9 alebo pripojite\013en\00e9 z monitora nap\00e1'||-
'jan\00e9 reproduktory Platinum Series pon\00fakaj\00fa jasn\00fd zvuk '||-
'a pohodlie zabezpe\010den\00e9 konektorom digit\00e1lneho audio prehr'||-
'\00e1va\010da. Sta\010d\00ed zapoji\0165 digit\00e1lny audio prehr'||-
'\00e1va\010d a m\00f4\017eete po\010d\00fava\0165 hudbu bez zapnuti'||-
'a po\010d\00edta\010da.'-
));
INSERT INTO product_descriptions VALUES(3331-
,'SK'-
,UNISTR(-
'Monitor 21/HR'-
),UNISTR(-
'21 palcov\00fd monitor (vidite\013en\00e1 plocha 20 palcov) s vysok'||-
'\00fdm rozl\00ed\0161en\00edm. Tento monitor je ide\00e1lny pre podni'||-
'kov\00e9, DTP a graficky n\00e1ro\010dn\00e9 aplik\00e1cie. U\017eit'||-
'e si produktivitu, ktor\00fa dok\00e1\017ee prinies\0165 ve\013ek'||-
'\00fd monitor prostredn\00edctvom v\00e4\010d\0161ieho pracovn\00e9h'||-
'o priestoru na sp\00fa\0161\0165anie aplik\00e1ci\00ed.'-
));
INSERT INTO product_descriptions VALUES(2252-
,'SK'-
,UNISTR(-
'Monitor 21/HR/M'-
),UNISTR(-
'21 palcov\00fd monitor (vidite\013en\00e1 plocha 20 palcov) s vysok'||-
'\00fdm rozl\00ed\0161en\00edm, monochromatick\00fd. Ve\013ekos\0165'||-
': 35,6 x 29,6 x 33,3 cm (14,6 kg) Balenie: 40,53 x 31,24 x 35,39 cm (16,5 '||-
'kg). Horizont\00e1lna frekvencia 31,5 - 54 kHz, vertik\00e1lna frekvenci'||-
'a 50 - 120 Hz. Univerz\00e1lne nap\00e1janie 90 - 132 V, 50 - 60 Hz.'-
));
INSERT INTO product_descriptions VALUES(3064-
,'SK'-
,UNISTR(-
'Monitor 21/SD'-
),UNISTR(-
'21 palcov\00fd monitor (vidite\013en\00e1 plocha 20 palcov) s kr\00e1t'||-
'kou h\013abkou. Medzi vlastnosti patr\00ed 0,25-0,28 Aperture Grille Pit'||-
'ch, podpora rozl\00ed\0161enia a\017e do 1920 x 1200 pri 76 Hz, ponuka '||-
'zobrazovan\00e1 na obrazovke a vodiv\00fd antireflexn\00fd kryc\00ed f'||-
'ilter.'-
));
INSERT INTO product_descriptions VALUES(3155-
,'SK'-
,UNISTR(-
'Nosn\00e9 rameno na monitor - HD'-
),UNISTR(-
'Nosn\00e9 rameno na monitor, ur\010den\00e9 na vy\0161\0161ie za'||-
'\0165a\017eenie, maxim\00e1lna hmotnos\0165 monitora 30 kg'-
));
INSERT INTO product_descriptions VALUES(3234-
,'SK'-
,UNISTR(-
'Nosn\00e9 rameno na monitor - STD'-
),UNISTR(-
'\0160tandardn\00e9 nosn\00e9 rameno na monitor, maxim\00e1lna hmotnos'||-
'\0165 monitora 10 kg'-
));
INSERT INTO product_descriptions VALUES(3350-
,'SK'-
,UNISTR(-
'Plazmov\00fd monitor 10/LE/VGA'-
),UNISTR(-
'10 palcov\00fd n\00edzkoenergetick\00fd plazmov\00fd monitor, rozl'||-
'\00ed\0161enie VGA'-
));
INSERT INTO product_descriptions VALUES(2236-
,'SK'-
,UNISTR(-
'Plazmov\00fd monitor 10/TFT/XGA'-
),UNISTR(-
'10 palcov\00fd monitor s plochou obrazovkou TFT XGA pre laptopy'-
));
INSERT INTO product_descriptions VALUES(3054-
,'SK'-
,UNISTR(-
'Plazmov\00fd monitor 10/XGA'-
),UNISTR(-
'10 palcov\00fd \0161tandardn\00fd plazmov\00fd monitor, rozl\00ed'||-
'\0161enie XGA. T\00e1to prakticky ploch\00e1 obrazovka s vysok\00fdm r'||-
'ozl\00ed\0161en\00edm poskytuje vynikaj\00facu kvalitu obrazu so zn'||-
'\00ed\017een\00fdm odleskom.'-
));
INSERT INTO product_descriptions VALUES(1782-
,'SK'-
,UNISTR(-
'Compact 400/DQ'-
),UNISTR(-
'Vysokor\00fdchlostn\00e1 tla\010diare\0148 s konceptovou kvalitou tla'||-
'\010de a r\00fdchlos\0165ou 400 znakov za sekundu. Rozmery (V x \0160 '||-
'x H): 17,34 x 24,26 x 26,32 palcov. Rozhranie: S\00e9riov\00e9 pripojeni'||-
'e RS-232 (9-pinov\00e9), \017eiadne roz\0161irovacie sloty. Ve\013ekos'||-
'\0165 papiera: A4, US Letter.'-
));
INSERT INTO product_descriptions VALUES(2430-
,'SK'-
,UNISTR(-
'Compact 400/LQ'-
),UNISTR(-
'Vysokor\00fdchlostn\00e1 tla\010diare\0148 s listovou kvalitou tla'||-
'\010de a r\00fdchlos\0165ou 400 znakov za sekundu. Rozmery (V x \0160 '||-
'x H): 12,37 x 27,96 x 23,92 palcov. Rozhranie: S\00e9riov\00e9 pripojeni'||-
'e RS-232 (25-pinov\00e9), 3 roz\0161irovacie sloty. Ve\013ekos\0165 pa'||-
'piera: A2, A3, A4.'-
));
INSERT INTO product_descriptions VALUES(1792-
,'SK'-
,UNISTR(-
'Industrial 600/DQ'-
),UNISTR(-
'Vysokor\00fdchlostn\00e1 tla\010diare\0148 s konceptovou kvalitou tla'||-
'\010de a r\00fdchlos\0165ou 600 znakov za sekundu, so \0161irok\00fdm'||-
' voz\00edkom a mo\017enos\0165ou farebnej tla\010de. Rozmery (V x '||-
'\0160 x H): 22,31 x 25,73 x 20,12 palcov. Ve\013ekos\0165 papiera: 3x5 '||-
'palcov\00fd a\017e 11x17 palcov\00fd form\00e1t "full bleed wide".'-
));
INSERT INTO product_descriptions VALUES(1791-
,'SK'-
,UNISTR(-
'Industrial 700/HD'-
),UNISTR(-
'Ihli\010dkov\00e1 tla\010diare\0148 s r\00fdchlos\0165ou 700 znakov '||-
'za sekundu, s pevnej\0161\00edm krytom a ochranou proti prachu na priemy'||-
'seln\00e9 pou\017eitie. Rozhranie: Centronics parallel, v zhode s IEEE 1'||-
'284. Ve\013ekos\0165 papiera: 3x5 palcov\00fd a\017e 11x17 palcov'||-
'\00fd form\00e1t "full bleed wide". Pam\00e4\0165: 4 MB. Rozmery (V x '||-
'\0160 x H): 9,3 x 16,5 x 13 palcov.'-
));
INSERT INTO product_descriptions VALUES(2302-
,'SK'-
,UNISTR(-
'Inkjet B/6'-
),UNISTR(-
'Atramentov\00e1 tla\010diare\0148, \010diernobiela, 6 str\00e1n za mi'||-
'n\00fatu, rozl\00ed\0161enie 600 x 300 dpi. Rozhranie: Centronics paral'||-
'lel, v zhode s IEEE 1284. Rozmery (V x \0160 x H): 7,3 x 17,5 x 14 palcov'||-
'. Ve\013ekos\0165 papiera: A3, A4, US legal. \017diadne roz\0161irovac'||-
'ie sloty.'-
));
INSERT INTO product_descriptions VALUES(2453-
,'SK'-
,UNISTR(-
'Inkjet C/4'-
),UNISTR(-
'Atramentov\00e1 tla\010diare\0148, farebn\00e1 (s dvoma oddelen\00fdm'||-
'i atramentov\00fdmi kartrid\017emi), 6 strany za min\00fatu \010dierno'||-
'bielo, 4 strany za min\00fatu vo farbe, rozl\00ed\0161enie 600 x 300 dp'||-
'i. Rozhranie: Paraleln\00e9 rozhranie v s\00falade s Biodirectional IEEE'||-
' 1284 a RS-232 s\00e9riov\00e9 (9-pinov\00e9) rozhranie, 2 otvoren'||-
'\00e9 roz\0161irovacie sloty EIO. Pam\00e4\0165: 8 MB, 96 kB prij'||-
'\00edmac\00ed buffer.'-
));
INSERT INTO product_descriptions VALUES(1797-
,'SK'-
,UNISTR(-
'Inkjet C/8/HQ'-
),UNISTR(-
'Atramentov\00e1 tla\010diare\0148, farebn\00e1, 8 str\00e1n za min'||-
'\00fatu, vysok\00e9 rozl\00ed\0161enie (fotografick\00e1 kvalita). Pa'||-
'm\00e4\0165: 16 MB. Rozmery (V x \0160 x H): 7,3 x 17,5 x 14 palcov. Ve'||-
'\013ekos\0165 papiera: A4, US Letter, ob\00e1lky. Rozhranie: Centronics'||-
' parallel, v zhode s IEEE 1284.'-
));
INSERT INTO product_descriptions VALUES(2459-
,'SK'-
,UNISTR(-
'LaserPro 1200/8/BW'-
),UNISTR(-
'Profesion\00e1lna \010diernobiela tla\010diare\0148, rozl\00ed\0161e'||-
'nie 1200 dpi, 8 str\00e1n za min\00fatu. Rozmery (V x \0160 x H): 22,37'||-
' x 19,86 x 21,92 palcov. Softv\00e9r: Roz\0161\00edren\00e1 podpora ov'||-
'l\00e1da\010dov pre SPNIX v4.0; zabudovan\00e9 ovl\00e1da\010de tla'||-
'\010diarn\00ed pre MS-DOS: \0161k\00e1lovacia technol\00f3gia ZoomSma'||-
'rt, billboard, handout, zrkadlenie, vodotla\010d, uk\00e1\017eka pred t'||-
'la\010dou, quick sets, emul\00e1cia okrajov laserovej tla\010diarne.'-
));
INSERT INTO product_descriptions VALUES(3127-
,'SK'-
,UNISTR(-
'LaserPro 600/6/BW'-
),UNISTR(-
'\0160tandardn\00e1 \010diernobiela laserov\00e1 tla\010diare\0148, r'||-
'ozl\00ed\0161enie 600 dpi, 6 str\00e1n za min\00fatu. Rozhranie: Centr'||-
'onics parallel, v zhode s IEEE 1284. Pam\00e4\0165: 8 MB, 96 kB prij'||-
'\00edmac\00ed buffer. Ovl\00e1da\010d kompatibiln\00fd s MS-DOS ToolB'||-
'ox utilities for SPNIX AutoCAM v.17.'-
));
INSERT INTO product_descriptions VALUES(2254-
,'SK'-
,UNISTR(-
'HD 10GB /I'-
),UNISTR(-
'10 GB pevn\00e1 diskov\00e1 jednotka (intern\00e1). Tieto jednotky s'||-
'\00fa ur\010den\00e9 na pou\017eitie v dne\0161nom na d\00e1ta n'||-
'\00e1ro\010dnom podnikovom prostred\00ed a s\00fa ide\00e1lne na pou'||-
'\017eitie v aplik\00e1ci\00e1ch RAID. Univerz\00e1lne volite\013en'||-
'\00e9 kity s\00fa konfigurovan\00e9 a predmontovan\00e9 v pr\00edslu'||-
'\0161n\00fdch blokoch ur\010den\00fdch na na okam\017eit\00fa in'||-
'\0161tal\00e1ciu do v\00e1\0161ho podnikov\00e9ho servera alebo pam'||-
'\00e4\0165ov\00e9ho syst\00e9mu.'-
));
INSERT INTO product_descriptions VALUES(3353-
,'SK'-
,UNISTR(-
'HD 10GB /R'-
),UNISTR(-
'10 GB vyberate\013en\00e1 pevn\00e1 diskov\00e1 jednotka. Diskov\00e9'||-
' jednotky Supra7 poskytuj\00fa najnov\0161iu technol\00f3giu v z\00e1u'||-
'jme zlep\0161enia podnikov\00e9ho v\00fdkonu, pri\010dom zvy\0161uj'||-
'\00fa maxim\00e1lnu r\00fdchlos\0165 prenosu d\00e1t a\017e na 160 M'||-
'B/s.'-
));
INSERT INTO product_descriptions VALUES(3069-
,'SK'-
,UNISTR(-
'HD 10GB /S'-
),UNISTR(-
'10 GB pevn\00e1 diskov\00e1 jednotka pre Standard Mount. Sp\00e4tne kom'||-
'patibiln\00e1 so syst\00e9mami Supra5. Pou\017e\00edvatelia m\00f4'||-
'\017eu vo\013ene nasadzova\0165 tieto jednotky a r\00fdchlo z\00edska'||-
'va\0165 zv\00fd\0161en\00fa pam\00e4\0165ov\00fa kapacitu. Jednotky'||-
' Supra eliminuj\00fa riziko firmv\00e9rovej nekompatibility.'-
));
INSERT INTO product_descriptions VALUES(2253-
,'SK'-
,UNISTR(-
'HD 10GB @5400 /SE'-
),UNISTR(-
'10 GB pevn\00fd disk (extern\00fd), rozhranie SCSI, 5400 ot./min. Univer'||-
'z\00e1lne volite\013en\00e9 kity s\00fa konfigurovan\00e9 a predmonto'||-
'van\00e9 v pr\00edslu\0161n\00fdch blokoch ur\010den\00fdch na na ok'||-
'am\017eit\00fa in\0161tal\00e1ciu do v\00e1\0161ho podnikov\00e9ho '||-
'servera alebo pam\00e4\0165ov\00e9ho syst\00e9mu. Jednotky Supra elimi'||-
'nuj\00fa riziko firmv\00e9rovej nekompatibility.'-
));
INSERT INTO product_descriptions VALUES(3354-
,'SK'-
,UNISTR(-
'HD 12GB /I'-
),UNISTR(-
'12 GB pevn\00e1 diskov\00e1 jednotka (intern\00e1). Jednotky Supra elim'||-
'inuj\00fa riziko firmv\00e9rovej nekompatibility. Sp\00e4tn\00e1 kompa'||-
'tibilita: Zariadenia Supra2 a Supra3 m\00f4\017eete kombinova\0165 aleb'||-
'o p\00e1rova\0165, \010d\00edm mo\017eno dosahova\0165 optimalizovan'||-
'\00e9 rie\0161enia a bud\00faci rast.'-
));
INSERT INTO product_descriptions VALUES(3072-
,'SK'-
,UNISTR(-
'HD 12GB /N'-
),UNISTR(-
'12 GB pevn\00e1 diskov\00e1 jednotka pre Narrow Mount. Zahor\00faca nap'||-
'ojite\013en\00e9 diskov\00e9 jednotky Supra9 poskytuj\00fa mo\017enos'||-
'\0165 in\0161talova\0165 alebo odstra\0148ova\0165 jednotky on-line. '||-
'Na\0161e okam\017eite napojite\013en\00e9 pevn\00e9 diskov\00e9 jedn'||-
'otky musia vyhovova\0165 na\0161im pr\00edsnym \0161tandardom spo'||-
'\013eahlivosti a v\00fdkonu.'-
));
INSERT INTO product_descriptions VALUES(3334-
,'SK'-
,UNISTR(-
'HD 12GB /R'-
),UNISTR(-
'12 GB vyberate\013en\00e1 pevn\00e1 diskov\00e1 jednotka. Vzh\013eado'||-
'm na kompatibilitu pre mnoh\00e9 podnikov\00e9 platformy m\00f4\017eet'||-
'e vo\013ene nasadzova\0165 tieto jednotky a r\00fdchlo z\00edskava'||-
'\0165 zv\00fd\0161en\00fa pam\00e4\0165ov\00fa kapacitu. Univerz'||-
'\00e1lne diskov\00e9 jednotky Supra7 s\00fa druhou gener\00e1ciou vyso'||-
'kov\00fdkonn\00fdch zahor\00faca napojite\013en\00fdch jednotiek s ko'||-
'mpatibilitou pre firemn\00e9 servery a extern\00e9 pam\00e4\0165ov'||-
'\00e9 priestory.'-
));
INSERT INTO product_descriptions VALUES(3071-
,'SK'-
,UNISTR(-
'HD 12GB /S'-
),UNISTR(-
'12 GB pevn\00e1 diskov\00e1 jednotka pre Standard Mount. Bez preru\0161'||-
'enia prev\00e1dzky napojite\013en\00e9 diskov\00e9 jednotky Supra9 pos'||-
'kytuj\00fa mo\017enos\0165 in\0161talova\0165 alebo odstra\0148ova'||-
'\0165 jednotky on-line. Na\0161e okam\017eite napojite\013en\00e9 pev'||-
'n\00e9 diskov\00e9 jednotky musia vyhovova\0165 na\0161im pr\00edsnym'||-
' \0161tandardom spo\013eahlivosti a v\00fdkonu.'-
));
INSERT INTO product_descriptions VALUES(2255-
,'SK'-
,UNISTR(-
'HD 12GB @7200 /SE'-
),UNISTR(-
'12 GB pevn\00fd disk (extern\00fd), SCSI, 7200 ot./min. Tieto jednotky s'||-
'\00fa ur\010den\00e9 na pou\017eitie v dne\0161n\00fdch n\00e1ro'||-
'\010dn\00fdch, d\00e1tovo kritick\00fdch podnikov\00fdch prostrediach'||-
' a mo\017eno ich pou\017ei\0165 v aplik\00e1ci\00e1ch RAID. Univerz'||-
'\00e1lne volite\013en\00e9 kity s\00fa konfigurovan\00e9 a predmontov'||-
'an\00e9 v pr\00edslu\0161n\00fdch zahor\00faca in\0161talovate\013e'||-
'n\00fdch blokoch na okam\017eit\00fa in\0161tal\00e1ciu do firemn'||-
'\00e9ho servera alebo pam\00e4\0165ov\00e9ho syst\00e9mu.'-
));
INSERT INTO product_descriptions VALUES(1743-
,'SK'-
,UNISTR(-
'HD 18.2GB @10000 /E'-
),UNISTR(-
'Extern\00e1 pevn\00e1 diskov\00e1 jednotka - 18,2 GB, r\00fdchlos'||-
'\0165 a\017e do 10 000 ot./min. Tieto jednotky s\00fa ur\010den\00e9 '||-
'na d\00e1ta n\00e1ro\010dn\00e9 podnikov\00e9 prostredie a s\00fa id'||-
'e\00e1lne na pou\017eitie v aplik\00e1ci\00e1ch RAID.'-
));
INSERT INTO product_descriptions VALUES(2382-
,'SK'-
,UNISTR(-
'HD 18.2GB@10000 /I'-
),UNISTR(-
'18,2 GB SCSI pevn\00fd disk s 10 000 ot./min (intern\00fd). Univerz'||-
'\00e1lne diskov\00e9 jednotky Supra7 poskytuj\00fa bezkonkuren\010dn'||-
'\00fa \00farove\0148 ochrany a zjednodu\0161enia invest\00edci\00ed '||-
'pre z\00e1kazn\00edkov t\00fdm, \017ee zabezpe\010duj\00fa kompatibi'||-
'litu jednotiek pre mnoh\00e9 podnikov\00e9 platformy.'-
));
INSERT INTO product_descriptions VALUES(3399-
,'SK'-
,UNISTR(-
'HD 18GB /SE'-
),UNISTR(-
'18 GB SCSI extern\00e1 pevn\00e1 diskov\00e1 jednotka. Univerz\00e1lne'||-
' diskov\00e9 jednotky Supra5 m\00f4\017eu by\0165 bez preru\0161enia '||-
'\010dinnosti zapojen\00e9 do r\00f4znych serverov, RAID pol\00ed a ext'||-
'ern\00fdch pam\00e4\0165ov\00fdch priestorov.'-
));
INSERT INTO product_descriptions VALUES(3073-
,'SK'-
,UNISTR(-
'HD 6GB /I'-
),UNISTR(-
'6 GB pevn\00e1 diskov\00e1 jednotka (intern\00e1). Jednotky Supra elimi'||-
'nuj\00fa riziko firmv\00e9rovej nekompatibility.'-
));
INSERT INTO product_descriptions VALUES(1768-
,'SK'-
,UNISTR(-
'HD 8.2GB @5400'-
),UNISTR(-
'Pevn\00e1 diskov\00e1 jednotka - 8,2 GB, r\00fdchlos\0165 a\017e do 5'||-
' 400 ot./min. Jednotky Supra eliminuj\00fa riziko firmv\00e9rovej nekomp'||-
'atibility. \0160tandardn\00e9 s\00e9riov\00e9 rozhranie RS-232.'-
));
INSERT INTO product_descriptions VALUES(2410-
,'SK'-
,UNISTR(-
'HD 8.4GB @5400'-
),UNISTR(-
'8,4 GB pevn\00fd disk s 5400 ot./min. Zn\00ed\017een\00e9 invest\00ed'||-
'cie: Tieto jednotky mo\017eno vyu\017e\00edva\0165 pre r\00f4zne podn'||-
'ikov\00e9 platformy. T\00e1to zahor\00faca napojite\013en\00e1 pevn'||-
'\00e1 diskov\00e1 jednotka mus\00ed vyhovova\0165 pr\00edsnym \0161t'||-
'andardom spo\013eahlivosti a v\00fdkonu.'-
));
INSERT INTO product_descriptions VALUES(2257-
,'SK'-
,UNISTR(-
'HD 8GB /I'-
),UNISTR(-
'8 GB pevn\00e1 diskov\00e1 jednotka (intern\00e1). Bez preru\0161enia '||-
'prev\00e1dzky napojite\013en\00e9 diskov\00e9 jednotky Supra9 poskytuj'||-
'\00fa mo\017enos\0165 in\0161talova\0165 alebo odstra\0148ova\0165 '||-
'jednotky on-line. Sp\00e4tn\00e1 kompatibilita: Zariadenia Supra2 a Supr'||-
'a3 m\00f4\017eete kombinova\0165, \010d\00edm mo\017eno dosahova'||-
'\0165 optimalizovan\00e9 rie\0161enia a zabezpe\010di\0165 bud\00fac'||-
'i rast.'-
));
INSERT INTO product_descriptions VALUES(3400-
,'SK'-
,UNISTR(-
'HD 8GB /SE'-
),UNISTR(-
'8 GB SCSI pevn\00e1 diskov\00e1 jednotka (extern\00e1). Diskov\00e9 je'||-
'dnotky Supra7 poskytuj\00fa najnov\0161iu technol\00f3giu v z\00e1ujme'||-
' zlep\0161enia podnikov\00e9ho v\00fdkonu, pri\010dom zvy\0161uj'||-
'\00fa maxim\00e1lnu r\00fdchlos\0165 prenosu d\00e1t a\017e na 255 M'||-
'B/s.'-
));
INSERT INTO product_descriptions VALUES(3355-
,'SK'-
,UNISTR(-
'HD 8GB /SI'-
),UNISTR(-
'8 GB SCSI pevn\00e1 diskov\00e1 jednotka, intern\00e1. Vzh\013eadom na'||-
' kompatibilitu pre mnoh\00e9 podnikov\00e9 platformy m\00f4\017eete vo'||-
'\013ene nasadzova\0165 tieto jednotky a r\00fdchlo z\00edskava\0165 z'||-
'v\00fd\0161en\00fa pam\00e4\0165ov\00fa kapacitu.'-
));
INSERT INTO product_descriptions VALUES(1772-
,'SK'-
,UNISTR(-
'HD 9.1GB @10000'-
),UNISTR(-
'Pevn\00e1 diskov\00e1 jednotka -9,1 GB, r\00fdchlos\0165 a\017e do 10'||-
' 000 ot./min. Tieto jednotky s\00fa ur\010den\00e9 na pou\017eitie v d'||-
'\00e1tovo kritick\00fdch podnikov\00fdch prostrediach. Jednoduchos'||-
'\0165 pou\017eitia: jednotky, ktor\00e9 potrebujete, si m\00f4\017eet'||-
'e vybera\0165 bez oh\013eadu na aplik\00e1ciu, pre ktor\00fa bud\00fa'||-
' nasaden\00e9.'-
));
INSERT INTO product_descriptions VALUES(2414-
,'SK'-
,UNISTR(-
'HD 9.1GB @10000 /I'-
),UNISTR(-
'9,1 GB SCSI pevn\00fd disk s 10 000 ot./min (intern\00fd). Diskov\00e9 '||-
'jednotky Supra7 s\00fa k dispoz\00edcii s r\00fdchlos\0165ami 10 000 o'||-
't./min a kapacitami 18 GB a 9,1 GB. Rozhrania SCSI a RS-232.'-
));
INSERT INTO product_descriptions VALUES(2415-
,'SK'-
,UNISTR(-
'HD 9.1GB @7200'-
),UNISTR(-
'9,1 GB pevn\00fd disk s 7200 ot./min. Univerz\00e1lne volite\013en'||-
'\00e9 kity s\00fa konfigurovan\00e9 a predmontovan\00e9 v pr\00edslu'||-
'\0161n\00fdch zahor\00faca in\0161talovate\013en\00fdch blokoch na o'||-
'kam\017eit\00fa in\0161tal\00e1ciu do firemn\00e9ho servera alebo pam'||-
'\00e4\0165ov\00e9ho syst\00e9mu.'-
));
INSERT INTO product_descriptions VALUES(2395-
,'SK'-
,UNISTR(-
'32MB Cache /M'-
),UNISTR(-
'32 MB zrkadlen\00e1 pam\00e4\0165 cache (100-MHz registrovan\00e1 SDRA'||-
'M)'-
));
INSERT INTO product_descriptions VALUES(1755-
,'SK'-
,UNISTR(-
'32MB Cache /NM'-
),UNISTR(-
'32 MB nezrkadlen\00e1 pam\00e4\0165 cache'-
));
INSERT INTO product_descriptions VALUES(2406-
,'SK'-
,UNISTR(-
'64MB Cache /M'-
),UNISTR(-
'64 MB zrkadlen\00e1 pam\00e4\0165 cache'-
));
INSERT INTO product_descriptions VALUES(2404-
,'SK'-
,UNISTR(-
'64MB Cache /NM'-
),UNISTR(-
'64 MB nezrkadlen\00e1 pam\00e4\0165 cache. Pam\00e4\0165ov\00e9 '||-
'\010dipy FPM s\00fa implementovan\00e9 na 5 voltov\00fdch SIMM, ale s'||-
'\00fa k dispoz\00edcii aj na 3,3 voltov\00e9 DIMM.'-
));
INSERT INTO product_descriptions VALUES(1770-
,'SK'-
,UNISTR(-
'8MB Cache /NM'-
),UNISTR(-
'8 MB nezrkadlen\00e1 pam\00e4\0165 cache (100-MHz registrovan\00e1 SDR'||-
'AM)'-
));
INSERT INTO product_descriptions VALUES(2412-
,'SK'-
,UNISTR(-
'8 MB EDO pam\00e4\0165'-
),UNISTR(-
'8 MB 8 x 32 EDO SIM pam\00e4\0165. EDO (Extended Data Out) pam\00e4'||-
'\0165 sa l\00ed\0161i od FPM malou, ale v\00fdznamnou zmenou kon\0161'||-
'trukcie. Na rozdiel od FPM ovl\00e1da\010de d\00e1tov\00e9ho v\00fdst'||-
'upu pre EDO ost\00e1vaj\00fa zapnut\00e9, ke\010f pam\00e4\0165ov'||-
'\00fd radi\010d odstr\00e1ni adresu st\013apca, aby za\010dal nasledu'||-
'j\00faci cyklus. Preto nov\00fd d\00e1tov\00fd cyklus m\00f4\017ee z'||-
'a\010da\0165 sk\00f4r, ako sa skon\010d\00ed predch\00e1dzaj\00faci'||-
'. EDO je k dispoz\00edcii na SIMM a DIMM v 3,3 a 5 voltov\00fdch verzi'||-
'\00e1ch.'-
));
INSERT INTO product_descriptions VALUES(2378-
,'SK'-
,UNISTR(-
'DIMM - 128 MB'-
),UNISTR(-
'128 MB DIMM pam\00e4\0165. Hlavn\00fd d\00f4vod na zmenu zo SIMM na DI'||-
'MM je podpora vy\0161\0161\00edch zbernicov\00fdch \0161\00edrok 64-'||-
'bitov\00fdch procesorov. DIMM maj\00fa \0161\00edrku 64 alebo 72 bitov'||-
'; SIMM maj\00fa \0161\00edrku len 32 alebo 36 bitov (s paritou).'-
));
INSERT INTO product_descriptions VALUES(3087-
,'SK'-
,UNISTR(-
'DIMM - 16 MB'-
),UNISTR(-
'Citrus OLX DIMM - kapacita 16 MB.'-
));
INSERT INTO product_descriptions VALUES(2384-
,'SK'-
,UNISTR(-
'DIMM - 1GB'-
),UNISTR(-
'Pam\00e4\0165ov\00fd DIMM: RAM - kapacita 1 GB.'-
));
INSERT INTO product_descriptions VALUES(1749-
,'SK'-
,UNISTR(-
'DIMM - 256MB'-
),UNISTR(-
'Pam\00e4\0165ov\00fd DIMM: RAM 256 MB. (100-MHz registrovan\00e1 SDRAM'||-
')'-
));
INSERT INTO product_descriptions VALUES(1750-
,'SK'-
,UNISTR(-
'DIMM - 2GB'-
),UNISTR(-
'Pam\00e4\0165ov\00fd DIMM: RAM, kapacita 2 GB.'-
));
INSERT INTO product_descriptions VALUES(2394-
,'SK'-
,UNISTR(-
'DIMM - 32MB'-
),UNISTR(-
'32 MB roz\0161\00edrenie DIMM pam\00e4te.'-
));
INSERT INTO product_descriptions VALUES(2400-
,'SK'-
,UNISTR(-
'DIMM - 512 MB'-
),UNISTR(-
'512 MB DIMM pam\00e4\0165. Zlep\0161en\00e1 granularita roz\0161'||-
'\00edren\00ed pam\00e4te: Je potrebn\00fdch menej DIMM na roz\0161'||-
'\00edrenie syst\00e9mu, ako by bolo treba pri pou\017eit\00ed SIMM v t'||-
'om istom syst\00e9me. Zv\00fd\0161en\00e9 maxim\00e1lne pam\00e4'||-
'\0165ov\00e9 stropy: Pri rovnakom po\010dte pam\00e4\0165ov\00fdch s'||-
'lotov je maxim\00e1lna pam\00e4\0165 syst\00e9mu pri pou\017eit\00ed'||-
' DIMM v\00e4\010d\0161ia ako pri pou\017eit\00ed SIMM. DIMM maj\00fa'||-
' oddelen\00e9 kontakty na ka\017edej strane dosky, \010do poskytuje dvo'||-
'jn\00e1sobn\00fa d\00e1tov\00fa r\00fdchlos\0165 oproti jednej SIMM.'-
));
INSERT INTO product_descriptions VALUES(1763-
,'SK'-
,UNISTR(-
'DIMM - 64MB'-
),UNISTR(-
'Pam\00e4\0165ov\00fd DIMM: RAM, 64 MB (100-MHz neregistrovan\00e1 ECC '||-
'SDRAM)'-
));
INSERT INTO product_descriptions VALUES(2396-
,'SK'-
,UNISTR(-
'EDO - 32MB'-
),UNISTR(-
'Pam\00e4\0165 EDO SIM: RAM, 32 MB (100-MHz neregistrovan\00e1 ECC SDRAM'||-
'). Rovnako ako FPM je EDO k dispoz\00edcii na SIMM a DIMM v 3,3 a 5 volto'||-
'v\00fdch verzi\00e1ch. Pam\00e4\0165 EDO nemus\00ed fungova\0165, ak'||-
' je in\0161talovan\00e1 v po\010d\00edta\010di, ktor\00fd nebol skon'||-
'\0161truovan\00fd tak, aby ju podporoval.'-
));
INSERT INTO product_descriptions VALUES(2272-
,'SK'-
,UNISTR(-
'RAM - 16 MB'-
),UNISTR(-
'Pam\00e4\0165ov\00fd SIMM: RAM - kapacita 16 MB.'-
));
INSERT INTO product_descriptions VALUES(2274-
,'SK'-
,UNISTR(-
'RAM - 32 MB'-
),UNISTR(-
'Pam\00e4\0165ov\00fd SIMM: RAM - kapacita 32 MB.'-
));
INSERT INTO product_descriptions VALUES(3090-
,'SK'-
,UNISTR(-
'RAM - 48 MB'-
),UNISTR(-
'RAM, SIMM - kapacita 48 MB.'-
));
INSERT INTO product_descriptions VALUES(1739-
,'SK'-
,UNISTR(-
'SDRAM - 128 MB'-
),UNISTR(-
'Pam\00e4\0165 SDRAM - kapacita 128 MB. SDRAM m\00f4\017ee pristupova'||-
'\0165 k d\00e1tam r\00fdchlos\0165ou a\017e do 100 MHz, \010do je a'||-
'\017e \0161tyrikr\00e1t r\00fdchlej\0161ie ako \0161tandardn\00e9 D'||-
'RAM. V\00fdhody SDRAM v\0161ak mo\017eno plne realizova\0165 len na po'||-
'\010d\00edta\010doch skon\0161truovan\00fdch na podporu SDRAM. SDRAM '||-
'je k dispoz\00edcii pre 5 a 3,3 voltov\00e9 DIMM.'-
));
INSERT INTO product_descriptions VALUES(3359-
,'SK'-
,UNISTR(-
'SDRAM - 16 MB'-
),UNISTR(-
'Roz\0161irovac\00ed modul pam\00e4te SDRAM, 16 MB. SDRAM (Synchronous D'||-
'ynamic Random Access Memory) bola uveden\00e1 po EDO. Jej architekt\00fa'||-
'ra a fungovanie s\00fa zalo\017een\00e9 na \0161tandardnej DRAM, ale S'||-
'DRAM poskytuje revolu\010dn\00fa zmenu v hlavnej pam\00e4ti, ktor\00e1'||-
' \010falej zni\017euje \010dasy vyvolania d\00e1t. SDRAM je synchroniz'||-
'ovan\00e1 na syst\00e9mov\00e9 hodiny, ktor\00e9 riadia CPU. To znamen'||-
'\00e1, \017ee syst\00e9mov\00e9 hodiny riadiace funkcie mikroprocesora'||-
' riadia aj funkcie SDRAM. To umo\017e\0148uje pam\00e4\0165ov\00e9mu '||-
'radi\010du zisti\0165 cyklus hod\00edn, v ktorom bude d\00e1tov\00e1 '||-
'po\017eiadavka vykonan\00e1, a t\00fdm eliminova\0165 oneskorenia '||-
'\010dasovania.'-
));
INSERT INTO product_descriptions VALUES(3088-
,'SK'-
,UNISTR(-
'SDRAM - 32 MB'-
),UNISTR(-
'Modul SDRAM s ECC - kapacita 32 MB. SDRAM m\00e1 viacero pam\00e4\0165o'||-
'v\00fdch b\00e1nk, ktor\00e9 m\00f4\017eu pracova\0165 simult\00e1n'||-
'ne. Prep\00ednanie medzi bankami umo\017e\0148uje kontinu\00e1lny d'||-
'\00e1tov\00fd tok.'-
));
INSERT INTO product_descriptions VALUES(2276-
,'SK'-
,UNISTR(-
'SDRAM - 48 MB'-
),UNISTR(-
'Pam\00e4\0165ov\00fd SIMM: RAM - 48 MB. SDRAM m\00f4\017ee fungova'||-
'\0165 v monolitnom re\017eime. Ke\010f sa v monolitnom re\017eime pris'||-
'tupuje k jednej d\00e1tovej adrese, vyvol\00e1 sa cel\00fd d\00e1tov'||-
'\00fd blok namiesto jednej \010dasti. Predpoklad\00e1 sa, \017ee nasle'||-
'duj\00face d\00e1ta, ktor\00e9 sa bud\00fa po\017eadova\0165, bud'||-
'\00fa d\00e1ta nasleduj\00face po predch\00e1dzaj\00facich. Ke\010f'||-
'\017ee ide o zvy\010dajn\00fa situ\00e1ciu, d\00e1ta sa vlastne pripr'||-
'avuj\00fa vopred.'-
));
INSERT INTO product_descriptions VALUES(3086-
,'SK'-
,UNISTR(-
'VRAM - 16 MB'-
),UNISTR(-
'Citrus Video RAM modul - kapacita 16 MB. VRAM pou\017e\00edva video syst'||-
'\00e9m v po\010d\00edta\010di na uchov\00e1vanie video inform\00e1ci'||-
'\00ed a je vyhraden\00e1 v\00fdlu\010dne na video oper\00e1cie. Pam'||-
'\00e4\0165 bola vyvinut\00e1 za \00fa\010delom poskytnutia kontinu'||-
'\00e1lnych tokov s\00e9riov\00fdch d\00e1t na obnovovanie video obrazo'||-
'viek.'-
));
INSERT INTO product_descriptions VALUES(3091-
,'SK'-
,UNISTR(-
'VRAM - 64 MB'-
),UNISTR(-
'Pam\00e4\0165ov\00fd modul Citrus Video RAM - kapacita 64 MB. Fyzicky v'||-
'yzer\00e1 VRAM rovnako ako DRAM s pridan\00fdm hardv\00e9rom, ktor'||-
'\00fd sa naz\00fdva posunovac\00ed register. Osobitnou vlastnos\0165ou'||-
' VRAM je, \017ee dok\00e1\017ee prenies\0165 cel\00fd riadok d\00e1t'||-
' (a\017e do 256 bitov) do tohto posunovacieho registra v jedinom cykle ho'||-
'd\00edn. T\00e1to schopnos\0165 v\00fdrazne zni\017euje \010das na'||-
'\010d\00edtania, ke\010f\017ee po\010det vyvolan\00ed sa zni\017euj'||-
'e z mo\017en\00fdch 256 na jedin\00e9 vyvolanie. Hlavn\00fdm pr\00edn'||-
'osom posunovacieho registra na v\00fdpisy d\00e1t je, \017ee uvo\013e'||-
'\0148uje CPU na obnovovanie obrazovky namiesto na\010d\00edtavania d'||-
'\00e1t, \010d\00edm zdvojn\00e1sobuje d\00e1tov\00fa \0161\00edrku'||-
' p\00e1sma. Z tohto d\00f4vodu sa VRAM \010dasto ozna\010duje ako dvoj'||-
'portov\00e1. Posunovac\00ed register sa v\0161ak pou\017eije len vtedy'||-
', ke\010f \010dip VRAM dostane \0161peci\00e1lne in\0161trukcie, aby '||-
'to urobil. Pr\00edkaz na pou\017eitie posunovacieho registra je zabudova'||-
'n\00fd do grafick\00e9ho radi\010da.'-
));
INSERT INTO product_descriptions VALUES(1787-
,'SK'-
,UNISTR(-
'CPU D300'-
),UNISTR(-
'Du\00e1lne CPU s frekvenciou 300 MHz. Len pre nen\00e1ro\010dn\00e9 os'||-
'obn\00e9 \00falohy alebo s\00faborov\00e9 servery s menej ako 5 s'||-
'\00fabe\017en\00fdmi pou\017e\00edvate\013emi. Tento produkt bude '||-
'\010doskoro zastaran\00fd.'-
));
INSERT INTO product_descriptions VALUES(2439-
,'SK'-
,UNISTR(-
'CPU D400'-
),UNISTR(-
'Du\00e1lne CPU s frekvenciou 400 MHz. Dobr\00fd pomer cena/v\00fdkon; p'||-
're stredne ve\013ek\00e9 s\00faborov\00e9 servery siet\00ed LAN (do 1'||-
'00 s\00fabe\017en\00fdch pou\017e\00edvate\013eov).'-
));
INSERT INTO product_descriptions VALUES(1788-
,'SK'-
,UNISTR(-
'CPU D600'-
),UNISTR(-
'Du\00e1lne CPU s frekvenciou 600 MHz. Modern\00fd procesor s vysokou r'||-
'\00fdchlos\0165ou hod\00edn; pre vysoko za\0165a\017een\00e9 servery'||-
' siet\00ed WAN (do 200 s\00fabe\017en\00fdch pou\017e\00edvate\013e'||-
'ov).'-
));
INSERT INTO product_descriptions VALUES(2375-
,'SK'-
,UNISTR(-
'GP 1024x768'-
),UNISTR(-
'Grafick\00fd procesor, rozl\00ed\0161enie 1024 x 768 zobrazovac\00edch'||-
' bodov. Vynikaj\00faci pomer cena/v\00fdkon pre 2D a 3D aplik\00e1cie p'||-
'od SPNIX v3.3 a v4.0. Zdvojn\00e1sobte mo\017enosti zobrazovania prev'||-
'\00e1dzkovan\00edm dvoch monitorov z jedinej karty. Dva 17-palcov\00e9 '||-
'monitory maj\00fa v\00e4\010d\0161iu obrazovkov\00fa plochu ako jeden'||-
' 21-palcov\00fd monitor. Vynikaj\00faca vo\013eba pre pou\017e\00edva'||-
'te\013eov, ktor\00ed \010dasto vyu\017e\00edvaj\00fa multitasking al'||-
'ebo \010dasto pristupuj\00fa k d\00e1tam z r\00f4znych zdrojov.'-
));
INSERT INTO product_descriptions VALUES(2411-
,'SK'-
,UNISTR(-
'GP 1280x1024'-
),UNISTR(-
'Grafick\00fd procesor, rozl\00ed\0161enie 1280 x 1024 zobrazovac\00edc'||-
'h bodov. 3D v\00fdkon najvy\0161\0161ej triedy za cenu strednej triedy:'||-
' 15 mili\00f3nov Gouraudov\00fdch tie\0148ovan\00fdch trojuholn\00edk'||-
'ov za sekundu, optimalizovan\00e9 3D ovl\00e1da\010de pre aplik\00e1ci'||-
'e MCAD a DCC s pou\017e\00edvate\013esky prisp\00f4sobite\013en\00fd'||-
'mi nastaveniami. 64MB DDR SDRAM zjednoten\00fd r\00e1mcov\00fd buffer p'||-
'odporuj\00faci true color pri podporovan\00fdch \0161tandardn\00fdch r'||-
'ozl\00ed\0161eniach.'-
));
INSERT INTO product_descriptions VALUES(1769-
,'SK'-
,UNISTR(-
'GP 800x600'-
),UNISTR(-
'Grafick\00fd procesor, rozl\00ed\0161enie 800 x 600 zobrazovac\00edch '||-
'bodov. Pozoruhodn\00e1 hodnota pre pou\017e\00edvate\013eov vy\017ead'||-
'uj\00facich vynikaj\00face 2D schopnosti alebo v\0161eobecn\00fa 3D po'||-
'dporu pre n\00e1ro\010dnej\0161ie aplik\00e1cie. Poskytuje neuverite'||-
'\013en\00fd v\00fdkon vo vysoko komplexn\00fdch modeloch a umo\017e'||-
'\0148uje z\00e1kazn\00edkovi s\00fastredi\0165 sa na dizajn namiesto '||-
'procesu vykres\013eovania.'-
));
INSERT INTO product_descriptions VALUES(2049-
,'SK'-
,UNISTR(-
'MB - S300'-
),UNISTR(-
'Mati\010dn\00e1 doska typu PC, 300 Series.'-
));
INSERT INTO product_descriptions VALUES(2751-
,'SK'-
,UNISTR(-
'MB - S450'-
),UNISTR(-
'Mati\010dn\00e1 doska typu PC, 450 Series.'-
));
INSERT INTO product_descriptions VALUES(3112-
,'SK'-
,UNISTR(-
'MB - S500'-
),UNISTR(-
'Mati\010dn\00e1 doska typu PC, 500 Series.'-
));
INSERT INTO product_descriptions VALUES(2752-
,'SK'-
,UNISTR(-
'MB - S550'-
),UNISTR(-
'Mati\010dn\00e1 doska typu PC pre 550 Series.'-
));
INSERT INTO product_descriptions VALUES(2293-
,'SK'-
,UNISTR(-
'MB - S600'-
),UNISTR(-
'Mati\010dn\00e1 doska, 600 Series.'-
));
INSERT INTO product_descriptions VALUES(3114-
,'SK'-
,UNISTR(-
'MB - S900/650+'-
),UNISTR(-
'Mati\010dn\00e1 doska pre PC, 900 Series; \0161tandardn\00e1 mati'||-
'\010dn\00e1 doska pre v\0161etky modely 650 a vy\0161\0161ie.'-
));
INSERT INTO product_descriptions VALUES(3129-
,'SK'-
,UNISTR(-
'Zvukov\00e1 karta STD'-
),UNISTR(-
'Zvukov\00e1 karta - \0161tandardn\00e1 verzia s rozhran\00edm MIDI, li'||-
'nka dnu/von, n\00edzkoimpedan\010dn\00fd mikrof\00f3nov\00fd vstup.'-
));
INSERT INTO product_descriptions VALUES(3133-
,'SK'-
,UNISTR(-
'Videokarta /32'-
),UNISTR(-
'Videokarta s 32 MB pam\00e4\0165ou cache.'-
));
INSERT INTO product_descriptions VALUES(2308-
,'SK'-
,UNISTR(-
'Videokarta /E32'-
),UNISTR(-
'3-D ELSA videokarta s 32 MB pam\00e4\0165ou.'-
));
INSERT INTO product_descriptions VALUES(2496-
,'SK'-
,UNISTR(-
'WSP DA-130'-
),UNISTR(-
'Wide storage procesor DA-130 pre podjednotky pam\00e4\0165ov\00fdch pri'||-
'estorov.'-
));
INSERT INTO product_descriptions VALUES(2497-
,'SK'-
,UNISTR(-
'WSP DA-290'-
),UNISTR(-
'Wide storage procesor (model DA-290).'-
));
INSERT INTO product_descriptions VALUES(3106-
,'SK'-
,UNISTR(-
'KB 101/EN'-
),UNISTR(-
'\0160tandardn\00e1 PC/AT vylep\0161en\00e1 kl\00e1vesnica (101/102-kl'||-
'\00e1vesov\00e1). Jazyk: anglick\00fd (Slovak).'-
));
INSERT INTO product_descriptions VALUES(2289-
,'SK'-
,UNISTR(-
'KB 101/ES'-
),UNISTR(-
'\0160tandardn\00e1 PC/AT vylep\0161en\00e1 kl\00e1vesnica (101/102-kl'||-
'\00e1vesov\00e1). Jazyk: \0161panielsky.'-
));
INSERT INTO product_descriptions VALUES(3110-
,'SK'-
,UNISTR(-
'KB 101/FR'-
),UNISTR(-
'\0160tandardn\00e1 PC/AT vylep\0161en\00e1 kl\00e1vesnica (101/102-kl'||-
'\00e1vesov\00e1). Jazyk: franc\00fazsky.'-
));
INSERT INTO product_descriptions VALUES(3108-
,'SK'-
,UNISTR(-
'KB E/EN'-
),UNISTR(-
'Ergonomick\00e1 kl\00e1vesnica s dvoma oddelen\00fdmi kl\00e1vesov'||-
'\00fdmi oblas\0165ami a odpojite\013enou numerickou kl\00e1vesnicou. R'||-
'ozlo\017eenie kl\00e1ves: anglick\00e9 (Slovak).'-
));
INSERT INTO product_descriptions VALUES(2058-
,'SK'-
,UNISTR(-
'My\0161 + podlo\017eka'-
),UNISTR(-
'Kombin\00e1cia my\0161i a z\00e1p\00e4stnej podlo\017eky na pohodlnej'||-
'\0161ie p\00edsanie a pr\00e1cu s my\0161ou.'-
));
INSERT INTO product_descriptions VALUES(2761-
,'SK'-
,UNISTR(-
'My\0161 + podlo\017eka/logo'-
),UNISTR(-
'S\00faprava pozost\00e1vaj\00faca z my\0161i a z\00e1p\00e4stnej pod'||-
'lo\017eky s firemn\00fdm logom'-
));
INSERT INTO product_descriptions VALUES(3117-
,'SK'-
,UNISTR(-
'My\0161, bez\0161n\00farov\00e1, ergonomick\00e1'-
),UNISTR(-
'Ergonomick\00e1 bez\0161n\00farov\00e1 my\0161. S gu\013eov\00fdm o'||-
'vl\00e1da\010dom pre maxim\00e1lne pohodlie a \013eahkos\0165 pou'||-
'\017eitia.'-
));
INSERT INTO product_descriptions VALUES(2056-
,'SK'-
,UNISTR(-
'Podlo\017eka na my\0161 s logom'-
),UNISTR(-
'\0160tandardn\00e1 podlo\017eka na my\0161 s firemn\00fdm logom'-
));
INSERT INTO product_descriptions VALUES(2211-
,'SK'-
,UNISTR(-
'Z\00e1p\00e4stn\00e1 podlo\017eka'-
),UNISTR(-
'P\00e1s z plastickej peny na opieranie z\00e1p\00e4st\00ed po\010das '||-
'pou\017e\00edvania kl\00e1vesnice'-
));
INSERT INTO product_descriptions VALUES(2944-
,'SK'-
,UNISTR(-
'Z\00e1p\00e4stn\00e1 podlo\017eka s logom'-
),UNISTR(-
'Z\00e1p\00e4stn\00e1 podlo\017eka s firemn\00fdm logom'-
));
INSERT INTO product_descriptions VALUES(1742-
,'SK'-
,UNISTR(-
'CD-ROM 500/16x'-
),UNISTR(-
'CD mechanika, len na \010d\00edtanie, 16-r\00fdchlostn\00e1, maxim'||-
'\00e1lna kapacita 500 MB.'-
));
INSERT INTO product_descriptions VALUES(2402-
,'SK'-
,UNISTR(-
'CD-ROM 600/E/24x'-
),UNISTR(-
'600 MB extern\00e1 24-r\00fdchlostn\00e1 CD-ROM mechanika (len na '||-
'\010d\00edtanie).'-
));
INSERT INTO product_descriptions VALUES(2403-
,'SK'-
,UNISTR(-
'CD-ROM 600/I/24x'-
),UNISTR(-
'600 MB intern\00e1 CD-ROM mechanika len na \010d\00edtanie, r\00fdchlo'||-
's\0165 \010d\00edtania 24x'-
));
INSERT INTO product_descriptions VALUES(1761-
,'SK'-
,UNISTR(-
'CD-ROM 600/I/32x'-
),UNISTR(-
'600 MB intern\00e1 CD-ROM mechanika, 32-r\00fdchlostn\00e1 (len na '||-
'\010d\00edtanie).'-
));
INSERT INTO product_descriptions VALUES(2381-
,'SK'-
,UNISTR(-
'CD-ROM 8x'-
),UNISTR(-
'Zapisova\010d CD, len na \010d\00edtanie, 8-r\00fdchlostn\00fd'-
));
INSERT INTO product_descriptions VALUES(2424-
,'SK'-
,UNISTR(-
'CDW 12/24'-
),UNISTR(-
'Zapisova\010d CD, z\00e1pis 12x, \010d\00edtanie 24x. Upozornenie: '||-
'\010doskoro bude ve\013emi zastaran\00fd; t\00e1to r\00fdchlos\0165 '||-
'u\017e nie je dos\0165 vysok\00e1 a s\00fa k dispoz\00edcii aj lep'||-
'\0161ie alternat\00edvy za rozumn\00fa cenu.'-
));
INSERT INTO product_descriptions VALUES(1781-
,'SK'-
,UNISTR(-
'CDW 20/48/E'-
),UNISTR(-
'Zapisova\010d CD, \010d\00edtanie 48x, z\00e1pis 20x'-
));
INSERT INTO product_descriptions VALUES(2264-
,'SK'-
,UNISTR(-
'CDW 20/48/I'-
),UNISTR(-
'CD-ROM mechanika: \010d\00edtanie 20x, z\00e1pis 48x (intern\00e1)'-
));
INSERT INTO product_descriptions VALUES(2260-
,'SK'-
,UNISTR(-
'DFD 1.44/3.5'-
),UNISTR(-
'Du\00e1lna disketov\00e1 mechanika - 1,44 MB - 3,5 palcov\00e1'-
));
INSERT INTO product_descriptions VALUES(2266-
,'SK'-
,UNISTR(-
'DVD 12x'-
),UNISTR(-
'DVD-ROM mechanika: 12-r\00fdchlostn\00e1'-
));
INSERT INTO product_descriptions VALUES(3077-
,'SK'-
,UNISTR(-
'DVD 8x'-
),UNISTR(-
'DVD-ROM mechanika, 8-r\00fdchlostn\00e1. Pravdepodobne bude \010doskoro'||-
' zastaran\00e1...'-
));
INSERT INTO product_descriptions VALUES(2259-
,'SK'-
,UNISTR(-
'FD 1.44/3.5'-
),UNISTR(-
'Disketov\00e1 mechanika - 1,44 MB, kapacita s vysokou hustotou, 3,5 palco'||-
'v\00e1'-
));
INSERT INTO product_descriptions VALUES(2261-
,'SK'-
,UNISTR(-
'FD 1.44/3.5/E'-
),UNISTR(-
'Disketov\00e1 mechanika - 1,44 MB (vysok\00e1 hustota) - 3,5 palcov'||-
'\00e1 (extern\00e1)'-
));
INSERT INTO product_descriptions VALUES(3082-
,'SK'-
,UNISTR(-
'Modem - 56/90/E'-
),UNISTR(-
'Modem - 56 kb za sekundu, v zhode s v.90 PCI Global. Extern\00fd; nap'||-
'\00e1janie 110 V.'-
));
INSERT INTO product_descriptions VALUES(2270-
,'SK'-
,UNISTR(-
'Modem - 56/90/I'-
),UNISTR(-
'Modem - 56 kb za sekundu, v zhode s v.90 PCI Global. Intern\00fd, na '||-
'\0161tandardn\00e9 \0161asi (3,5 palcov\00e9).'-
));
INSERT INTO product_descriptions VALUES(2268-
,'SK'-
,UNISTR(-
'Modem - 56/H/E'-
),UNISTR(-
'\0160tandardn\00fd modem kompatibiln\00fd so syst\00e9mom Hayes - 56 k'||-
'b za sekundu, extern\00fd. Nap\00e1janie: 220 V.'-
));
INSERT INTO product_descriptions VALUES(3083-
,'SK'-
,UNISTR(-
'Modem - 56/H/I'-
),UNISTR(-
'\0160tandardn\00fd modem Hayes - 56kb za sekundu, intern\00fd, pre '||-
'\0161tandardn\00e9 3,5 palcov\00e9 \0161asi.'-
));
INSERT INTO product_descriptions VALUES(2374-
,'SK'-
,UNISTR(-
'Modem - C/100'-
),UNISTR(-
'Extern\00fd k\00e1blov\00fd modem v zhode s DOCSIS/EURODOCSIS 1.0/1.1'-
));
INSERT INTO product_descriptions VALUES(1740-
,'SK'-
,UNISTR(-
'TD 12GB/DAT'-
),UNISTR(-
'P\00e1skov\00e1 mechanika - kapacita 12 GB, form\00e1t DAT.'-
));
INSERT INTO product_descriptions VALUES(2409-
,'SK'-
,UNISTR(-
'TD 7GB/8'-
),UNISTR(-
'P\00e1skov\00e1 mechanika, kapacita 7 GB, kartrid\017e s 8 mm p\00e1sk'||-
'ou.'-
));
INSERT INTO product_descriptions VALUES(2262-
,'SK'-
,UNISTR(-
'ZIP 100'-
),UNISTR(-
'ZIP mechanika, kapacita 100 MB, extern\00e1, plus k\00e1bel na pripojeni'||-
'e na paraleln\00fd port'-
));
INSERT INTO product_descriptions VALUES(2522-
,'SK'-
,UNISTR(-
'Bat\00e9ria - EL'-
),UNISTR(-
'Bat\00e9ria s pred\013a\017eenou \017eivotnos\0165ou na laptopy'-
));
INSERT INTO product_descriptions VALUES(2278-
,'SK'-
,UNISTR(-
'Bat\00e9ria - NiHM'-
),UNISTR(-
'Dob\00edjate\013en\00e1 bat\00e9ria s pred\013a\017eenou \017eivotn'||-
'os\0165ou pre laptopy'-
));
INSERT INTO product_descriptions VALUES(2418-
,'SK'-
,UNISTR(-
'Bat\00e9riov\00e1 z\00e1loha (DA-130)'-
),UNISTR(-
'Nab\00edja\010dka jednej bat\00e9rie s LED indik\00e1tormi'-
));
INSERT INTO product_descriptions VALUES(2419-
,'SK'-
,UNISTR(-
'Bat\00e9riov\00e1 z\00e1loha (DA-290)'-
),UNISTR(-
'Nab\00edja\010dka dvoch bat\00e9ri\00ed s LED indik\00e1tormi'-
));
INSERT INTO product_descriptions VALUES(3097-
,'SK'-
,UNISTR(-
'K\00e1blov\00fd konektor - 32R'-
),UNISTR(-
'K\00e1blov\00fd konektor - 32-pinov\00e1 ma\0161\013ea'-
));
INSERT INTO product_descriptions VALUES(3099-
,'SK'-
,UNISTR(-
'K\00e1blov\00fd postroj'-
),UNISTR(-
'K\00e1blov\00fd postroj na organizovanie a zv\00e4zovanie po\010d'||-
'\00edta\010dovej kabel\00e1\017ee'-
));
INSERT INTO product_descriptions VALUES(2380-
,'SK'-
,UNISTR(-
'K\00e1bel PR/15/P'-
),UNISTR(-
'15-stopov\00fd paraleln\00fd k\00e1bel na tla\010diare\0148'-
));
INSERT INTO product_descriptions VALUES(2408-
,'SK'-
,UNISTR(-
'K\00e1bel PR/P/6'-
),UNISTR(-
'\0160tandardn\00fd 6-stopov\00fd k\00e1bel Centronics na tla\010diare'||-
'\0148, paraleln\00fd port'-
));
INSERT INTO product_descriptions VALUES(2457-
,'SK'-
,UNISTR(-
'K\00e1bel PR/S/6'-
),UNISTR(-
'\0160tandardn\00fd RS-232 s\00e9riov\00fd k\00e1bel na tla\010diare'||-
'\0148, 6-stopov\00fd'-
));
INSERT INTO product_descriptions VALUES(2373-
,'SK'-
,UNISTR(-
'K\00e1bel RS-232 10/AF'-
),UNISTR(-
'10 stopov\00fd k\00e1bel RS-232 s F/F a 9F/25F adapt\00e9rmi'-
));
INSERT INTO product_descriptions VALUES(1734-
,'SK'-
,UNISTR(-
'K\00e1bel RS-232 10/AM'-
),UNISTR(-
'10 stopov\00fd k\00e1bel RS-232 s M/M a 9M/25M adapt\00e9rmi'-
));
INSERT INTO product_descriptions VALUES(1737-
,'SK'-
,UNISTR(-
'K\00e1bel SCSI 10/FW/ADS'-
),UNISTR(-
'10-stopov\00fd SCSI2 F/W adapt\00e9r na k\00e1bel DSxx0'-
));
INSERT INTO product_descriptions VALUES(1745-
,'SK'-
,UNISTR(-
'K\00e1bel SCSI 20/WD->D'-
),UNISTR(-
'20-stopov\00fd SCSI2 Wide Disk Store na Disk Store Cable'-
));
INSERT INTO product_descriptions VALUES(2982-
,'SK'-
,UNISTR(-
'Mont\00e1\017e mechaniky - A'-
),UNISTR(-
'Mont\00e1\017ena s\00faprava mechaniky'-
));
INSERT INTO product_descriptions VALUES(3277-
,'SK'-
,UNISTR(-
'Mont\00e1\017e mechaniky - A/T'-
),UNISTR(-
'Mont\00e1\017ena s\00faprava mechaniky pre PC typu tower'-
));
INSERT INTO product_descriptions VALUES(2976-
,'SK'-
,UNISTR(-
'Mont\00e1\017e mechaniky - D'-
),UNISTR(-
'Mont\00e1\017ena s\00faprava mechaniky pre stoln\00e9 PC'-
));
INSERT INTO product_descriptions VALUES(3204-
,'SK'-
,UNISTR(-
'Envoy DS'-
),UNISTR(-
'Envoy dokovacia stanica'-
));
INSERT INTO product_descriptions VALUES(2638-
,'SK'-
,UNISTR(-
'Envoy DS/E'-
),UNISTR(-
'Enhanced Envoy Docking Station'-
));
INSERT INTO product_descriptions VALUES(3020-
,'SK'-
,UNISTR(-
'Envoy IC'-
),UNISTR(-
'Envoy Internet Computer, Plug&Play'-
));
INSERT INTO product_descriptions VALUES(1948-
,'SK'-
,UNISTR(-
'Envoy IC/58'-
),UNISTR(-
'Internetov\00fd po\010d\00edta\010d so zabudovan\00fdm 58 kb/s modemo'||-
'm'-
));
INSERT INTO product_descriptions VALUES(3003-
,'SK'-
,UNISTR(-
'Laptop 128/12/56/v90/110'-
),UNISTR(-
'Envoy Laptop, pam\00e4\0165 128 MB, pevn\00fd disk 12 GB, modem v90, na'||-
'p\00e1janie 110 V.'-
));
INSERT INTO product_descriptions VALUES(2999-
,'SK'-
,UNISTR(-
'Laptop 16/8/110'-
),UNISTR(-
'Envoy Laptop, pam\00e4\0165 16 MB, pevn\00fd disk 8 GB, nap\00e1janie '||-
'110 V (len Slovak).'-
));
INSERT INTO product_descriptions VALUES(3000-
,'SK'-
,UNISTR(-
'Laptop 32/10/56'-
),UNISTR(-
'Envoy Laptop, pam\00e4\0165 32 MB, pevn\00fd disk 10 GB, modem 56 kb/s,'||-
' univerz\00e1lne nap\00e1janie (prep\00ednate\013en\00e9).'-
));
INSERT INTO product_descriptions VALUES(3001-
,'SK'-
,UNISTR(-
'Laptop 48/10/56/110'-
),UNISTR(-
'Envoy Laptop, pam\00e4\0165 48 MB, pevn\00fd disk 10 GB, modem 56 kb/s,'||-
' nap\00e1janie 110 V.'-
));
INSERT INTO product_descriptions VALUES(3004-
,'SK'-
,UNISTR(-
'Laptop 64/10/56/220'-
),UNISTR(-
'Envoy Laptop, pam\00e4\0165 64 MB, pevn\00fd disk 10 GB, modem 56 kb/s,'||-
' nap\00e1janie 220 V.'-
));
INSERT INTO product_descriptions VALUES(3391-
,'SK'-
,UNISTR(-
'PS 110/220'-
),UNISTR(-
'Zdroj - prep\00ednate\013en\00fd, 110 V/220 V'-
));
INSERT INTO product_descriptions VALUES(3124-
,'SK'-
,UNISTR(-
'PS 110V /T'-
),UNISTR(-
'Zdroj pre sojanov\00e9 PC, 110 V'-
));
INSERT INTO product_descriptions VALUES(1738-
,'SK'-
,UNISTR(-
'PS 110V /US'-
),UNISTR(-
'Zdroj 110 V - kompatibilita pre Slovak'-
));
INSERT INTO product_descriptions VALUES(2377-
,'SK'-
,UNISTR(-
'PS 110V HS/US'-
),UNISTR(-
'Zahor\00faca vymie\0148ate\013en\00fd zdroj 110 V - kompatibilita pre '||-
'Slovak'-
));
INSERT INTO product_descriptions VALUES(2299-
,'SK'-
,UNISTR(-
'PS 12V /P'-
),UNISTR(-
'Zdroj - 12 V, prenosn\00fd'-
));
INSERT INTO product_descriptions VALUES(3123-
,'SK'-
,UNISTR(-
'PS 220V /D'-
),UNISTR(-
'\0160tandardn\00fd zdroj, 220 V, pre stoln\00e9 po\010d\00edta\010de'||-
'.'-
));
INSERT INTO product_descriptions VALUES(1748-
,'SK'-
,UNISTR(-
'PS 220V /EUR'-
),UNISTR(-
'220 V zdroj - Eur\00f3pa'-
));
INSERT INTO product_descriptions VALUES(2387-
,'SK'-
,UNISTR(-
'PS 220V /FR'-
),UNISTR(-
'220 V zdroj - Franc\00fazsko'-
));
INSERT INTO product_descriptions VALUES(2370-
,'SK'-
,UNISTR(-
'PS 220V /HS/FR'-
),UNISTR(-
'Zahor\00faca vymie\0148ate\013en\00fd 220 V zdroj pre Franc\00faszko.'-
));
INSERT INTO product_descriptions VALUES(2311-
,'SK'-
,UNISTR(-
'PS 220V /L'-
),UNISTR(-
'Zdroj pre laptopy, 220 V'-
));
INSERT INTO product_descriptions VALUES(1733-
,'SK'-
,UNISTR(-
'PS 220V /UK'-
),UNISTR(-
'220 V zdroj - Spojen\00e9 kr\00e1\013eovstvo'-
));
INSERT INTO product_descriptions VALUES(2878-
,'SK'-
,UNISTR(-
'Router - ASR/2W'-
),UNISTR(-
'\0160peci\00e1lny ALS router - polo\017eka mus\00ed by\0165 od schv'||-
'\00e1len\00e9ho dod\00e1vate\013ea s dvojcestn\00fdm pripojen\00edm'-
));
INSERT INTO product_descriptions VALUES(2879-
,'SK'-
,UNISTR(-
'Router - ASR/3W'-
),UNISTR(-
'\0160peci\00e1lny ALS router - polo\017eka vy\017eadovan\00e1 schv'||-
'\00e1len\00fdmi dod\00e1vate\013emi s trojcestn\00fdm pripojen\00edm'-
));
INSERT INTO product_descriptions VALUES(2152-
,'SK'-
,UNISTR(-
'Router - DTMF4'-
),UNISTR(-
'DTMF 4 portov\00fd router'-
));
INSERT INTO product_descriptions VALUES(3301-
,'SK'-
,UNISTR(-
'Skrutky <B.28.P>'-
),UNISTR(-
'Skrutky: mosadzn\00e9, ve\013ekos\0165 28 mm, hlavi\010dka Phillips. P'||-
'lastov\00e1 \0161katu\013eka, obsah 500.'-
));
INSERT INTO product_descriptions VALUES(3143-
,'SK'-
,UNISTR(-
'Skrutky <B.28.S>'-
),UNISTR(-
'Skrutky: mosadzn\00e9, ve\013ekos\0165 28 mm, rovn\00e9. Plastov\00e1'||-
' \0161katu\013eka, obsah 500.'-
));
INSERT INTO product_descriptions VALUES(2323-
,'SK'-
,UNISTR(-
'Skrutky <B.32.P>'-
),UNISTR(-
'Skrutky: mosadzn\00e9, ve\013ekos\0165 32mm, hlavi\010dka Phillips. Pl'||-
'astov\00e1 \0161katu\013eka, obsah 400.'-
));
INSERT INTO product_descriptions VALUES(3134-
,'SK'-
,UNISTR(-
'Skrutky <B.32.S>'-
),UNISTR(-
'Skrutky: mosadzn\00e9, ve\013ekos\0165 32mm, rovn\00e9. Plastov\00e1 '||-
'\0161katu\013eka, obsah 400.'-
));
INSERT INTO product_descriptions VALUES(3139-
,'SK'-
,UNISTR(-
'Skrutky <S.16.S>'-
),UNISTR(-
'Skrutky: oce\013eov\00e9, ve\013ekos\0165 16 mm, rovn\00e9. Kart'||-
'\00f3nov\00e1 \0161katu\013eka, obsah 750.'-
));
INSERT INTO product_descriptions VALUES(3300-
,'SK'-
,UNISTR(-
'Skrutky <S.32.P>'-
),UNISTR(-
'Skrutky: oce\013eov\00e9, ve\013ekos\0165 32 mm, hlavi\010dka Phillip'||-
's. Plastov\00e1 \0161katu\013eka, obsah 400.'-
));
INSERT INTO product_descriptions VALUES(2316-
,'SK'-
,UNISTR(-
'Skrutky <S.32.S>'-
),UNISTR(-
'Skrutky: oce\013eov\00e9, ve\013ekos\0165 32 mm, rovn\00e9. Plastov'||-
'\00e1 \0161katu\013eka, obsah 500.'-
));
INSERT INTO product_descriptions VALUES(3140-
,'SK'-
,UNISTR(-
'Skrutky <Z.16.S>'-
),UNISTR(-
'Skrutky: zinkov\00e9, ve\013ekos\0165 16mm, rovn\00e9. Kart\00f3nov'||-
'\00e1 \0161katu\013eka, obsah 750.'-
));
INSERT INTO product_descriptions VALUES(2319-
,'SK'-
,UNISTR(-
'Skrutky <Z.24.S>'-
),UNISTR(-
'Skrutky: zinkov\00e9, ve\013ekos\0165 24 mm, rovn\00e9. Kart\00f3nov'||-
'\00e1 \0161katu\013eka, obsah 500.'-
));
INSERT INTO product_descriptions VALUES(2322-
,'SK'-
,UNISTR(-
'Skrutky <Z.28.P>'-
),UNISTR(-
'Skrutky: zinkov\00e9, ve\013ekos\0165 28 mm, hlavi\010dka Phillips. Ka'||-
'rt\00f3nov\00e1 \0161katu\013eka, obsah 850.'-
));
INSERT INTO product_descriptions VALUES(3178-
,'SK'-
,UNISTR(-
'Tabu\013ekov\00fd procesor - SSP/V 2.0'-
),UNISTR(-
'Tabu\013ekov\00fd procesor SmartSpread, Professional Edition Version 2.0'||-
', pre Vision Release 11.1 a 11.2. Bal\00edk obsahuje CD-ROM obsahuj\00fa'||-
'ci softv\00e9r a on-line dokument\00e1ciu plus tla\010den\00fd manu'||-
'\00e1l, kurz a registr\00e1ciu licencie.'-
));
INSERT INTO product_descriptions VALUES(3179-
,'SK'-
,UNISTR(-
'Tabu\013ekov\00fd procesor - SSS/S 2.1'-
),UNISTR(-
'Tabu\013ekov\00fd procesor SmartSpread, Standard Edition Version 2.1, pr'||-
'e SPNIX Release 4.0. Bal\00edk obsahuje CD-ROM obsahuj\00faci softv'||-
'\00e9r a on-line dokument\00e1ciu plus tla\010den\00fd manu\00e1l a r'||-
'egistr\00e1ciu licencie.'-
));
INSERT INTO product_descriptions VALUES(3182-
,'SK'-
,UNISTR(-
'Textov\00fd procesor - SWP/V 4.5'-
),UNISTR(-
'Textov\00fd procesor SmartWord, Professional Edition Version 4.5, pre Vis'||-
'ion Release 11.x. Bal\00edk obsahuje CD-ROM obsahuj\00faci softv\00e9r,'||-
' tla\010den\00fd manu\00e1l a registr\00e1ciu licencie.'-
));
INSERT INTO product_descriptions VALUES(3183-
,'SK'-
,UNISTR(-
'Textov\00fd procesor - SWS/V 4.5'-
),UNISTR(-
'Textov\00fd procesor SmartWord, Standard Edition Version 4.5, pre Vision '||-
'Release 11.x. Bal\00edk obsahuje CD-ROM a registr\00e1ciu licencie.'-
));
INSERT INTO product_descriptions VALUES(3197-
,'SK'-
,UNISTR(-
'Tabu\013ekov\00fd procesor - SSS/V 2.1'-
),UNISTR(-
'Tabu\013ekov\00fd procesor SmartSpread, Standard Edition Version 2,1, pr'||-
'e Vision Release 11.1 a 11.2. Bal\00edk obsahuje CD-ROM obsahuj\00faci s'||-
'oftv\00e9r a on-line dokument\00e1ciu plus tla\010den\00fd manu\00e1l'||-
', kurz a registr\00e1ciu licencie.'-
));
INSERT INTO product_descriptions VALUES(3255-
,'SK'-
,UNISTR(-
'Tabu\013ekov\00fd procesor - SSS/CD 2.2B'-
),UNISTR(-
'Tabu\013ekov\00fd procesor SmartSpread, Standard Edition, Beta Version 2'||-
'.2, pre SPNIX Release 4.1. Len CD-ROM.'-
));
INSERT INTO product_descriptions VALUES(3256-
,'SK'-
,UNISTR(-
'Tabu\013ekov\00fd procesor - SSS/V 2.0'-
),UNISTR(-
'Tabu\013ekov\00fd procesor SmartSpread, Standard Edition Version 2.0, pr'||-
'e Vision Release 11.0. Bal\00edk obsahuje CD-ROM obsahuj\00faci softv'||-
'\00e9r a on-line dokument\00e1ciu plus tla\010den\00fd manu\00e1l, ku'||-
'rz a registr\00e1ciu licencie.'-
));
INSERT INTO product_descriptions VALUES(3260-
,'SK'-
,UNISTR(-
'Textov\00fd procesor - SWP/S 4.4'-
),UNISTR(-
'Tabu\013ekov\00fd procesor SmartSpread, Standard Edition Version 2.2, pr'||-
'e SPNIX Release 4.x. Bal\00edk obsahuje CD-ROM obsahuj\00faci softv'||-
'\00e9r plus tla\010den\00fd manu\00e1l a registr\00e1ciu licencie.'-
));
INSERT INTO product_descriptions VALUES(3262-
,'SK'-
,UNISTR(-
'Tabu\013ekov\00fd procesor - SSS/S 2.2'-
),UNISTR(-
'Tabu\013ekov\00fd procesor SmartSpread, Standard Edition Version 2.2, pr'||-
'e SPNIX Release 4.1. Bal\00edk obsahuje CD-ROM obsahuj\00faci softv'||-
'\00e9r a on-line dokument\00e1ciu plus tla\010den\00fd manu\00e1l a r'||-
'egistr\00e1ciu licencie.'-
));
INSERT INTO product_descriptions VALUES(3361-
,'SK'-
,UNISTR(-
'Tabu\013ekov\00fd procesor - SSP/S 1.5'-
),UNISTR(-
'Tabu\013ekov\00fd procesor SmartSpread, Standard Edition Version 2.2, pr'||-
'e SPNIX Release 4.1. Bal\00edk obsahuje CD-ROM obsahuj\00faci softv'||-
'\00e9r a on-line dokument\00e1ciu plus tla\010den\00fd manu\00e1l a r'||-
'egistr\00e1ciu licencie.'-
));
INSERT INTO product_descriptions VALUES(1799-
,'SK'-
,UNISTR(-
'SPNIX3.3 - SL'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - Base Server License. Obsahuje'||-
' 10 v\0161eobecn\00fdch licenci\00ed pre syst\00e9mov\00fa administr'||-
'\00e1ciu, v\00fdvoj\00e1rov alebo pou\017e\00edvate\013eov. \017dia'||-
'dne licencovanie sie\0165ov\00fdch pou\017e\00edvate\013eov.'-
));
INSERT INTO product_descriptions VALUES(1801-
,'SK'-
,UNISTR(-
'SPNIX3.3 - AL'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - dodato\010dn\00e1 licencia '||-
'syst\00e9mov\00e9ho administr\00e1tora vr\00e1tane sie\0165ov\00e9ho'||-
' pr\00edstupu.'-
));
INSERT INTO product_descriptions VALUES(1803-
,'SK'-
,UNISTR(-
'SPNIX3.3 - DL'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - dodato\010dn\00e1 licencia '||-
'v\00fdvoj\00e1ra.'-
));
INSERT INTO product_descriptions VALUES(1804-
,'SK'-
,UNISTR(-
'SPNIX3.3 - UL/N'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - dodato\010dn\00e1 pou\017e'||-
'\00edvate\013esk\00e1 licencia so sie\0165ov\00fdm pr\00edstupom.'-
));
INSERT INTO product_descriptions VALUES(1805-
,'SK'-
,UNISTR(-
'SPNIX3.3 - UL/A'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - dodato\010dn\00e1 pou\017e'||-
'\00edvate\013esk\00e1 licencia triedy A.'-
));
INSERT INTO product_descriptions VALUES(1806-
,'SK'-
,UNISTR(-
'SPNIX3.3 - UL/C'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - dodato\010dn\00e1 pou\017e'||-
'\00edvate\013esk\00e1 licencia triedy C.'-
));
INSERT INTO product_descriptions VALUES(1808-
,'SK'-
,UNISTR(-
'SPNIX3.3 - UL/D'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - dodato\010dn\00e1 pou\017e'||-
'\00edvate\013esk\00e1 licencia triedy D.'-
));
INSERT INTO product_descriptions VALUES(1820-
,'SK'-
,UNISTR(-
'SPNIX3.3 - NL'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - dodato\010dn\00e1 licencia '||-
'na sie\0165ov\00fd pr\00edstup.'-
));
INSERT INTO product_descriptions VALUES(1822-
,'SK'-
,UNISTR(-
'SPNIX4.0 - SL'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V4.3 - Base Server License. Obsahuje'||-
' 10 v\0161eobecn\00fdch licenci\00ed pre syst\00e9mov\00fa administr'||-
'\00e1ciu, v\00fdvoj\00e1rov alebo pou\017e\00edvate\013eov. \017dia'||-
'dne licencovanie sie\0165ov\00fdch pou\017e\00edvate\013eov.'-
));
INSERT INTO product_descriptions VALUES(2422-
,'SK'-
,UNISTR(-
'SPNIX4.0 - SAL'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V4.0 - dodato\010dn\00e1 licencia '||-
'syst\00e9mov\00e9ho administr\00e1tora vr\00e1tane sie\0165ov\00e9ho'||-
' pr\00edstupu.'-
));
INSERT INTO product_descriptions VALUES(2452-
,'SK'-
,UNISTR(-
'SPNIX4.0 - DL'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V4.0 - dodato\010dn\00e1 licencia '||-
'v\00fdvoj\00e1ra.'-
));
INSERT INTO product_descriptions VALUES(2462-
,'SK'-
,UNISTR(-
'SPNIX4.0 - UL/N'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V4.0 - dodato\010dn\00e1 pou\017e'||-
'\00edvate\013esk\00e1 licencia so sie\0165ov\00fdm pr\00edstupom.'-
));
INSERT INTO product_descriptions VALUES(2464-
,'SK'-
,UNISTR(-
'SPNIX4.0 - UL/A'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V4.0 - dodato\010dn\00e1 pou\017e'||-
'\00edvate\013esk\00e1 licencia triedy A.'-
));
INSERT INTO product_descriptions VALUES(2467-
,'SK'-
,UNISTR(-
'SPNIX4.0 - UL/D'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V4.0 - dodato\010dn\00e1 pou\017e'||-
'\00edvate\013esk\00e1 licencia triedy D.'-
));
INSERT INTO product_descriptions VALUES(2468-
,'SK'-
,UNISTR(-
'SPNIX4.0 - UL/C'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V4.0 - dodato\010dn\00e1 pou\017e'||-
'\00edvate\013esk\00e1 licencia triedy C.'-
));
INSERT INTO product_descriptions VALUES(2470-
,'SK'-
,UNISTR(-
'SPNIX4.0 - NL'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V4.0 - dodato\010dn\00e1 licencia '||-
'na sie\0165ov\00fd pr\00edstup.'-
));
INSERT INTO product_descriptions VALUES(2471-
,'SK'-
,UNISTR(-
'SPNIX3.3 SU'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - Base Server License Upgrade n'||-
'a V4.0.'-
));
INSERT INTO product_descriptions VALUES(2492-
,'SK'-
,UNISTR(-
'SPNIX3.3 AU'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - zv\00fd\0161enie verzie na '||-
'4.0, pou\017e\00edvate\013e triedy A.'-
));
INSERT INTO product_descriptions VALUES(2493-
,'SK'-
,UNISTR(-
'SPNIX3.3 C/DU'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - zv\00fd\0161enie verzie na '||-
'4.0, pou\017e\00edvate\013e triedy C alebo D.'-
));
INSERT INTO product_descriptions VALUES(2494-
,'SK'-
,UNISTR(-
'SPNIX3.3 NU'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - zv\00fd\0161enie verzie na '||-
'4.0; licencia na sie\0165ov\00fd pr\00edstup.'-
));
INSERT INTO product_descriptions VALUES(2995-
,'SK'-
,UNISTR(-
'SPNIX3.3 SAU'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - zv\00fd\0161enie verzie na '||-
'4.0; licencia syst\00e9mov\00e9ho administr\00e1tora.'-
));
INSERT INTO product_descriptions VALUES(3290-
,'SK'-
,UNISTR(-
'SPNIX3.3 DU'-
),UNISTR(-
'Opera\010dn\00fd syst\00e9m: SPNIX V3.3 - zv\00fd\0161enie verzie na '||-
'4.0; licencia v\00fdvoj\00e1ra.'-
));
INSERT INTO product_descriptions VALUES(1778-
,'SK'-
,UNISTR(-
'C pre SPNIX3.3 - 1 Seat'-
),UNISTR(-
'Softv\00e9r na programovanie v jazyku C pre SPNIX V3.3 - jeden pou\017e'||-
'\00edvate\013e'-
));
INSERT INTO product_descriptions VALUES(1779-
,'SK'-
,UNISTR(-
'C pre SPNIX3.3 - Doc'-
),UNISTR(-
'Dokument\00e1cia programovania v jazyku C, SPNIX V3.3'-
));
INSERT INTO product_descriptions VALUES(1780-
,'SK'-
,UNISTR(-
'C pre SPNIX3.3 - Sys'-
),UNISTR(-
'Softv\00e9r na programovanie v jazyku C pre SPNIX V3.3 - syst\00e9mov'||-
'\00fd kompil\00e1tor, kni\017enice, linker'-
));
INSERT INTO product_descriptions VALUES(2371-
,'SK'-
,UNISTR(-
'C pre SPNIX4.0 - Doc'-
),UNISTR(-
'Dokument\00e1cia programovania v jazyku C, SPNIX V4.0'-
));
INSERT INTO product_descriptions VALUES(2423-
,'SK'-
,UNISTR(-
'C pre SPNIX4.0 - 1 Seat'-
),UNISTR(-
'Softv\00e9r na programovanie v jazyku C pre SPNIX V4.0 - jeden pou\017e'||-
'\00edvate\013e'-
));
INSERT INTO product_descriptions VALUES(3501-
,'SK'-
,UNISTR(-
'C pre SPNIX4.0 - Sys'-
),UNISTR(-
'Softv\00e9r na programovanie v jazyku C pre SPNIX V4.0 - syst\00e9mov'||-
'\00fd kompil\00e1tor, kni\017enice, linker'-
));
INSERT INTO product_descriptions VALUES(3502-
,'SK'-
,UNISTR(-
'C pre SPNIX3.3 - Sys/U'-
),UNISTR(-
'Softv\00e9r na programovanie v jazyku C pre SPNIX V3.3, zv\00fd\0161eni'||-
'e verzie na 4.0; syst\00e9mov\00fd kompil\00e1tor, kni\017enice, linke'||-
'r'-
));
INSERT INTO product_descriptions VALUES(3503-
,'SK'-
,UNISTR(-
'C pre SPNIX3.3 - Seat/U'-
),UNISTR(-
'Softv\00e9r na programovanie v jazyku C pre SPNIX V3.3, zv\00fd\0161eni'||-
'e verzie na 4.0 - jeden pou\017e\00edvate\013e'-
));
INSERT INTO product_descriptions VALUES(1774-
,'SK'-
,UNISTR(-
'Base ISO CP - BL'-
),UNISTR(-
'Base ISO komunika\010dn\00fd bal\00edk - z\00e1kladn\00e1 licencia'-
));
INSERT INTO product_descriptions VALUES(1775-
,'SK'-
,UNISTR(-
'Client ISO CP - S'-
),UNISTR(-
'Pr\00eddavn\00e1 licencia na ISO komunika\010dn\00fd bal\00edk pre '||-
'\010fal\0161ieho klienta SPNIX V3.3.'-
));
INSERT INTO product_descriptions VALUES(1794-
,'SK'-
,UNISTR(-
'OSI 8-16/IL'-
),UNISTR(-
'OSI Layer 8 to 16 - inkrement\00e1lna licencia'-
));
INSERT INTO product_descriptions VALUES(1825-
,'SK'-
,UNISTR(-
'X25 - 1 Line License'-
),UNISTR(-
'Syst\00e9m riadenia pr\00edstupu do siete X25, jeden pou\017e\00edvate'||-
'\013e'-
));
INSERT INTO product_descriptions VALUES(2004-
,'SK'-
,UNISTR(-
'IC Browser - S'-
),UNISTR(-
'IC web preh\013ead\00e1va\010d pre SPNIX. Preh\013ead\00e1va\010d s '||-
'funkciou sie\0165ovej po\0161ty.'-
));
INSERT INTO product_descriptions VALUES(2005-
,'SK'-
,UNISTR(-
'IC Browser Doc - S'-
),UNISTR(-
'S\00faprava dokument\00e1cie pre IC web preh\013ead\00e1va\010d pre S'||-
'PNIX. Obsahuje in\0161tala\010dn\00fa pr\00edru\010dku, sprievodcu ad'||-
'ministr\00e1tora po\0161tov\00e9ho servera a stru\010dn\00fa pr\00ed'||-
'ru\010dku pre pou\017e\00edvate\013ea.'-
));
INSERT INTO product_descriptions VALUES(2416-
,'SK'-
,UNISTR(-
'Client ISO CP - S'-
),UNISTR(-
'Pr\00eddavn\00e1 licencia na ISO komunika\010dn\00fd bal\00edk pre '||-
'\010fal\0161ieho klienta SPNIX V4.0.'-
));
INSERT INTO product_descriptions VALUES(2417-
,'SK'-
,UNISTR(-
'Client ISO CP - V'-
),UNISTR(-
'Pr\00eddavn\00e1 licencia na ISO komunika\010dn\00fd bal\00edk pre '||-
'\010fal\0161ieho klienta Vision.'-
));
INSERT INTO product_descriptions VALUES(2449-
,'SK'-
,UNISTR(-
'OSI 1-4/IL'-
),UNISTR(-
'OSI Layer 1 to 4 - inkrement\00e1lna licencia'-
));
INSERT INTO product_descriptions VALUES(3101-
,'SK'-
,UNISTR(-
'IC Browser - V'-
),UNISTR(-
'IC web preh\013ead\00e1va\010d pre Vision s manu\00e1lom. Preh\013ead'||-
'\00e1va\010d s funkciou sie\0165ovej po\0161ty.'-
));
INSERT INTO product_descriptions VALUES(3170-
,'SK'-
,UNISTR(-
'Smart Suite - V/SP'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) pre Vision. '||-
'Softv\00e9r a pou\017e\00edvate\013esk\00e9 manu\00e1ly v \0161pani'||-
'elskom jazyku.'-
));
INSERT INTO product_descriptions VALUES(3171-
,'SK'-
,UNISTR(-
'Smart Suite - S3.3/EN'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) pre SPNIX Ve'||-
'rsion 3.3. Softv\00e9r v anglickom jazyku a pou\017e\00edvate\013esk'||-
'\00e9 manu\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3172-
,'SK'-
,UNISTR(-
'Graphics - DIK+'-
),UNISTR(-
'Software Kit Graphics: Draw-It Kwik-Plus. Obsahuje rozsiahle s\00fabory s'||-
' obr\00e1zkami a progres\00edvne n\00e1stroje na kreslenie na 3-D objek'||-
'tov\00fa manipul\00e1ciu, variabiln\00e9 tie\0148ovanie a roz\0161'||-
'\00edren\00e9 p\00edsma.'-
));
INSERT INTO product_descriptions VALUES(3173-
,'SK'-
,UNISTR(-
'Graphics - SA'-
),UNISTR(-
'Software Kit Graphics: SmartArt. Profesion\00e1lny grafick\00fd bal'||-
'\00edk pre SPNIX s mnoh\00fdmi \0161t\00fdlmi \010diar, text\00faram'||-
'i, zabudovan\00fdmi tvarmi a be\017en\00fdmi symbolmi.'-
));
INSERT INTO product_descriptions VALUES(3175-
,'SK'-
,UNISTR(-
'Project Management - S4.0'-
),UNISTR(-
'Softv\00e9r projektov\00e9ho mana\017ementu pre SPNIX V4.0. Softv\00e9'||-
'r obsahuje pr\00edkazov\00fd riadok a grafick\00e9 rozhranie s textov'||-
'\00fdmi, tabu\013ekov\00fdmi a prisp\00f4sobite\013en\00fdmi form'||-
'\00e1tmi zost\00e1v.'-
));
INSERT INTO product_descriptions VALUES(3176-
,'SK'-
,UNISTR(-
'Smart Suite - V/EN'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) pre Vision. '||-
'Softv\00e9r v anglickom jazyku a pou\017e\00edvate\013esk\00e9 manu'||-
'\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3177-
,'SK'-
,UNISTR(-
'Smart Suite - V/FR'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) pre Vision. '||-
'Softv\00e9r vo franc\00fazskom jazyku a pou\017e\00edvate\013esk'||-
'\00e9 manu\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3245-
,'SK'-
,UNISTR(-
'Smart Suite - S4.0/FR'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) pre SPNIX V4'||-
'.0. Softv\00e9r vo franc\00fazskom jazyku a pou\017e\00edvate\013esk'||-
'\00e9 manu\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3246-
,'SK'-
,UNISTR(-
'Smart Suite - S4.0/SP'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) pre SPNIX V4'||-
'.0. Softv\00e9r v \0161panielskom jazyku a pou\017e\00edvate\013esk'||-
'\00e9 manu\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3247-
,'SK'-
,UNISTR(-
'Smart Suite - V/DE'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) pre Vision. '||-
'Softv\00e9r v nemeckom jazyku a pou\017e\00edvate\013esk\00e9 manu'||-
'\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3248-
,'SK'-
,UNISTR(-
'Smart Suite - S4.0/DE'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) pre SPNIX V4'||-
'.0. Softv\00e9r v nemeckom jazyku a pou\017e\00edvate\013esk\00e9 man'||-
'u\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3250-
,'SK'-
,UNISTR(-
'Graphics - DIK'-
),UNISTR(-
'Software Kit Graphics: Draw-It Kwik. Jednoduch\00fd grafick\00fd bal'||-
'\00edk pre syst\00e9my Vision s mo\017enos\0165ami uklada\0165 s'||-
'\00fabory vo form\00e1toch GIF, JPG a BMP.'-
));
INSERT INTO product_descriptions VALUES(3251-
,'SK'-
,UNISTR(-
'Project Management - V'-
),UNISTR(-
'Softv\00e9r projektov\00e9ho mana\017ementu pre Vision. Softv\00e9r ob'||-
'sahuje pr\00edkazov\00fd riadok a grafick\00e9 rozhranie s textov\00fd'||-
'mi, tabu\013ekov\00fdmi a prisp\00f4sobite\013en\00fdmi form\00e1tmi'||-
' zost\00e1v.'-
));
INSERT INTO product_descriptions VALUES(3252-
,'SK'-
,UNISTR(-
'Project Management - S3.3'-
),UNISTR(-
'Softv\00e9r projektov\00e9ho mana\017ementu pre SPNIX V3.3. Softv\00e9'||-
'r obsahuje pr\00edkazov\00fd riadok a grafick\00e9 rozhranie s textov'||-
'\00fdmi, tabu\013ekov\00fdmi a prisp\00f4sobite\013en\00fdmi form'||-
'\00e1tmi zost\00e1v.'-
));
INSERT INTO product_descriptions VALUES(3253-
,'SK'-
,UNISTR(-
'Smart Suite - S4.0/EN'-
),UNISTR(-
'Office Suite (SmartWrite, SmartArt, SmartSpread, SmartBrowse) pre SPNIX V4'||-
'.0. Softv\00e9r v anglickom jazyku a pou\017e\00edvate\013esk\00e9 ma'||-
'nu\00e1ly.'-
));
INSERT INTO product_descriptions VALUES(3257-
,'SK'-
,UNISTR(-
'Web Browser - SB/S 2.1'-
),UNISTR(-
'Software Kit Web Browser: SmartBrowse V2.1 pre SPNIX V3.3. Obsahuje kontex'||-
'tovo z\00e1visl\00e9 pomocn\00e9 s\00fabory a online dokument\00e1ciu'||-
'.'-
));
INSERT INTO product_descriptions VALUES(3258-
,'SK'-
,UNISTR(-
'Web Browser - SB/V 1.0'-
),UNISTR(-
'Software Kit Web Browser: SmartBrowse V2.1 pre Vision. Obsahuje kontextovo'||-
' z\00e1visl\00e9 pomocn\00e9 s\00fabory a online dokument\00e1ciu.'-
));
INSERT INTO product_descriptions VALUES(3362-
,'SK'-
,UNISTR(-
'Web Browser - SB/S 4.0'-
),UNISTR(-
'Software Kit Web Browser: SmartBrowse V4.0 pre SPNIX V4.0. Obsahuje kontex'||-
'tovo z\00e1visl\00e9 pomocn\00e9 s\00fabory a online dokument\00e1ciu'||-
'.'-
));
INSERT INTO product_descriptions VALUES(2231-
,'SK'-
,UNISTR(-
'St\00f4l - S/V'-
),UNISTR(-
'St\00f4l \0161tandardnej ve\013ekosti; odpisovate\013en\00fd, zdanite'||-
'\013en\00e1 polo\017eka. Povrchov\00e1 \00faprava je z dyhy, ktor'||-
'\00e1 je na sklade v \010dase objednania a m\00f4\017ee by\0165 dubov'||-
'\00e1, jase\0148ov\00e1, \010dere\0161\0148ov\00e1 a mahag\00f3nov'||-
'\00e1.'-
));
INSERT INTO product_descriptions VALUES(2335-
,'SK'-
,UNISTR(-
'Mobiln\00fd telef\00f3n'-
),UNISTR(-
'Dvojp\00e1smov\00fd mobiln\00fd telef\00f3n s n\00edzkou spotrebou ba'||-
't\00e9rie. \013dahk\00fd, skladate\013en\00fd, so z\00e1suvkou na je'||-
'dnoduch\00e9 sl\00fachadlo a priestorom na rezervn\00e9 bat\00e9rie.'-
));
INSERT INTO product_descriptions VALUES(2350-
,'SK'-
,UNISTR(-
'St\00f4l - W/48'-
),UNISTR(-
'St\00f4l - 48-palcov\00fd, biely lamin\00e1t, bez prednej dosky; odpiso'||-
'vate\013en\00fd, zdanite\013en\00e1 polo\017eka.'-
));
INSERT INTO product_descriptions VALUES(2351-
,'SK'-
,UNISTR(-
'St\00f4l - W/48/R'-
),UNISTR(-
'St\00f4l - 60-palcov\00fd, biely lamin\00e1t so 48-palcovou prednou dos'||-
'kou; odpisovate\013en\00fd, zdanite\013en\00e1 polo\017eka.'-
));
INSERT INTO product_descriptions VALUES(2779-
,'SK'-
,UNISTR(-
'St\00f4l - OS/O/F'-
),UNISTR(-
'Mana\017e\00e9rsky dubov\00fd st\00f4l v\00e4\010d\0161ej ve\013ek'||-
'osti so z\00e1suvkami. Povrchov\00e1 \00faprava na objedn\00e1vku, sve'||-
'tl\00fd alebo tmav\00fd dub alebo pr\00edrodn\00e9 ru\010dn\00e9 le'||-
'\0161tenie.'-
));
INSERT INTO product_descriptions VALUES(3337-
,'SK'-
,UNISTR(-
'Mobiln\00fd web telef\00f3n'-
),UNISTR(-
'Mobiln\00fd telef\00f3n vr\00e1tane mesa\010dn\00e9ho poplatku za pr'||-
'\00edstup na web. Ploch\00fd tvar s ko\017eenkov\00fdm puzdrom a pr'||-
'\00edchytkou na opasok.'-
));
INSERT INTO product_descriptions VALUES(2091-
,'SK'-
,UNISTR(-
'Podlo\017eka na papiere LW 8 1/2 x 11'-
),UNISTR(-
'Podlo\017eka pod papiere, obalen\00e1, biela, ve\013ekos\0165 8,5 x 11'||-
' palcov'-
));
INSERT INTO product_descriptions VALUES(2093-
,'SK'-
,UNISTR(-
'Per\00e1 - 10/FP'-
),UNISTR(-
'Gu\013e\00f4\010dkov\00e9 pero, r\00fdchlo zasych\00e1 a je odoln'||-
'\00e9 proti rozotretiu. Hladk\00e9 p\00edsanie bez zadrh\00e1vania. Je'||-
'mn\00e1 \0161pi\010dka. \0160katule s jednou farbou (\010dierna, modr'||-
'\00e1, \010derven\00e1) alebo v\00fdberov\00e9 (6 \010diernych, 3 mo'||-
'dr\00e9 a 1 \010derven\00e9).'-
));
INSERT INTO product_descriptions VALUES(2144-
,'SK'-
,UNISTR(-
'Kryt na vizitk\00e1r'-
),UNISTR(-
'N\00e1hradn\00fd kryt na stoln\00fd dr\017eiak na vizitky. Dymov\00e1'||-
' siv\00e1 (p\00f4vodn\00e1 farba) alebo \010d\00edry plast.'-
));
INSERT INTO product_descriptions VALUES(2336-
,'SK'-
,UNISTR(-
'\0160katu\013ea vizitiek - 250'-
),UNISTR(-
'\0160katu\013ea vizitiek, kapacita 250 vizitiek. Pri objedn\00e1vke pou'||-
'\017eite formul\00e1r BC110-2, Rev. 3/2000 (na papieri alebo on-line) a '||-
'vypl\0148te v\0161etky polia ozna\010den\00e9 hviezdi\010dkou.'-
));
INSERT INTO product_descriptions VALUES(2337-
,'SK'-
,UNISTR(-
'Vizitky - 1000/2L'-
),UNISTR(-
'\0160katu\013ea vizitiek, kapacita 1000 vizitiek, dvojstrann\00e9 s r'||-
'\00f4znym jazykom na ka\017edej strane. Pri objedn\00e1vke pou\017eite'||-
' formul\00e1r BC111-2, Rev. 12/1999 (na papieri alebo on-line) a vypl'||-
'\0148te v\0161etky polia ozna\010den\00e9 hviezdi\010dkou a za\010di'||-
'arkavacie pol\00ed\010dko pre druh\00fd jazyk (angli\010dtina je v'||-
'\017edy na strane 1).'-
));
INSERT INTO product_descriptions VALUES(2339-
,'SK'-
,UNISTR(-
'Papier - \0161tandardn\00fd do tla\010diarne'-
),UNISTR(-
'20 lb. 8,5 x 11 palcov\00fd biely papier do laserovej tla\010diarne (rec'||-
'yklovan\00fd), desa\0165 500-listov\00fdch bal\00edkov'-
));
INSERT INTO product_descriptions VALUES(2536-
,'SK'-
,UNISTR(-
'Vizitky -250/2L'-
),UNISTR(-
'\0160katu\013ea vizitiek, kapacita 250 vizitiek, dvojstrann\00e9 s r'||-
'\00f4znym jazykom na ka\017edej strane. Pri objedn\00e1vke pou\017eite'||-
' formul\00e1r BC111-2, Rev. 12/1999 (na papieri alebo on-line) a vypl'||-
'\0148te v\0161etky polia ozna\010den\00e9 hviezdi\010dkou a za\010di'||-
'arkavacie pol\00ed\010dko pre druh\00fd jazyk (angli\010dtina je v'||-
'\017edy na strane 1).'-
));
INSERT INTO product_descriptions VALUES(2537-
,'SK'-
,UNISTR(-
'\0160katu\013ea vizitiek - 1000'-
),UNISTR(-
'\0160katu\013ea vizitiek, kapacita 1000 vizitiek. Pri objedn\00e1vke po'||-
'u\017eite formul\00e1r BC110-3, Rev. 3/2000 (na papieri alebo on-line) a'||-
' vypl\0148te v\0161etky polia ozna\010den\00e9 hviezdi\010dkou.'-
));
INSERT INTO product_descriptions VALUES(2783-
,'SK'-
,UNISTR(-
'Spinky na papier'-
),UNISTR(-
'Spinky na papier svetovej zna\010dky, ktor\00e9 definuj\00fa \0161tand'||-
'ard kvality. 10 \0161kat\00fa\013e po 100 spiniek. \010c. 1 be\017en'||-
'\00e9 alebo jumbo, hladk\00e9 alebo nek\013azav\00e9.'-
));
INSERT INTO product_descriptions VALUES(2808-
,'SK'-
,UNISTR(-
'Podlo\017eka na papiere LY 8 1/2 x 11'-
),UNISTR(-
'Podlo\017eka pod papiere, riadkovan\00e1, \017elt\00e1, ve\013ekos'||-
'\0165 8,5 x 11 palcov'-
));
INSERT INTO product_descriptions VALUES(2810-
,'SK'-
,UNISTR(-
'Per\00e1 Inkvisible'-
),UNISTR(-
'Gu\013e\00f4\010dkov\00e9 pero vybaven\00e9 hladkou presnou \0161pi'||-
'\010dkou. Prieh\013eadn\00e1 gumen\00e1 r\00fa\010dka d\00e1va preh'||-
'\013ead o z\00e1sobe atramentu a zabezpe\010duje pohodln\00e9 p\00eds'||-
'anie. Bal\00edk so 4 perami - \010dierne, modr\00e9, \010derven\00e9 '||-
'a zelen\00e9.'-
));
INSERT INTO product_descriptions VALUES(2870-
,'SK'-
,UNISTR(-
'Ceruzka zna\010dky Mech'-
),UNISTR(-
'Mechanick\00e1 ceruzka s ergonomick\00fdm dizajnom poskytuje zv\00fd'||-
'\0161en\00e9 pohodlie pri p\00edsan\00ed. Vymie\0148ate\013en\00e9 '||-
'gumy a tuhy. Dostupn\00e9 v troch ve\013ekostiach t\00fah: 0,5 mm (tenk'||-
'\00e1); 0,7 mm (stredn\00e1) a 0,9 mm (hrub\00e1).'-
));
INSERT INTO product_descriptions VALUES(3051-
,'SK'-
,UNISTR(-
'Per\00e1 - 10/MP'-
),UNISTR(-
'Ve\010dn\00e9 pero, r\00fdchlo zasych\00e1 a je odoln\00e9 proti rozo'||-
'tretiu. Hladk\00e9 p\00edsanie bez zadrh\00e1vania. Stredn\00e1 \0161'||-
'pi\010dka. \0160katule s jednou farbou (\010dierna, modr\00e1, \010de'||-
'rven\00e1) alebo v\00fdberov\00e9 (6 \010diernych, 3 modr\00e9 a 1 '||-
'\010derven\00e9).'-
));
INSERT INTO product_descriptions VALUES(3150-
,'SK'-
,UNISTR(-
'Puzdro na vizitky - 25'-
),UNISTR(-
'\0164a\017ek\00e9 plastov\00e9 puzdro na vizitky s embosovan\00fdm fi'||-
'remn\00fdm logom. Pojme asi 25 va\0161ich vizitiek v z\00e1vislosti od '||-
'hr\00fabky vizitky.'-
));
INSERT INTO product_descriptions VALUES(3208-
,'SK'-
,UNISTR(-
'Ceruzky - dreven\00e9'-
),UNISTR(-
'\0160katu\013ea dvoch tuctov dreven\00fdch ceruziek. Pri objedn\00e1va'||-
'n\00ed uve\010fte typ tuhy: 2H (double hard), H (hard), HB (hard black),'||-
' B (soft black).'-
));
INSERT INTO product_descriptions VALUES(3209-
,'SK'-
,UNISTR(-
'Str\00fahadlo na ceruzky'-
),UNISTR(-
'Elektrick\00e9 str\00fahadlo na ceruzky s no\017emi z pevnej ocele v z'||-
'\00e1ujme dlhej \017eivotnosti. PencilSaver pom\00e1ha predch\00e1dza'||-
'\0165 nadmern\00e9mu zaostreniu. Proti\0161mykov\00e9 gumen\00e9 podl'||-
'o\017eky. Zabudovan\00fd dr\017eiak na ceruzky.'-
));
INSERT INTO product_descriptions VALUES(3224-
,'SK'-
,UNISTR(-
'Vizitk\00e1r - 250'-
),UNISTR(-
'Prenosn\00e9 puzdro na organizovanie vizitiek, kapacita 250. Bro\017e'||-
'\00farov\00fd \0161t\00fdl s prieh\013eadn\00fdmi priehradkami na vi'||-
'zitky. Volite\013en\00e9 abecedn\00e9 z\00e1lo\017eky. Pri objedn'||-
'\00e1van\00ed uve\010fte farbu obalu (tmavohned\00e1, b\00e9\017eov'||-
'\00e1, burgundsk\00e1, \010dierna a svetlosiv\00e1).'-
));
INSERT INTO product_descriptions VALUES(3225-
,'SK'-
,UNISTR(-
'Vizitk\00e1r - 1000'-
),UNISTR(-
'Puzdro na vizitky s abecedn\00fdmi odde\013eova\010dmi, kapacita 1000. '||-
'Stoln\00fd \0161t\00fdl s dymovo-siv\00fdm obalom a \010diernym z'||-
'\00e1kladom. Vie\010dko je sn\00edmate\013en\00e9, aby sa puzdro dalo'||-
' uchov\00e1va\0165 aj v z\00e1suvke.'-
));
INSERT INTO product_descriptions VALUES(3511-
,'SK'-
,UNISTR(-
'Papier - pre tla\010diarne HQ'-
),UNISTR(-
'Kvalitn\00fd papier pre atramentov\00e9 a laserov\00e9 tla\010diarne t'||-
'estovan\00fd na odolnos\0165 proti zasek\00e1vaniu papiera v tla\010di'||-
'arni. Neobsahuje kyseliny, vhodn\00fd na arch\00edvne \00fa\010dely. V'||-
'\00e1ha 22 lb, belos\0165 92. Ve\013ekos\0165: 8 1/2 x 11. Jednotliv'||-
'\00e9 500-listov\00e9 bal\00edky.'-
));
INSERT INTO product_descriptions VALUES(3515-
,'SK'-
,UNISTR(-
'N\00e1hradn\00e9 tuhy'-
),UNISTR(-
'N\00e1hradn\00e9 tuhy pre mechanick\00e9 ceruzky. Ka\017ed\00e9 balen'||-
'ie obsahuje 25 t\00fah a n\00e1hradn\00fa gumu. Dostupn\00e9 v troch v'||-
'e\013ekostiach t\00fah: 0,5 mm (tenk\00e1); 0,7 mm (stredn\00e1) a 0,9'||-
' mm (hrub\00e1).'-
));
INSERT INTO product_descriptions VALUES(2986-
,'SK'-
,UNISTR(-
'Manu\00e1l - Vision OS/2x +'-
),UNISTR(-
'Manu\00e1ly pre opera\010dn\00fd syst\00e9m Vision V 2.x a Vision Offi'||-
'ce Suite'-
));
INSERT INTO product_descriptions VALUES(3163-
,'SK'-
,UNISTR(-
'Manu\00e1l - Vision Net6.3/US'-
),UNISTR(-
'Referen\010dn\00fd manu\00e1l pre Vision Networking V6.3 Americk\00e1 '||-
'verzia s roz\0161\00edren\00fdm \0161ifrovan\00edm.'-
));
INSERT INTO product_descriptions VALUES(3165-
,'SK'-
,UNISTR(-
'Manu\00e1l - Vision Tools2.0'-
),UNISTR(-
'Referen\010dn\00fd manu\00e1l pre Vision Business Tools Suite V2.0. Zah'||-
'\0155\0148a in\0161tal\00e1ciu, konfigur\00e1ciu a pou\017e\00edvat'||-
'e\013esk\00fa pr\00edru\010dku.'-
));
INSERT INTO product_descriptions VALUES(3167-
,'SK'-
,UNISTR(-
'Manu\00e1l - Vision OS/2.x'-
),UNISTR(-
'Referen\010dn\00fd manu\00e1l pre opera\010dn\00fd syst\00e9m Vision'||-
' V2.0/2.1/2/3. Kompletn\00e1 in\0161tal\00e1cia, konfigur\00e1cia, spr'||-
'\00e1va a ladenie pre administr\00e1ciu syst\00e9mu Vision. Tento manu'||-
'\00e1l nahr\00e1dza jednotliv\00e9 manu\00e1ly pre verziu 2.0 a 2.1.'-
));
INSERT INTO product_descriptions VALUES(3216-
,'SK'-
,UNISTR(-
'Manu\00e1l - Vision Net6.3'-
),UNISTR(-
'Referen\010dn\00fd manu\00e1l pre Vision Networking V6.3 Neamerick'||-
'\00e1 verzia so z\00e1kladn\00fdm \0161ifrovan\00edm.'-
));
INSERT INTO product_descriptions VALUES(3220-
,'SK'-
,UNISTR(-
'Manu\00e1l - Vision OS/1.2'-
),UNISTR(-
'Referen\010dn\00fd manu\00e1l pre opera\010dn\00fd syst\00e9m Vision'||-
' Operating V1.2. Kompletn\00e1 in\0161tal\00e1cia, konfigur\00e1cia, s'||-
'pr\00e1va a ladenie pre administr\00e1ciu syst\00e9mu Vision.'-
));
INSERT INTO product_descriptions VALUES(1729-
,'SK'-
,UNISTR(-
'Chemik\00e1lie - RCP'-
),UNISTR(-
'Chemik\00e1lie na \010distenie - 3500 tamp\00f3nov na \010distenie val'||-
'cov'-
));
INSERT INTO product_descriptions VALUES(1910-
,'SK'-
,UNISTR(-
'Sklen\00e9 vl\00e1kna - H'-
),UNISTR(-
'Sklen\00e9 vl\00e1kna - siln\00e9, hr\00fabka 1'-
));
INSERT INTO product_descriptions VALUES(1912-
,'SK'-
,UNISTR(-
'Plech z nehrdzavej\00facej ocele - 3 mm'-
),UNISTR(-
'Plech z nehrdzavej\00facej ocele - 3 mm. Mo\017eno ho predv\0155ta'||-
'\0165 pre \0161tandardn\00e9 zdroje, dr\017eiaky mati\010dn\00fdch d'||-
'osiek a pevn\00fdch diskov. Pri objedn\00e1van\00ed predv\0155tan'||-
'\00e9ho plechu pou\017eite pr\00edslu\0161n\00fa \0161abl\00f3nu na'||-
' identifik\00e1ciu \010d\00edsla modelu, umiestnenia a ve\013ekosti ho'||-
'tov\00e9ho plechu.'-
));
INSERT INTO product_descriptions VALUES(1940-
,'SK'-
,UNISTR(-
'Elektrostatick\00fd uzem\0148ovac\00ed n\00e1ramok/klip'-
),UNISTR(-
'Elektrostatick\00fd uzem\0148ovac\00ed n\00e1ramok so svorkou typu ali'||-
'g\00e1tor na \013eahk\00e9 pripojenie ku skrinke po\010d\00edta\010d'||-
'a alebo in\00e9 uzemnenie.'-
));
INSERT INTO product_descriptions VALUES(2030-
,'SK'-
,UNISTR(-
'Latexov\00e9 rukavice'-
),UNISTR(-
'Latexov\00e9 rukavice pre mont\00e1\017enych technikov, na manipul'||-
'\00e1ciu s chemik\00e1liami a in\0161tal\00e1cie. Siln\00e9, bezpe'||-
'\010dnostnej oran\017eovej farby, so zdrsnenou plochou na prstoch a palc'||-
'i. Vodotesn\00e9 a odoln\00e9 a\017e do 220 V/2 A, 110 V/5 A. Kyselinov'||-
'zdorn\00e9 a\017e do 5 min\00fat.'-
));
INSERT INTO product_descriptions VALUES(2326-
,'SK'-
,UNISTR(-
'Plast - Y'-
),UNISTR(-
'Plast - \017elt\00fd, \0161tandardn\00e1 kvalita.'-
));
INSERT INTO product_descriptions VALUES(2330-
,'SK'-
,UNISTR(-
'Plast - R'-
),UNISTR(-
'Plast - \010derven\00fd, \0161tandardn\00e1 kvalita.'-
));
INSERT INTO product_descriptions VALUES(2334-
,'SK'-
,UNISTR(-
'\017divica'-
),UNISTR(-
'Viac\00fa\010delov\00e1 syntetick\00e1 \017eivica.'-
));
INSERT INTO product_descriptions VALUES(2340-
,'SK'-
,UNISTR(-
'Chemik\00e1lie - SW'-
),UNISTR(-
'\010cistiace chemik\00e1lie - 3500 antistatick\00fdch utierok'-
));
INSERT INTO product_descriptions VALUES(2365-
,'SK'-
,UNISTR(-
'Chemik\00e1lie - TCS'-
),UNISTR(-
'\010cistiaca chemik\00e1lia - 2500 transportn\00fdch \010distiacich h'||-
'\00e1rkov'-
));
INSERT INTO product_descriptions VALUES(2594-
,'SK'-
,UNISTR(-
'Sklen\00e9 vl\00e1kna - L'-
),UNISTR(-
'Sklen\00e9 vl\00e1kna - tenk\00e9 na intern\00e9 tepeln\00e9 tienenie'||-
', hr\00fabka 1/4'-
));
INSERT INTO product_descriptions VALUES(2596-
,'SK'-
,UNISTR(-
'Plech z nehrdzavej\00facej ocele - 1 mm'-
),UNISTR(-
'Plech z nehrdzavej\00facej ocele - 3 mm. M\00f4\017ee by\0165 predv'||-
'\0155tan\00fd na mati\010dn\00e9 dosky \0161tandardn\00fdch modelov '||-
'a dr\017eiaky bat\00e9ri\00ed. Pri objedn\00e1van\00ed predv\0155tan'||-
'\00e9ho plechu pou\017eite pr\00edslu\0161n\00fa \0161abl\00f3nu na'||-
' identifik\00e1ciu \010d\00edsla modelu, umiestnenia a ve\013ekosti ho'||-
'tov\00e9ho plechu.'-
));
INSERT INTO product_descriptions VALUES(2631-
,'SK'-
,UNISTR(-
'Elektrostatick\00fd uzem\0148ovac\00ed n\00e1ramok/QR'-
),UNISTR(-
'Elektrostatick\00fd uzem\0148ovac\00ed n\00e1ramok: Dvojit\00fd vodi'||-
'\010d s r\00fdchlouvo\013e\0148ovac\00edm konektorom. Jeden kus sa pe'||-
'rmanentne pripoj\00ed na skrinku po\010d\00edta\010da skrutkou a druh'||-
'\00fd sa pripoj\00ed na n\00e1ramok. S\00fa k dispoz\00edcii aj dodat'||-
'o\010dn\00e9 permanentn\00e9 zakon\010denia.'-
));
INSERT INTO product_descriptions VALUES(2721-
,'SK'-
,UNISTR(-
'Puzdro na laptop - L/S'-
),UNISTR(-
'\010cierne ko\017een\00e9 puzdro na po\010d\00edta\010d - kapacita n'||-
'a jeden laptop s vreckami na manu\00e1ly, dodato\010dn\00fd hardv\00e9'||-
'r a dokumenty. Nastavite\013en\00e9 ochrann\00e9 remene a odn\00edmate'||-
'\013en\00e9 vrecko na zdroj a k\00e1ble.'-
));
INSERT INTO product_descriptions VALUES(2722-
,'SK'-
,UNISTR(-
'Puzdro na laptop - L/D'-
),UNISTR(-
'\010cierne ko\017een\00e9 puzdro na po\010d\00edta\010d - kapacita n'||-
'a dva laptopy s vreckami na manu\00e1ly, dodato\010dn\00fd hardv\00e9r'||-
' a dokumenty. Nastavite\013en\00e9 ochrann\00e9 remene a odn\00edmate'||-
'\013en\00e9 vreck\00e1 na zdroje a k\00e1ble. N\00e1plecn\00fd reme'||-
'\0148 s dvojitou \0161\00edrkou pre v\00e4\010d\0161ie pohodlie.'-
));
INSERT INTO product_descriptions VALUES(2725-
,'SK'-
,UNISTR(-
'Strojov\00fd olej'-
),UNISTR(-
'Strojov\00fd olej na mazanie dver\00ed a posuvn\00fdch \010dast\00ed '||-
'CD-ROM mechaniky. Samo\010distiaca nastavite\013en\00e1 hubica na jemn'||-
'\00fd a\017e stredn\00fd prietok.'-
));
INSERT INTO product_descriptions VALUES(2782-
,'SK'-
,UNISTR(-
'Ta\0161ka na laptop - C/S'-
),UNISTR(-
'Pl\00e1tenn\00e9 puzdro na po\010d\00edta\010d - kapacita na jeden la'||-
'ptop s vreckami na manu\00e1ly, dodato\010dn\00fd hardv\00e9r a dokume'||-
'nty. Nastavite\013en\00e9 ochrann\00e9 remene a odn\00edmate\013en'||-
'\00e9 vrecko na zdroj a k\00e1ble. Vonkaj\0161ie vrecko s \013eahko ot'||-
'v\00e1rate\013en\00fdm uz\00e1verom na jednoduch\00fd pr\00edstup po'||-
'\010das cestovania.'-
));
INSERT INTO product_descriptions VALUES(3187-
,'SK'-
,UNISTR(-
'Plast - B/HD'-
),UNISTR(-
'Plast - modr\00fd, vysokohustotn\00fd.'-
));
INSERT INTO product_descriptions VALUES(3189-
,'SK'-
,UNISTR(-
'Plast - G'-
),UNISTR(-
'Plast - zelen\00fd, \0161tandardn\00e1 hustota.'-
));
INSERT INTO product_descriptions VALUES(3191-
,'SK'-
,UNISTR(-
'Plast - O'-
),UNISTR(-
'Plast - oran\017eov\00fd, \0161tandardn\00e1 hustota.'-
));
INSERT INTO product_descriptions VALUES(3193-
,'SK'-
,UNISTR(-
'Plast - W/HD'-
),UNISTR(-
'Plast - biely, vysokohustotn\00fd.'-
));
commit;
set define on
